"use strict";
(() => {
var exports = {};
exports.id = 5513;
exports.ids = [5513];
exports.modules = {

/***/ 18026:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/empty.fb5e331e.png","height":400,"width":400,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAkklEQVR42mMIZug2Zygz3Wy6maGs2zyIgeFk8uH/C/7nAeGC/4f/n0xm2J208/fu37v+7Pqz+zeQlcSwiG3b1+X/J/2d8nf5/21fF7ExNDKtj53wYs//Lf8mPlsXX83E0MUyjyGvbs//rf+zWmcz9LMxMDD+Z2TgLmku7U6/MTG0jwEEGBkY+hgmM0yI7mnrZQAAjkVC4z+TQUUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 95370:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/Frame.bce93628.png","height":78,"width":78,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAbklEQVR42iXIvwoBARwA4F+e4XKbRXkCddTldAoD3fm3USaLZFQGi4GJN/6i7hu/cDUwM/KwF1phKNRqpY+++Ieeu5upxESEQjg46UjkIix1jZ3lFk1UMqW5tcpKGkqp0Laz8fIMF5lCbevo7fsDBFtP2lOQvtEAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 72523:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/store_message.f1916534.svg","height":60,"width":1240});

/***/ }),

/***/ 6189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/sort.3a34c357.png","height":56,"width":59,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAAtElEQVR42jWOMQrCQBREp1X0HoKN4BHEA1hb2Es6KxEvIFa7hZAuq6KgWRtvkMbaLmIrYmslNuszJIHH/7N5O4mMS+eQmSQ9Q9s6L6hZlzYkHg6/NvErk/gn4rQUMvarWR/qYgkIA4QL8sw4HzMDOfAuF2FP3Y2ZQw86sOPSidn/C13MiDmEJrtgyWc21T+8se9l5YQssJxtC4H6D6GFcERYlEJMg68aHoQXUmAfg2DEhUiSfkzsjl3775SOAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 22519:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(94960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13258);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var redux_slices_configData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53236);
/* harmony import */ var _src_components_store_details__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1516);
/* harmony import */ var api_manage_ApiRoutes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(60274);
/* harmony import */ var _src_components_seo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(95376);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var components_ScrollToTop__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(11737);
/* harmony import */ var api_manage_hooks_custom_hooks_useScrollToTop__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(59599);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__, _src_components_store_details__WEBPACK_IMPORTED_MODULE_7__, _src_components_seo__WEBPACK_IMPORTED_MODULE_8__]);
([_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__, _src_components_store_details__WEBPACK_IMPORTED_MODULE_7__, _src_components_seo__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);













const Index = ({ configData , storeDetails , landingPageData  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_4__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const { distance  } = router.query;
    const metaTitle = `${storeDetails?.meta_title ? storeDetails?.meta_title : storeDetails?.name} - ${configData?.business_name}`;
    const metaImage = storeDetails?.meta_image_full_url ?? storeDetails.cover_photo_full_url;
    const [isSSR, setIsSSR] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const initialSet = ()=>{
        const stores = [];
        stores.push(storeDetails);
        localStorage.setItem("visitedStores", JSON.stringify(stores));
    };
    const manageVisitAgain = ()=>{
        if (localStorage.getItem("visitedStores")) {
            let visitedStores = JSON.parse(localStorage.getItem("visitedStores"));
            if (visitedStores?.length > 0) {
                if (!visitedStores.find((item)=>item?.id === storeDetails?.id)) {
                    visitedStores.push({
                        ...storeDetails,
                        distance: distance
                    });
                }
                localStorage.setItem("visitedStores", JSON.stringify(visitedStores));
            } else {
                initialSet();
            }
        } else {
            initialSet();
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        //setIsSSR(false);
        if (storeDetails) {
            manageVisitAgain();
        // initialSet();
        }
        if (configData) {
            if (configData.length === 0) {
                next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/404");
            } else if (configData?.maintenance_mode) {
                next_router__WEBPACK_IMPORTED_MODULE_5___default().push("/maintainance");
            } else {
                dispatch((0,redux_slices_configData__WEBPACK_IMPORTED_MODULE_6__/* .setConfigData */ .Zr)(configData));
            }
        } else {}
    }, [
        configData,
        storeDetails
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2___default()), {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_seo__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    title: metaTitle ? metaTitle : "loading",
                    image: metaImage,
                    businessName: configData?.business_name,
                    description: storeDetails?.meta_description,
                    configData: configData
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    configData: configData,
                    landingPageData: landingPageData,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_9__.NoSsr, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_store_details__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            storeDetails: storeDetails,
                            configData: configData
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);
const getServerSideProps = async (context)=>{
    const storeId = context.query.id;
    const moduleId = context.query.module_id;
    const { req  } = context;
    const language = req.cookies.languageSetting;
    const lat = context.query.lat;
    const lng = context.query.lng;
    const configRes = await fetch(`${"https://bite.md"}${api_manage_ApiRoutes__WEBPACK_IMPORTED_MODULE_12__/* .config_api */ .Ax}`, {
        method: "GET",
        headers: {
            "X-software-id": 33571750,
            "X-server": "server",
            origin: process.env.NEXT_CLIENT_HOST_URL,
            "X-localization": language,
            lat: lat,
            lng: lng
        }
    });
    const storeDetailsRes = await fetch(`${"https://bite.md"}${api_manage_ApiRoutes__WEBPACK_IMPORTED_MODULE_12__/* .store_details_api */ .HR}/${storeId}`, {
        method: "GET",
        headers: {
            moduleId: moduleId,
            "X-software-id": 33571750,
            "X-server": "server",
            origin: process.env.NEXT_CLIENT_HOST_URL,
            "X-localization": language
        }
    });
    const landingPageRes = await fetch(`${"https://bite.md"}/api/v1/react-landing-page`, {
        method: "GET",
        headers: {
            "X-software-id": 33571750,
            "X-server": "server",
            origin: process.env.NEXT_CLIENT_HOST_URL,
            "X-localization": language
        }
    });
    const landingPageData = await landingPageRes.json();
    const config = await configRes.json();
    const storeDetails = await storeDetailsRes.json();
    return {
        props: {
            configData: config,
            storeDetails: storeDetails,
            landingPageData: landingPageData
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 27707:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetCommonConditionStore)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60274);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var _helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90603);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const getCommonConditionStoreProduct = async (params)=>{
    const { id , moduleId , storeZoneId , offset , limit  } = params;
    if ((0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__/* .getCurrentModuleType */ .X)()) {
        const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .common_condition_product_in_store */ .$p}?store_id=${id}&offset=${offset}&limit=${limit}`);
        return data;
    } else {
        const { data: data1  } = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"https://bite.md"}${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .common_condition_product_in_store */ .$p}/${id}`, {
            headers: {
                "Content-Type": "application/json",
                zoneid: storeZoneId,
                moduleId: moduleId
            }
        });
        return data1;
    }
};
function useGetCommonConditionStore(params) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "common-condition-store",
        params
    ], ()=>getCommonConditionStoreProduct(params), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 3934:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ usePopularProductsInStore)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60274);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var _helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90603);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const getPopularProductsInStore = async (params)=>{
    const { id , moduleId , storeZoneId  } = params;
    if ((0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__/* .getCurrentModuleType */ .X)()) {
        const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .popular_items_in_store */ ._d}?store_id=${id}`);
        return data;
    } else {
        const { data: data1  } = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"https://bite.md"}${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .popular_items_in_store */ ._d}?store_id=${id}`, {
            headers: {
                "Content-Type": "application/json",
                zoneid: storeZoneId,
                moduleId: moduleId
            }
        });
        return data1;
    }
};
function usePopularProductsInStore(params) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)([
        "popular-store-items",
        params
    ], ()=>getPopularProductsInStore(params), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 58968:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetStoreReviews)
/* harmony export */ });
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(67759);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__, _MainApi__WEBPACK_IMPORTED_MODULE_2__]);
([_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__, _MainApi__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getData = async (id)=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_2__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .store_review_api */ .ZU}?store_id=${id}`);
    return data;
};
function useGetStoreReviews(id) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)("track-order-dxxx", ()=>getData(id), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_1__/* .onSingleErrorResponse */ .f$
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 62540:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetSearchedStoreItems)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var _helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90603);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const getData = async (pageParams)=>{
    const { storeId , searchKey , offset , limit , type , moduleId , storeZoneId  } = pageParams;
    if ((0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__/* .getCurrentModuleType */ .X)()) {
        const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .store_item_search_api */ .qY}?store_id=${storeId}&name=${searchKey}&offset=${offset}&limit=${limit}&type=${type}`);
        return data;
    } else {
        const { data: data1  } = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"https://bite.md"}${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .store_item_search_api */ .qY}?store_id=${storeId}&name=${searchKey}&offset=${offset}&limit=${limit}&type=${type}`, {
            headers: {
                "Content-Type": "application/json",
                zoneid: JSON.stringify(storeZoneId),
                moduleId: moduleId
            }
        });
        return data1;
    }
};
function useGetSearchedStoreItems(pageParams, handleSearchSuccess) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useInfiniteQuery)("searched-store-items", ()=>getData(pageParams), {
        getNextPageParam: (lastPage, allPages)=>{
            const nextPage = allPages.length + 1;
            return lastPage?.products?.length > 0 ? nextPage : undefined;
        },
        getPreviousPageParam: (firstPage, allPages)=>firstPage.prevCursor,
        retry: 3,
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$,
        cacheTime: "0"
    });
// return useQuery("searched-store-items", () => getData(pageParams), {
//   enabled: false,
//   onSuccess: handleSearchSuccess,
//   onError: onErrorResponse,
// });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 20751:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetItemOrStore)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getBanners = async (id)=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .banners */ .Ty}/${id}`);
    return data;
};
function useGetItemOrStore(id) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)("store-banners", ()=>getBanners(id), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 54410:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetStoresCategoriesItem)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var _helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(90603);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__, axios__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const getData = async (pageParams)=>{
    const { storeId , categoryId: categoryIdEr , offset , type , limit , minMax , moduleId , storeZoneId  } = pageParams;
    const categoryId = categoryIdEr?.length === 0 ? [
        0
    ] : categoryIdEr;
    if ((0,_helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_4__/* .getCurrentModuleType */ .X)()) {
        if (minMax[0] !== 0 && minMax[1] !== 1) {
            const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .latest_items_api */ .vV}?store_id=${storeId}&category_id=${categoryId}&offset=${offset}&limit=${limit}&type=${type}&min_price=${minMax[0]}&max_price=${minMax[1]}`);
            return data;
        } else {
            const { data: data1  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .latest_items_api */ .vV}?store_id=${storeId}&category_id=${categoryId}&offset=${offset}&limit=${limit}&type=${type}`);
            return data1;
        }
    } else {
        if (minMax[0] !== 0 && minMax[1] !== 1) {
            const { data: data2  } = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"https://bite.md"}${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .latest_items_api */ .vV}?store_id=${storeId}&category_id=${categoryId}&offset=${offset}&limit=${limit}&type=${type}&min_price=${minMax[0]}&max_price=${minMax[1]}`, {
                headers: {
                    "Content-Type": "application/json",
                    zoneid: JSON.stringify(storeZoneId),
                    moduleId: moduleId
                }
            });
            return data2;
        } else {
            const { data: data3  } = await axios__WEBPACK_IMPORTED_MODULE_3__["default"].get(`${"https://bite.md"}${_ApiRoutes__WEBPACK_IMPORTED_MODULE_5__/* .latest_items_api */ .vV}?store_id=${storeId}&category_id=${categoryId}&offset=${offset}&limit=${limit}&type=${type}`, {
                headers: {
                    "Content-Type": "application/json",
                    zoneid: JSON.stringify(storeZoneId),
                    moduleId: moduleId
                }
            });
            return data3;
        }
    }
};
function useGetStoresCategoriesItem(pageParams, handleSuccess) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useInfiniteQuery)([
        "stores-categories-item",
        pageParams.offset,
        pageParams.storeId
    ], ()=>getData(pageParams), {
        // enabled: false,
        // onSuccess: handleSuccess,
        // onError: onErrorResponse,
        getNextPageParam: (lastPage, allPages)=>{
            const nextPage = allPages.length + 1;
            return lastPage?.products?.length > 0 ? nextPage : undefined;
        },
        getPreviousPageParam: (firstPage, allPages)=>firstPage.prevCursor,
        retry: 3,
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$,
        cacheTime: "0"
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 63566:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22021);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _cards_GuestCheckoutModal__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(87641);
/* harmony import */ var helper_functions_getToken__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(61859);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(86201);
/* harmony import */ var utils_toasterMessages__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(70557);
/* harmony import */ var components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58861);
/* harmony import */ var _store_details_assets_Frame_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(95370);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_4__, _cards_GuestCheckoutModal__WEBPACK_IMPORTED_MODULE_6__, react_hot_toast__WEBPACK_IMPORTED_MODULE_7__]);
([i18next__WEBPACK_IMPORTED_MODULE_4__, _cards_GuestCheckoutModal__WEBPACK_IMPORTED_MODULE_6__, react_hot_toast__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const AnimatedContainer = (0,_mui_system__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box, {
    shouldForwardProp: (prop)=>prop !== "expanded"
})(({ theme , expanded  })=>({
        position: "fixed",
        right: "10%",
        top: "80%",
        bottom: {
            xs: 100,
            md: 40
        },
        cursor: "pointer",
        zIndex: 999,
        boxShadow: "0px 10px 30px 0px rgba(3, 157, 85, 0.24)",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: theme.palette.neutral[100],
        paddingLeft: expanded ? "20px" : "0px",
        borderRadius: expanded ? "8px 50px 50px 8px" : "50px",
        transition: "all 0.3s ease",
        gap: "10px",
        [theme.breakpoints.down("sm")]: {
            right: "0%",
            gap: "10px"
        }
    }));
const Prescription = ({ storeId , expanded  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const token = (0,helper_functions_getToken__WEBPACK_IMPORTED_MODULE_10__/* .getToken */ .L)();
    const [sideDrawerOpen, setSideDrawerOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    const handleClick = ()=>{
        if (token) {
            handleRoute();
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_7__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)(utils_toasterMessages__WEBPACK_IMPORTED_MODULE_11__/* .not_logged_in_message */ .XO));
        }
    };
    const handleRoute = ()=>{
        router.push({
            pathname: "/checkout",
            query: {
                page: "prescription",
                store_id: storeId
            }
        }, undefined, {
            shallow: true
        });
        setOpen(false);
    };
    const iconColor = theme.palette.neutral[100];
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnimatedContainer, {
        expanded: expanded,
        onClick: handleClick,
        spacing: 2,
        children: [
            expanded && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                fontSize: {
                    xs: "14px",
                    sm: "14px"
                },
                fontWeight: "500",
                color: theme.palette.primary.main,
                children: (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("Prescription Order")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                backgroundColor: theme.palette.primary.main,
                padding: "18px",
                width: {
                    xs: "50px",
                    sm: "50px",
                    md: "65px"
                },
                hight: {
                    xs: "50px",
                    sm: "50px",
                    md: "65px"
                },
                borderRadius: "50%",
                alignItems: "center",
                justifyContent: "center",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                    width: "100%",
                    src: _store_details_assets_Frame_png__WEBPACK_IMPORTED_MODULE_9__/* ["default"].src */ .Z.src
                })
            }),
            open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_GuestCheckoutModal__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                open: open,
                setOpen: setOpen,
                setSideDrawerOpen: setSideDrawerOpen,
                handleRoute: handleRoute
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Prescription);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 11737:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);


function ScrollToTop({ router  }) {
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        window.scrollTo(0, 0);
    }, [
        router.pathname
    ]);
    return null;
}
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((0,next_router__WEBPACK_IMPORTED_MODULE_1__.withRouter)(ScrollToTop));


/***/ }),

/***/ 18293:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(32245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(81261);
/* harmony import */ var _ClosedNowOverlay__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(92389);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_3__, _ClosedNowOverlay__WEBPACK_IMPORTED_MODULE_4__]);
([_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_3__, _ClosedNowOverlay__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const ClosedNowScheduleWise = (props)=>{
    const { active , schedules , borderRadius  } = props;
    if (active) {
        if (schedules.length > 0) {
            const todayInNumber = moment__WEBPACK_IMPORTED_MODULE_2___default()().weekday();
            let isOpen = false;
            let filteredSchedules = schedules.filter((item)=>item.day === todayInNumber);
            let isAvailableNow = [];
            filteredSchedules.forEach((item)=>{
                if ((0,_utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_3__/* .isAvailable */ ._e)(item?.opening_time, item?.closing_time)) {
                    isAvailableNow.push(item);
                }
            });
            if (isAvailableNow.length > 0) {
                isOpen = true;
            } else {
                isOpen = false;
            }
            if (!isOpen) {
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ClosedNowOverlay__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    borderRadius: borderRadius
                });
            }
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ClosedNowOverlay__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                borderRadius: borderRadius
            });
        }
    } else {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ClosedNowOverlay__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
            borderRadius: borderRadius
        });
    }
};
ClosedNowScheduleWise.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ClosedNowScheduleWise);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 65309:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export StyledSimpleBar */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_LinearProgress__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25545);
/* harmony import */ var _mui_material_LinearProgress__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_LinearProgress__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(94172);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(simplebar_react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var simplebar_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(29233);
/* harmony import */ var simplebar_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(simplebar_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var api_manage_hooks_react_query_review_useGetStoreReviews__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(58968);
/* harmony import */ var utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(81261);
/* harmony import */ var components_search_CustomRatings__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(27559);
/* harmony import */ var components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(58861);
/* harmony import */ var components_DotSpin__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(16533);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(45269);
/* harmony import */ var components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(7188);
/* harmony import */ var helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(52539);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(90603);
/* harmony import */ var components_food_details_foodDetail_modal_FoodDetailModal__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(49957);
/* harmony import */ var components_cards_ModuleModal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(59876);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var redux_slices_wishList__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(64134);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(86201);
/* harmony import */ var utils_toasterMessages__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(70557);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(64038);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(94156);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__, api_manage_hooks_react_query_review_useGetStoreReviews__WEBPACK_IMPORTED_MODULE_10__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__, components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_16__, components_food_details_foodDetail_modal_FoodDetailModal__WEBPACK_IMPORTED_MODULE_17__, components_cards_ModuleModal__WEBPACK_IMPORTED_MODULE_18__, react_hot_toast__WEBPACK_IMPORTED_MODULE_21__, api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_22__, api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_23__]);
([i18next__WEBPACK_IMPORTED_MODULE_5__, api_manage_hooks_react_query_review_useGetStoreReviews__WEBPACK_IMPORTED_MODULE_10__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__, components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_16__, components_food_details_foodDetail_modal_FoodDetailModal__WEBPACK_IMPORTED_MODULE_17__, components_cards_ModuleModal__WEBPACK_IMPORTED_MODULE_18__, react_hot_toast__WEBPACK_IMPORTED_MODULE_21__, api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_22__, api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_23__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



























const BorderLinearProgress = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.styled)((_mui_material_LinearProgress__WEBPACK_IMPORTED_MODULE_2___default()))(({ theme  })=>({
        height: 8,
        borderRadius: 5,
        [`&.${_mui_material_LinearProgress__WEBPACK_IMPORTED_MODULE_2__.linearProgressClasses.colorPrimary}`]: {
            backgroundColor: theme.palette.grey[theme.palette.mode === "light" ? 200 : 800]
        },
        [`& .${_mui_material_LinearProgress__WEBPACK_IMPORTED_MODULE_2__.linearProgressClasses.bar}`]: {
            borderRadius: 5,
            backgroundColor: theme.palette.primary.main
        }
    }));
const StyledSimpleBar = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_3__.styled)((simplebar_react__WEBPACK_IMPORTED_MODULE_8___default()))(({ theme  })=>({
        maxHeight: "60vh",
        "& .simplebar-track.simplebar-vertical": {
            right: "-20px !important"
        }
    }));
const RestaurantReviewModal = ({ product_avg_rating , rating_count , reviews_comments_count , id , restaurantDetails , configData  })=>{
    const [review_count, setReview_Count] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_19__.useRouter)();
    const reduxDispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useDispatch)();
    const [openModal, setOpenModal] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const [productData, setProductData] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)({});
    const { wishLists  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.wishList);
    const { data , refetch , isLoading  } = (0,api_manage_hooks_react_query_review_useGetStoreReviews__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(id);
    const [isWishlisted, setIsWishlisted] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const { mutate: addFavoriteMutation  } = (0,api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_22__/* .useAddToWishlist */ .x)();
    const { mutate  } = (0,api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_23__/* .useWishListDelete */ .V)();
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        refetch();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        wishlistItemExistHandler();
    }, [
        wishLists
    ]);
    const wishlistItemExistHandler = ()=>{
        if (wishLists?.item?.find((wishItem)=>wishItem.id === productData?.id)) {
            setIsWishlisted(true);
        } else {
            setIsWishlisted(false);
        }
    };
    const getPercentOfNumber = (percentRate)=>{
        const total = restaurantDetails?.ratings.reduce((sum, current)=>sum + current, 0);
        return percentRate ? (percentRate / total * 100).toFixed(1) : 0;
    };
    const handleClick = (itemReview)=>{
        setProductData(itemReview);
        if (itemReview?.item?.module_type === "ecommerce") {
            router.push({
                pathname: "/product/[id]",
                query: {
                    id: `${itemReview?.item?.slug ? itemReview?.item?.slug : itemReview?.item?.id}`,
                    module_id: `${(0,helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_24__/* .getModuleId */ .S)()}`
                }
            });
        } else {
            setOpenModal(true);
        }
    };
    const addToWishlistHandler = (e)=>{
        e.stopPropagation();
        let token = undefined;
        if (false) {}
        if (token) {
            addFavoriteMutation(item?.id, {
                onSuccess: (response)=>{
                    if (response) {
                        reduxDispatch((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_20__/* .addWishList */ .TM)(item));
                        setIsWishlisted(true);
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].success(response?.message);
                    }
                },
                onError: (error)=>{
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].error(error.response.data.message);
                }
            });
        } else react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)(utils_toasterMessages__WEBPACK_IMPORTED_MODULE_25__/* .not_logged_in_message */ .XO));
    };
    const removeFromWishlistHandler = (e)=>{
        e.stopPropagation();
        const onSuccessHandlerForDelete = (res)=>{
            reduxDispatch((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_20__/* .removeWishListItem */ .$8)(item?.id));
            setIsWishlisted(false);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].success(res.message, {
                id: "wishlist"
            });
        };
        mutate(item?.id, {
            onSuccess: onSuccessHandlerForDelete,
            onError: (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_21__["default"].error(error.response.data.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, {
        sx: {
            position: "relative",
            width: {
                xs: "350px",
                sm: "450px",
                md: "750px"
            },
            p: "15px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_15__/* .CustomStackFullWidth */ .Xw, {
                sx: {
                    padding: {
                        xs: ".5rem",
                        sm: "1rem",
                        md: "1.2rem"
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(StyledSimpleBar, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_15__/* .CustomStackFullWidth */ .Xw, {
                            backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.neutral[400], 0.1),
                            padding: "2rem",
                            borderRadius: "8px",
                            color: theme.palette.text.primary,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                container: true,
                                gap: {
                                    xs: 2,
                                    md: 0
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        item: true,
                                        xs: 12,
                                        sm: 12,
                                        md: 6,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                    component: "span",
                                                    fontSize: "50px",
                                                    color: theme.palette.primary.main,
                                                    fontWeight: "500",
                                                    children: [
                                                        (0,utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__/* .getNumberWithConvertedDecimalPoint */ .J2)(product_avg_rating, 1),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            component: "span",
                                                            fontSize: "35px",
                                                            color: theme.palette.primary.deep,
                                                            fontWeight: "500",
                                                            children: "/5"
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_search_CustomRatings__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    readOnly: true,
                                                    ratingValue: product_avg_rating
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    spacing: 1,
                                                    marginTop: ".8rem",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "13px",
                                                            color: theme.palette.neutral[600],
                                                            backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.neutral[500], 0.2),
                                                            padding: "2px 6px",
                                                            borderRadius: "4px",
                                                            children: [
                                                                rating_count,
                                                                " ",
                                                                (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Ratings")
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "13px",
                                                            color: theme.palette.neutral[600],
                                                            backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.neutral[500], 0.2),
                                                            padding: "2px 6px",
                                                            borderRadius: "4px",
                                                            children: [
                                                                reviews_comments_count,
                                                                " ",
                                                                (0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)("Reviews")
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        item: true,
                                        xs: 12,
                                        sm: 12,
                                        md: 6,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                            gap: 1.5,
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            children: "5"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                                            flexGrow: 1,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BorderLinearProgress, {
                                                                variant: "determinate",
                                                                value: getPercentOfNumber(restaurantDetails?.ratings[0])
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            color: theme.palette.neutral[600],
                                                            children: [
                                                                getPercentOfNumber(restaurantDetails?.ratings[0]),
                                                                "%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            children: "4"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                                            flexGrow: 1,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BorderLinearProgress, {
                                                                variant: "determinate",
                                                                value: getPercentOfNumber(restaurantDetails?.ratings[1])
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            color: theme.palette.neutral[600],
                                                            children: [
                                                                getPercentOfNumber(restaurantDetails?.ratings[1]),
                                                                "%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            children: "3"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                                            flexGrow: 1,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BorderLinearProgress, {
                                                                variant: "determinate",
                                                                value: getPercentOfNumber(restaurantDetails?.ratings[2])
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            color: theme.palette.neutral[600],
                                                            children: [
                                                                getPercentOfNumber(restaurantDetails?.ratings[2]),
                                                                "%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            children: "2"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                                            flexGrow: 1,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BorderLinearProgress, {
                                                                variant: "determinate",
                                                                value: getPercentOfNumber(restaurantDetails?.ratings[3])
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            color: theme.palette.neutral[600],
                                                            children: [
                                                                getPercentOfNumber(restaurantDetails?.ratings[3]),
                                                                "%"
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            children: "1"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                                            flexGrow: 1,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BorderLinearProgress, {
                                                                variant: "determinate",
                                                                value: getPercentOfNumber(restaurantDetails?.ratings[4])
                                                            })
                                                        }),
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "14px",
                                                            color: theme.palette.neutral[600],
                                                            children: [
                                                                getPercentOfNumber(restaurantDetails?.ratings[4]),
                                                                "%"
                                                            ]
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        }),
                        data && data?.map((review)=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                container: true,
                                padding: "10px",
                                spacing: 2,
                                justifyContent: "space-between",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        item: true,
                                        xs: 8,
                                        sm: 8,
                                        md: 9.5,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                            gap: 0.4,
                                            justifyContent: "flex-end",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                    fontSize: "14px",
                                                    fontWeight: "500",
                                                    color: theme.palette.text.primary,
                                                    children: review?.customer_name
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_search_CustomRatings__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                                    readOnly: true,
                                                    ratingValue: review.rating,
                                                    fontSize: "1.2rem"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                    fontSize: "12px",
                                                    fontWeight: "400",
                                                    color: "text.secondary",
                                                    children: (0,utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__/* .getDateFormat */ .mh)(review.created_at)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_16__/* .ReadMore */ .y, {
                                                    color: theme.palette.neutral[600],
                                                    limits: "160",
                                                    children: review?.comment
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        item: true,
                                        xs: 4,
                                        sm: 4,
                                        md: 2.5,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                            justifyContent: "center",
                                            spacing: 0.5,
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            onClick: ()=>handleClick(review?.item),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    padding: "7px",
                                                    borderRadius: "8px",
                                                    sx: {
                                                        border: ".8px solid",
                                                        borderColor: (theme)=>theme.palette.neutral[300]
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                                        src: review.item_image_full_url,
                                                        objectFit: "cover",
                                                        height: "74px",
                                                        borderRadius: "8px"
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                    textAlign: "center",
                                                    color: theme.palette.neutral[600],
                                                    fontSize: "10px",
                                                    fontWeight: "400",
                                                    children: review.item_name
                                                })
                                            ]
                                        })
                                    }),
                                    review.reply ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                        item: true,
                                        xs: 12,
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                            sx: {
                                                background: theme.palette.neutral[300],
                                                padding: "13px",
                                                borderRadius: "9px"
                                            },
                                            children: [
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    direction: "row",
                                                    justifyContent: "space-between",
                                                    alignItems: "center",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "12px",
                                                            fontWeight: "500",
                                                            color: theme.palette.text.primary,
                                                            children: restaurantDetails?.name
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                                            fontSize: "10px",
                                                            fontWeight: "400",
                                                            color: "text.secondary",
                                                            children: (0,utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_11__/* .getDateFormat */ .mh)(review.updated_at)
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                                    mt: "5px",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_16__/* .ReadMore */ .y, {
                                                        color: theme.palette.text.secondary,
                                                        limits: "160",
                                                        children: review.reply
                                                    })
                                                })
                                            ]
                                        })
                                    }) : ""
                                ]
                            }, review?.id)),
                        isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                            marginTop: "2rem",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_DotSpin__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {})
                        })
                    ]
                })
            }),
            openModal && (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_26__/* .getCurrentModuleType */ .X)() === "food" && productData ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_food_details_foodDetail_modal_FoodDetailModal__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                product: productData,
                //imageBaseUrl={imageBaseUrl}
                open: openModal,
                handleModalClose: ()=>setOpenModal(false),
                setOpen: setOpenModal,
                addToWishlistHandler: addToWishlistHandler,
                removeFromWishlistHandler: removeFromWishlistHandler,
                isWishlisted: isWishlisted
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_cards_ModuleModal__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                open: openModal,
                handleModalClose: ()=>setOpenModal(false),
                configData: configData,
                productDetailsData: productData,
                addToWishlistHandler: addToWishlistHandler,
                removeFromWishlistHandler: removeFromWishlistHandler,
                isWishlisted: isWishlisted
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RestaurantReviewModal);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 643:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _assets_store_message_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(72523);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Campaign__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(26616);
/* harmony import */ var _mui_icons_material_Campaign__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Campaign__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53139);
/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4115);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react__WEBPACK_IMPORTED_MODULE_7__, _emotion_styled__WEBPACK_IMPORTED_MODULE_8__]);
([_emotion_react__WEBPACK_IMPORTED_MODULE_7__, _emotion_styled__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const BgBox = (0,_emotion_styled__WEBPACK_IMPORTED_MODULE_8__["default"])(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Box)(({ theme , src  })=>({
        backgroundImage: `url(${src})`,
        backgroundPosition: "center",
        backgroundColor: (0,_mui_system__WEBPACK_IMPORTED_MODULE_4__.alpha)(theme.palette.secondary.main, 0.1),
        borderRadius: "8px",
        backgroundRepeat: "no-repeat",
        backgroundSize: "contain",
        border: `1px solid ${theme.palette.secondary.main}`,
        // padding: "20px",
        display: "flex",
        alignItems: "center"
    }));
const normalStyle = {
    textAlign: "center"
};
const StoreCustomMessage = ({ storeAnnouncement  })=>{
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_7__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useMediaQuery)(theme.breakpoints.down("sm"));
    let duration = storeAnnouncement?.length * 24 / 100;
    const translateX = isSmall ? storeAnnouncement?.length * 3.5 : storeAnnouncement?.length * 1.3;
    const wordCount = isSmall ? storeAnnouncement?.length > 35 : storeAnnouncement?.length > 110;
    // const wordCount = true;
    const animatedStyle = {
        width: "90%",
        paddingInline: "10px",
        whiteSpace: "nowrap",
        animation: `scrollRightToLeft ${duration}s linear infinite`,
        position: "absolute",
        left: "95%",
        transformOrigin: "top left",
        "@keyframes scrollRightToLeft": {
            "0%": {
                transform: "translateX(0%)"
            },
            "100%": {
                transform: `translateX(-${translateX}%)`
            }
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        paddingBlock: "10px",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BgBox, {
            src: _assets_store_message_svg__WEBPACK_IMPORTED_MODULE_3__/* ["default"].src */ .Z.src,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                height: "60px",
                position: "relative",
                padding: "0px",
                justifyContent: "center",
                alignItems: "center",
                overflow: "hidden",
                width: "100%",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                    position: "absolute",
                    direction: "row",
                    spacing: {
                        xs: 1,
                        md: 2
                    },
                    sx: wordCount ? animatedStyle : normalStyle,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Campaign__WEBPACK_IMPORTED_MODULE_6___default()), {
                            color: "primary",
                            style: {
                                width: "30px",
                                height: "30px"
                            }
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                            fontSize: "16px",
                            fontWeight: "500",
                            textTransform: "capitalize",
                            children: storeAnnouncement
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StoreCustomMessage); // import { CustomStackFullWidth } from "../../styled-components/CustomStyles.style";
 // import CustomContainer from "../container";
 // import StoreMessageSvg from "./assets/store_message.svg";
 // import { Stack, alpha } from "@mui/system";
 // import { Box, Typography } from "@mui/material";
 // import CampaignIcon from '@mui/icons-material/Campaign';
 // import { useTheme } from '@emotion/react';
 // import styled from '@emotion/styled';
 // import { useEffect, useState } from "react";
 // const BgBox = styled(Box)(({ theme, src }) => ({
 //     backgroundImage: `url(${src})`,
 //     backgroundPosition: "center",
 //     backgroundColor: alpha(theme.palette.secondary.main, 0.1),
 //     borderRadius: "8px",
 //     backgroundRepeat: "no-repeat",
 //     backgroundSize: "contain",
 //     border: `1px solid ${theme.palette.secondary.main}`,
 //     display: "flex",
 //     alignItems: "center",
 // }));
 // // const animatedStyle = {
 // //     width: "90%",
 // //     paddingInline: "10px",
 // //     whiteSpace: "nowrap",
 // //     position: "absolute",
 // //     left: "95%",
 // //     transformOrigin: "top left",
 // //     animation: "scrollRightToLeft 5s linear infinite",
 // //     "@keyframes scrollRightToLeft": {
 // //         "0%": {
 // //             transform: "translateX(0%)",
 // //         },
 // //         "100%": {
 // //             transform: "translateX(-200%)",
 // //         }
 // //     },
 // // };
 // const animatedStyle = {
 // }
 // const normalStyle = {
 //     textAlign: "center"
 // };
 // const StoreCustomMessage = ({ storeAnnouncement }) => {
 //     // const storeAnnouncement = "aaaaaaaaaa"
 //     // const storeAnnouncement = "here are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable"
 //     const theme = useTheme();
 //     const wordCount = storeAnnouncement?.length > 110 ? true : false;
 //     const [shouldAnimate, setShouldAnimate] = useState(wordCount);
 //     useEffect(() => {
 //         if (shouldAnimate) {
 //             const animationDuration = 35000; // 25 seconds
 //             setTimeout(() => {
 //                 setShouldAnimate(false); // Stop the animation after the specified time
 //             }, animationDuration);
 //         }
 //     }, [shouldAnimate]);
 //     return (
 //         <CustomStackFullWidth padding="20px">
 //             <BgBox src={StoreMessageSvg.src}>
 //                 <Stack
 //                     height="60px"
 //                     position="relative"
 //                     padding="0px"
 //                     justifyContent="center"
 //                     alignItems="center"
 //                     overflow="hidden"
 //                     width="100%"
 //                 >
 //                     <Stack
 //                         position="absolute"
 //                         direction="row"
 //                         spacing={{ xs: 1, md: 2 }}
 //                         // sx={wordCount ? animatedStyle : normalStyle}
 //                         sx={{
 //                             width: "100%",
 //                             whiteSpace: "nowrap",
 //                             overflowX: "auto",
 //                             cursor: "grab",
 //                             scrollbarWidth: "none",
 //                             "-ms-overflow-style": "none",
 //                             "&::-webkit-scrollbar": {
 //                                 display: "none"
 //                             }
 //                         }}
 //                     >
 //                         <CampaignIcon color="primary" style={{ width: "30px", height: "30px" }} />
 //                         <Typography fontSize="16px" fontWeight="500" textTransform="capitalize">
 //                             {storeAnnouncement}
 //                         </Typography>
 //                     </Stack>
 //                 </Stack>
 //             </BgBox>
 //         </CustomStackFullWidth>
 //     );
 // };
 // export default StoreCustomMessage;

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 65187:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6910);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Directions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(88566);
/* harmony import */ var _mui_icons_material_Directions__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Directions__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(38096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(61598);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(88278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(86201);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(57987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(80697);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(93706);
/* harmony import */ var helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(89113);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(90603);
/* harmony import */ var helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(42604);
/* harmony import */ var _redux_slices_wishList__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(64134);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(45269);
/* harmony import */ var utils_toasterMessages__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(70557);
/* harmony import */ var _closed_now_ClosedNowScheduleWise__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(18293);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(58861);
/* harmony import */ var _CustomMultipleRatings__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(96117);
/* harmony import */ var _Map_location_view_LocationViewOnMap__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(26148);
/* harmony import */ var _product_details_product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(53357);
/* harmony import */ var _typographies_H1__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(74485);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(81261);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_10__, react_i18next__WEBPACK_IMPORTED_MODULE_11__, api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_13__, api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_14__, _closed_now_ClosedNowScheduleWise__WEBPACK_IMPORTED_MODULE_19__, _CustomMultipleRatings__WEBPACK_IMPORTED_MODULE_21__, _Map_location_view_LocationViewOnMap__WEBPACK_IMPORTED_MODULE_22__, _typographies_H1__WEBPACK_IMPORTED_MODULE_24__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_27__]);
([react_hot_toast__WEBPACK_IMPORTED_MODULE_10__, react_i18next__WEBPACK_IMPORTED_MODULE_11__, api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_13__, api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_14__, _closed_now_ClosedNowScheduleWise__WEBPACK_IMPORTED_MODULE_19__, _CustomMultipleRatings__WEBPACK_IMPORTED_MODULE_21__, _Map_location_view_LocationViewOnMap__WEBPACK_IMPORTED_MODULE_22__, _typographies_H1__WEBPACK_IMPORTED_MODULE_24__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_27__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






























const ContentWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu)(({ theme  })=>({
        position: "relative",
        height: "250px",
        width: "50%"
    }));
const ImageWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Box)(({ theme , smallScreen  })=>({
        position: "relative",
        maxWidth: "100px",
        width: "100%",
        height: "100px",
        [theme.breakpoints.down("lg")]: {
            height: "100px",
            maxWidth: "110px"
        },
        [theme.breakpoints.down("md")]: {
            //height: "120px",
            maxWidth: "110px"
        },
        [theme.breakpoints.down("sm")]: {
            height: smallScreen === "true" ? "100px" : "65px",
            maxWidth: smallScreen !== "true" && "85px",
            width: smallScreen === "true" && "100px"
        }
    }));
const PrimaryWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Box)(({ theme , borderradius  })=>({
        backgroundColor: theme.palette.primary.main,
        color: theme.palette.whiteContainer.main,
        padding: "8px",
        borderRadius: borderradius,
        cursor: "pointer"
    }));
const ContentBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Box)(({ theme , borderradius  })=>({
        width: "100%",
        height: "100%",
        position: "absolute",
        top: 0,
        left: 0,
        color: theme.palette.whiteContainer.main,
        borderRadius: "5px"
    }));
const initialState = {
    viewMap: false
};
const reducer = (state, action)=>{
    switch(action.type){
        case "setViewMap":
            return {
                ...state,
                viewMap: action.payload
            };
        default:
            return state;
    }
};
const Top = (props)=>{
    const { bannerCover , storeDetails , configData , logo , storeShare , bannersData , isLoading , setOpenReviewModal  } = props;
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_9__.useReducer)(reducer, initialState);
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
    const dispatchRedux = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useDispatch)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)(theme.breakpoints.down("md"));
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_11__.useTranslation)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_26__.useRouter)();
    const ACTION = {
        setViewMap: "setViewMap"
    };
    const settings = {
        dots: false,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        speed: 800,
        autoplaySpeed: 4000,
        cssEase: "linear",
        responsive: [
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    const openMapHandler = ()=>{
        dispatch({
            type: ACTION.setViewMap,
            payload: true
        });
    };
    const { wishLists  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_12__.useSelector)((state)=>state.wishList);
    let token = undefined;
    if (false) {}
    const { mutate: addFavoriteMutation  } = (0,api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_13__/* .useAddStoreToWishlist */ .v)();
    const addToFavorite = ()=>{
        if (token) {
            addFavoriteMutation(storeDetails?.id, {
                onSuccess: (response)=>{
                    if (response) {
                        dispatchRedux((0,_redux_slices_wishList__WEBPACK_IMPORTED_MODULE_17__/* .addWishListStore */ .KO)(storeDetails));
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].success(response?.message);
                    }
                },
                onError: (error)=>{
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].error(error.response.data.message);
                }
            });
        } else react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].error(t(utils_toasterMessages__WEBPACK_IMPORTED_MODULE_28__/* .not_logged_in_message */ .XO));
    };
    const isInWishList = (id)=>{
        return !!wishLists?.store?.find((wishStore)=>wishStore.id === storeDetails?.id);
    };
    const onSuccessHandlerForDelete = (res)=>{
        dispatchRedux((0,_redux_slices_wishList__WEBPACK_IMPORTED_MODULE_17__/* .removeWishListStore */ .$X)(storeDetails?.id));
        react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].success(res.message, {
            id: "wishlist"
        });
    };
    const { mutate  } = (0,api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_14__/* .useWishListStoreDelete */ .K)();
    const deleteWishlistStore = (id)=>{
        mutate(id, {
            onSuccess: onSuccessHandlerForDelete,
            onError: (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_10__["default"].error(error.response.data.message);
            }
        });
    };
    const getModuleWiseBG = ()=>{
        if ((0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_29__/* .getCurrentModuleType */ .X)()) {
            switch((0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_29__/* .getCurrentModuleType */ .X)()){
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.GROCERY */ .J.GROCERY:
                    return {
                        bgColor: theme.palette.primary.main
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.PHARMACY */ .J.PHARMACY:
                    return {
                        bgColor: theme.palette.primary.main
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.ECOMMERCE */ .J.ECOMMERCE:
                    return {
                        bgColor: theme.palette.primary.main
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.FOOD */ .J.FOOD:
                    return {
                        bgColor: theme.palette.primary.main
                    };
            }
        } else {
            switch(storeShare?.moduleType){
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.GROCERY */ .J.GROCERY:
                    return {
                        bgColor: theme.palette.primary.main
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.PHARMACY */ .J.PHARMACY:
                    return {
                        bgColor: theme.palette.info.custom1
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.ECOMMERCE */ .J.ECOMMERCE:
                    return {
                        bgColor: theme.palette.info.blue
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.FOOD */ .J.FOOD:
                    return {
                        bgColor: theme.palette.moduleTheme.food
                    };
            }
        }
    };
    const handleBannerClick = (link)=>{
        if (link) {
            router.push(link);
        }
    };
    const content = ()=>{
        if (isSmall) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomStackFullWidth */ .Xw, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                        sx: {
                            position: "relative",
                            height: "122px"
                        },
                        children: [
                            bannersData?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_5___default()), {
                                ...settings,
                                children: bannersData?.map((banner)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                        onClick: ()=>handleBannerClick(banner?.default_link),
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                            src: banner?.image_full_url,
                                            width: "100%",
                                            height: "122px",
                                            objectFit: "cover",
                                            borderRadius: "10px"
                                        })
                                    }, banner?.id);
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                src: bannerCover,
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                                borderRadius: "10px"
                            }),
                            " "
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomStackFullWidth */ .Xw, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                sx: {
                                    backdropFilter: "blur(10px)",
                                    zIndex: 0
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                    sx: {
                                        backgroundColor: getModuleWiseBG()?.bgColor,
                                        zIndex: 999,
                                        position: "relative"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                        sx: {
                                            background: " rgba(255, 255, 255, 0.1)",
                                            boxShadow: "0px 2px 30px 2px rgba(0, 0, 0, 0.08)",
                                            padding: "15px 20px"
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                            container: true,
                                            spacing: 3,
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                    item: true,
                                                    xs: 4,
                                                    sm: 2,
                                                    sx: {
                                                        mt: "22px",
                                                        mb: "30px",
                                                        position: "relative"
                                                    },
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                                        sx: {
                                                            position: "absolute",
                                                            top: -52
                                                        },
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ImageWrapper, {
                                                            smallScreen: "true",
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                                    src: logo,
                                                                    width: "100%",
                                                                    height: "100%",
                                                                    objectFit: "cover",
                                                                    borderRadius: "50%"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_closed_now_ClosedNowScheduleWise__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                                                    active: storeDetails?.active,
                                                                    schedules: storeDetails?.schedules,
                                                                    borderRadius: "50%"
                                                                })
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                    item: true,
                                                    xs: 8,
                                                    sm: 10,
                                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomStackFullWidth */ .Xw, {
                                                        sx: {
                                                            color: "whiteContainer.main"
                                                        },
                                                        spacing: 1,
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_H1__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                                                text: storeDetails?.name,
                                                                textAlign: "flex-start"
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                                direction: "row",
                                                                alignItems: "center",
                                                                spacing: 1,
                                                                children: [
                                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                                        direction: "row",
                                                                        alignItems: "center",
                                                                        justifyContent: "center",
                                                                        spacing: 0.4,
                                                                        children: [
                                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomMultipleRatings__WEBPACK_IMPORTED_MODULE_21__/* .StyledRating */ .p, {
                                                                                name: "read-only",
                                                                                value: storeDetails?.avg_rating ? storeDetails.avg_rating : 5,
                                                                                readOnly: true,
                                                                                size: "small",
                                                                                hasRating: "true"
                                                                            }),
                                                                            storeDetails?.rating_count !== 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                                children: `(${storeDetails?.avg_rating})`
                                                                            }) : null
                                                                        ]
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        sx: {
                                                                            color: (theme)=>theme.palette.neutral[600]
                                                                        },
                                                                        children: "|"
                                                                    }),
                                                                    storeDetails?.rating_count !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        textDecoration: "underline",
                                                                        fontWeight: "700",
                                                                        lineHeight: "16.15px",
                                                                        sx: {
                                                                            fontSize: {
                                                                                xs: "10px",
                                                                                sm: "14px"
                                                                            },
                                                                            cursor: "pointer"
                                                                        },
                                                                        onClick: ()=>setOpenReviewModal(true),
                                                                        children: [
                                                                            storeDetails?.reviews_comments_count,
                                                                            " ",
                                                                            t("Reviews")
                                                                        ]
                                                                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: {
                                                                            xs: "11px",
                                                                            md: "13.5px"
                                                                        },
                                                                        sx: {
                                                                            textDecoration: "underLine"
                                                                        },
                                                                        children: t("No reviews yet")
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                textDecoration: "underline",
                                                                fontWeight: "400",
                                                                lineHeight: "16.15px",
                                                                sx: {
                                                                    fontSize: {
                                                                        xs: "12px",
                                                                        sm: "14px"
                                                                    }
                                                                },
                                                                children: storeDetails?.address
                                                            })
                                                        ]
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                sx: {
                                    // backdropFilter: "blur(10px)",
                                    backgroundColor: getModuleWiseBG()?.bgColor,
                                    opacity: "0.9",
                                    padding: "13.5px 25px",
                                    color: "whiteContainer.main"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                    direction: "row",
                                    alignItems: "center",
                                    spacing: {
                                        xs: 4,
                                        sm: 3,
                                        md: 5
                                    },
                                    children: [
                                        storeDetails?.positive_rating !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                            alignItems: "flex-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    textAlign: "center",
                                                    variant: "h5",
                                                    sx: {
                                                        fontSize: {
                                                            xs: "14px",
                                                            sm: "22px",
                                                            md: "22px"
                                                        }
                                                    },
                                                    children: storeDetails?.positive_rating.toFixed(configData?.digit_after_decimal_point)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                    direction: "row",
                                                    alignItems: "center",
                                                    spacing: 0.3,
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                        noWrap: true,
                                                        sx: {
                                                            fontSize: {
                                                                xs: "10px",
                                                                sm: "inherit"
                                                            }
                                                        },
                                                        children: t("Positive Review")
                                                    })
                                                })
                                            ]
                                        }) : null,
                                        storeDetails?.minimum_order !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                            alignItems: "flex-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    variant: "h5",
                                                    sx: {
                                                        fontSize: {
                                                            xs: "16px",
                                                            sm: "22px",
                                                            md: "22px"
                                                        }
                                                    },
                                                    children: (0,helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_15__/* .getAmountWithSign */ .B9)(storeDetails?.minimum_order)
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    noWrap: true,
                                                    sx: {
                                                        fontSize: {
                                                            xs: "10px",
                                                            sm: "inherit"
                                                        }
                                                    },
                                                    children: t("Minimum Order Value")
                                                })
                                            ]
                                        }) : null,
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                            alignItems: "flex-start",
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    variant: "h5",
                                                    sx: {
                                                        fontSize: {
                                                            xs: "16px",
                                                            sm: "22px",
                                                            md: "22px"
                                                        }
                                                    },
                                                    children: storeDetails?.delivery_time
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                    noWrap: true,
                                                    sx: {
                                                        fontSize: {
                                                            xs: "10px",
                                                            sm: "inherit"
                                                        }
                                                    },
                                                    children: t("Delivery Time")
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            });
        } else {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContentWrapper, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                src: bannerCover,
                                width: "100%",
                                height: "100%",
                                objectFit: "cover",
                                borderRadius: "10px"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContentBox, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                        sx: {
                                            borderTopLeftRadius: "10px",
                                            backgroundColor: getModuleWiseBG()?.bgColor
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                            sx: {
                                                borderTopRightRadius: "10px",
                                                borderTopLeftRadius: "10px",
                                                background: " rgba(255, 255, 255, 0.1)",
                                                boxShadow: "0px 2px 30px 2px rgba(0, 0, 0, 0.08)",
                                                padding: "10px 25px"
                                            },
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                container: true,
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                        item: true,
                                                        xs: 3,
                                                        md: 2.5,
                                                        sx: {
                                                            mt: "22px",
                                                            mb: "30px"
                                                        },
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ImageWrapper, {
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                                                    src: logo,
                                                                    width: "100%",
                                                                    height: "100%",
                                                                    objectFit: "cover",
                                                                    borderRadius: "10px"
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_closed_now_ClosedNowScheduleWise__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                                                    active: storeDetails?.active,
                                                                    schedules: storeDetails?.schedules,
                                                                    borderRadius: "50%"
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                        item: true,
                                                        xs: 7,
                                                        md: 7.5,
                                                        alignSelf: "center",
                                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomStackFullWidth */ .Xw, {
                                                            spacing: 1,
                                                            children: [
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_H1__WEBPACK_IMPORTED_MODULE_24__/* ["default"] */ .Z, {
                                                                    text: storeDetails?.name,
                                                                    textAlign: "flex-start"
                                                                }),
                                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                                    direction: "row",
                                                                    alignItems: "center",
                                                                    spacing: 1,
                                                                    children: [
                                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                                            direction: "row",
                                                                            alignItems: "center",
                                                                            justifyContent: "center",
                                                                            spacing: 0.4,
                                                                            children: [
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomMultipleRatings__WEBPACK_IMPORTED_MODULE_21__/* .StyledRating */ .p, {
                                                                                    sx: {
                                                                                        color: storeDetails?.avg_rating === 0 ? (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.alpha)(theme.palette.whiteContainer.main, 0.6) : "warning.dark"
                                                                                    },
                                                                                    name: "read-only",
                                                                                    value: storeDetails?.avg_rating ? storeDetails?.avg_rating : 5,
                                                                                    readOnly: true,
                                                                                    size: "small",
                                                                                    hasRating: storeDetails?.avg_rating === 0 ? true : false
                                                                                }),
                                                                                storeDetails?.rating_count !== 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                                    children: `(${storeDetails?.avg_rating})`
                                                                                }) : null
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                            sx: {
                                                                                color: (theme)=>theme.palette.neutral[600]
                                                                            },
                                                                            children: "|"
                                                                        }),
                                                                        storeDetails?.rating_count !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                            onClick: ()=>setOpenReviewModal(true),
                                                                            fontSize: "14px",
                                                                            sx: {
                                                                                textDecoration: "underLine",
                                                                                cursor: "pointer"
                                                                            },
                                                                            fontWeight: "700",
                                                                            lineHeight: "16.15px",
                                                                            component: "span",
                                                                            children: [
                                                                                storeDetails?.reviews_comments_count,
                                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                                    component: "span",
                                                                                    fontSize: "13px",
                                                                                    fontWeight: "400",
                                                                                    children: t(" Reviews")
                                                                                })
                                                                            ]
                                                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                            fontSize: "13.5px",
                                                                            children: t("No reviews yet")
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                    fontSize: "14px",
                                                                    textDecoration: "underline",
                                                                    fontWeight: "400",
                                                                    lineHeight: "16.15px",
                                                                    children: storeDetails?.address
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                                                        item: true,
                                                        xs: 2,
                                                        align: "right",
                                                        children: [
                                                            !isInWishList(storeDetails?.id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                                                                title: "Add to wishlist",
                                                                arrow: true,
                                                                placement: "bottom",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_23__/* .RoundedIconButton */ .n, {
                                                                    onClick: addToFavorite,
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_2___default()), {
                                                                        color: "primary"
                                                                    })
                                                                })
                                                            }),
                                                            isInWishList(storeDetails?.id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                                                                title: "Remove from wishlist",
                                                                arrow: true,
                                                                placement: "bottom",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_23__/* .RoundedIconButton */ .n, {
                                                                    onClick: ()=>deleteWishlistStore(storeDetails?.id),
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default()), {
                                                                        color: "primary"
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Box, {
                                                                mt: "10px",
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                                                                    title: "Location",
                                                                    arrow: true,
                                                                    placement: "bottom",
                                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_23__/* .RoundedIconButton */ .n, {
                                                                        onClick: openMapHandler,
                                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Directions__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                                            color: "primary"
                                                                        })
                                                                    })
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomBoxFullWidth */ .uu, {
                                        sx: {
                                            backgroundColor: getModuleWiseBG()?.bgColor,
                                            opacity: "0.9",
                                            padding: "13.5px 25px",
                                            borderBottomLeftRadius: "10px"
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                            direction: "row",
                                            alignItems: "center",
                                            spacing: {
                                                xs: 2,
                                                sm: 3,
                                                md: 5
                                            },
                                            children: [
                                                storeDetails?.positive_rating !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                    alignItems: "flex-start",
                                                    children: [
                                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                            textAlign: "center",
                                                            variant: "h5",
                                                            sx: {
                                                                fontSize: {
                                                                    xs: "14px",
                                                                    sm: "22px",
                                                                    md: "22px"
                                                                }
                                                            },
                                                            children: [
                                                                storeDetails?.positive_rating.toFixed(0),
                                                                "%"
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                            direction: "row",
                                                            alignItems: "center",
                                                            spacing: 0.3,
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                children: t("Positive Review")
                                                            })
                                                        })
                                                    ]
                                                }) : null,
                                                storeDetails?.minimum_order !== 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                    alignItems: "flex-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                            variant: "h5",
                                                            sx: {
                                                                fontSize: {
                                                                    xs: "16px",
                                                                    sm: "22px",
                                                                    md: "22px"
                                                                }
                                                            },
                                                            children: (0,helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_15__/* .getAmountWithSign */ .B9)(storeDetails?.minimum_order)
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                            children: t("Minimum Order Value")
                                                        })
                                                    ]
                                                }) : null,
                                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                                    alignItems: "flex-start",
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                            variant: "h5",
                                                            sx: {
                                                                fontSize: {
                                                                    xs: "16px",
                                                                    sm: "22px",
                                                                    md: "22px"
                                                                }
                                                            },
                                                            children: storeDetails?.delivery_time
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                            children: t("Delivery Time")
                                                        })
                                                    ]
                                                })
                                            ]
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                        width: "50%",
                        children: !isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: bannersData?.length ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_5___default()), {
                                ...settings,
                                children: bannersData?.map((banner)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                                        onClick: ()=>handleBannerClick(banner?.default_link),
                                        sx: {
                                            cursor: "pointer",
                                            width: "100%",
                                            borderRadius: "10px"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                            src: banner?.image_full_url,
                                            width: "100%",
                                            height: "251px",
                                            objectFit: "cover"
                                        })
                                    }, banner?.id);
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                src: bannerCover,
                                width: "100%",
                                height: "250px",
                                objectFit: "cover"
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                            width: "100%",
                            height: "100%",
                            variant: "rectangular"
                        })
                    })
                ]
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            content(),
            state.viewMap && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Map_location_view_LocationViewOnMap__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                open: state.viewMap,
                handleClose: ()=>dispatch({
                        type: ACTION.setViewMap,
                        payload: false
                    }),
                latitude: storeDetails?.latitude,
                longitude: storeDetails?.longitude,
                address: storeDetails?.address,
                storeDetails: storeDetails
            })
        ]
    });
};
Top.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Top);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1516:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(90603);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _Prescription__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(63566);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(28332);
/* harmony import */ var _Top__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65187);
/* harmony import */ var _middle_section__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(34538);
/* harmony import */ var _popular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(34361);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _api_manage_hooks_react_query_store_useGetStoreBanners__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(20751);
/* harmony import */ var _StoreCustomMessage__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(643);
/* harmony import */ var _api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(38579);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var redux_slices_utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(67493);
/* harmony import */ var components_modal__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(86390);
/* harmony import */ var components_store_details_ReviewModal__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(65309);
/* harmony import */ var api_manage_hooks_custom_hooks_useScrollToTop__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(59599);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Prescription__WEBPACK_IMPORTED_MODULE_4__, _Top__WEBPACK_IMPORTED_MODULE_6__, _middle_section__WEBPACK_IMPORTED_MODULE_7__, _popular__WEBPACK_IMPORTED_MODULE_8__, _api_manage_hooks_react_query_store_useGetStoreBanners__WEBPACK_IMPORTED_MODULE_10__, _StoreCustomMessage__WEBPACK_IMPORTED_MODULE_11__, _api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_12__, components_modal__WEBPACK_IMPORTED_MODULE_15__, components_store_details_ReviewModal__WEBPACK_IMPORTED_MODULE_16__]);
([_Prescription__WEBPACK_IMPORTED_MODULE_4__, _Top__WEBPACK_IMPORTED_MODULE_6__, _middle_section__WEBPACK_IMPORTED_MODULE_7__, _popular__WEBPACK_IMPORTED_MODULE_8__, _api_manage_hooks_react_query_store_useGetStoreBanners__WEBPACK_IMPORTED_MODULE_10__, _StoreCustomMessage__WEBPACK_IMPORTED_MODULE_11__, _api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_12__, components_modal__WEBPACK_IMPORTED_MODULE_15__, components_store_details_ReviewModal__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const StoreDetails = ({ storeDetails , configData  })=>{
    (0,api_manage_hooks_custom_hooks_useScrollToTop__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useDispatch)();
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [openReviewModal, setOpenReviewModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const bannerCover = storeDetails?.cover_photo_full_url;
    const ownCategories = storeDetails?.category_ids;
    const logo = storeDetails?.logo_full_url;
    const [rerender, setRerender] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.down("sm"));
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const storeShare = {
        moduleId: router.query.module_id,
        moduleType: router.query.module_type,
        storeZoneId: [
            parseInt(router.query.store_zone_id)
        ]
    };
    const { data: bannersData , refetch , isLoading  } = (0,_api_manage_hooks_react_query_store_useGetStoreBanners__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(storeDetails?.id);
    const { data: moduleDataFromApi , refetch: refetchModule  } = (0,_api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        refetchModule();
        refetch();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (moduleDataFromApi) {
            moduleDataFromApi?.filter((item)=>{
                if (storeShare.moduleId == item.id) {
                    localStorage.setItem("module", JSON.stringify(item));
                    dispatch((0,redux_slices_utils__WEBPACK_IMPORTED_MODULE_14__/* .setSelectedModule */ .$w)(item));
                }
            });
        }
    }, [
        moduleDataFromApi
    ]);
    let zoneid = undefined;
    if (false) {}
    const layoutHandler = ()=>{
        if (isSmall) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                spacing: {
                    xs: 1,
                    sm: 2,
                    md: 3
                },
                children: [
                    storeDetails?.announcement === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StoreCustomMessage__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                        storeAnnouncement: storeDetails?.announcement_message
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Top__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        bannerCover: bannerCover,
                        storeDetails: storeDetails,
                        configData: configData,
                        logo: logo,
                        isSmall: isSmall,
                        storeShare: storeShare,
                        bannersData: bannersData,
                        isLoading: isLoading,
                        setOpenReviewModal: setOpenReviewModal
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popular__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                        id: storeDetails?.id,
                        storeShare: storeShare
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                            spacing: 3,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_middle_section__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                                    ownCategories: ownCategories,
                                    storeDetails: storeDetails,
                                    isSmall: isSmall,
                                    storeShare: storeShare,
                                    setExpanded: setExpanded
                                }),
                                configData?.prescription_order_status && storeDetails?.prescription_order && (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_18__/* .getCurrentModuleType */ .X)() === "pharmacy" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Prescription__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                    expanded: expanded,
                                    storeId: storeDetails?.id
                                })
                            ]
                        })
                    })
                ]
            });
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 3,
                    children: [
                        storeDetails?.announcement === 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StoreCustomMessage__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            storeAnnouncement: storeDetails?.announcement_message
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Top__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            bannerCover: bannerCover,
                            storeDetails: storeDetails,
                            configData: configData,
                            logo: logo,
                            isSmall: isSmall,
                            storeShare: storeShare,
                            bannersData: bannersData,
                            setOpenReviewModal: setOpenReviewModal
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_popular__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            id: storeDetails?.id,
                            storeShare: storeShare
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_middle_section__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .ZP, {
                            ownCategories: ownCategories,
                            storeDetails: storeDetails,
                            isSmall: isSmall,
                            storeShare: storeShare,
                            setExpanded: setExpanded
                        }),
                        configData?.prescription_order_status && storeDetails?.prescription_order && (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_18__/* .getCurrentModuleType */ .X)() === "pharmacy" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Prescription__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            expanded: expanded,
                            storeId: storeDetails?.id
                        })
                    ]
                })
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                sx: {
                    minHeight: "100vh"
                },
                spacing: 3,
                children: layoutHandler()
            }, rerender),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_modal__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                openModal: openReviewModal,
                handleClose: ()=>setOpenReviewModal(false),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_store_details_ReviewModal__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                    product_avg_rating: storeDetails?.avg_rating,
                    reviews_comments_count: storeDetails?.reviews_comments_count,
                    rating_count: storeDetails?.rating_count,
                    id: storeDetails?.id,
                    restaurantDetails: storeDetails,
                    configData: configData
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StoreDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98697:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export CustomPaperBox */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _srollbar__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92391);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
/* harmony import */ var api_manage_hooks_react_query_all_category_all_categorys__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(40291);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(31011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(78315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(45269);
/* harmony import */ var _CustomDivider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(35740);
/* harmony import */ var _search_CustomSlider__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(11629);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53139);
/* harmony import */ var _CheckboxWithChild__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(24275);
/* harmony import */ var _sort_HighToLow__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(87296);
/* harmony import */ var _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(95785);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(90603);
/* harmony import */ var helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(42604);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_17__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__, api_manage_hooks_react_query_all_category_all_categorys__WEBPACK_IMPORTED_MODULE_6__, _emotion_react__WEBPACK_IMPORTED_MODULE_12__, _CheckboxWithChild__WEBPACK_IMPORTED_MODULE_13__, _sort_HighToLow__WEBPACK_IMPORTED_MODULE_14__, _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_5__, api_manage_hooks_react_query_all_category_all_categorys__WEBPACK_IMPORTED_MODULE_6__, _emotion_react__WEBPACK_IMPORTED_MODULE_12__, _CheckboxWithChild__WEBPACK_IMPORTED_MODULE_13__, _sort_HighToLow__WEBPACK_IMPORTED_MODULE_14__, _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



















const CustomPaperBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box)(({ theme  })=>({
        backgroundColor: "paper.default",
        boxShadow: "0px 4px 15px rgba(0, 0, 0, 0.05)",
        borderRadius: "10px",
        p: "1rem",
        color: theme.palette.neutral[900]
    }));
const initialState = {
    categories: [],
    isSelected: 0
};
const Dummy = [
    {
        name: "Fruits & Vegetables",
        child: [
            {
                name: "Fresh Fruits"
            },
            {
                name: "Fresh Vegetables"
            },
            {
                name: "Dates "
            }
        ]
    },
    {
        name: "Fruits & Vegetables",
        child: [
            {
                name: "Fresh Fruits"
            },
            {
                name: "Fresh Vegetables"
            },
            {
                name: "Dates "
            }
        ]
    },
    {
        name: "Fruits & Vegetables",
        child: [
            {
                name: "Fresh Fruits"
            },
            {
                name: "Fresh Vegetables"
            },
            {
                name: "Dates "
            }
        ]
    },
    {
        name: "Fruits & Vegetables",
        child: [
            {
                name: "Fresh Fruits"
            },
            {
                name: "Fresh Vegetables"
            },
            {
                name: "Dates "
            }
        ]
    },
    {
        name: "Fruits & Vegetables",
        child: [
            {
                name: "Fresh Fruits"
            },
            {
                name: "Fresh Vegetables"
            },
            {
                name: "Dates "
            }
        ]
    }
];
const reducer = (state, action)=>{
    switch(action.type){
        case "setCategories":
            return {
                ...state,
                categories: action.payload
            };
        case "setIsSelected":
            return {
                ...state,
                isSelected: action.payload
            };
        default:
            return state;
    }
};
const ACTION = {
    setCategories: "setCategories",
    setIsSelected: "setIsSelected"
};
const Sidebar = (props)=>{
    const { open , onClose , ownCategories , handleCategoryId , handleChangePrice , priceFilterRange , storesApiLoading , searchIsLoading , storeId , handleSortBy , sortBy , isSmall , selectedCategories , selected , handleSelection , checkState , setCheckState  } = props;
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(reducer, initialState);
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_17__.useSelector)((state)=>state.configData);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_12__.useTheme)();
    const lgUp = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)((theme)=>theme.breakpoints.up("lg"), {
        noSsr: true
    });
    const [minMax, setMinMax] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([
        0,
        0
    ]);
    const handleOnSuccess = (res)=>{
        if (ownCategories?.length > 0 && res?.data?.length > 0) {
            const common = res?.data?.filter((item)=>ownCategories.some((oItem)=>oItem === item?.id));
            dispatch({
                type: ACTION.setCategories,
                payload: common
            });
        }
    };
    const searchKey = "";
    const queryKey = "stores-categories";
    const { refetch , isFetched , isFetching , isLoading  } = (0,api_manage_hooks_react_query_all_category_all_categorys__WEBPACK_IMPORTED_MODULE_6__/* .useGetCategories */ .P)(searchKey, handleOnSuccess, queryKey);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        refetch();
    }, [
        storeId
    ]);
    // useEffect(() => {
    //   handleFilter();
    // }, [minMax]);
    const handleCategoriesClick = (id)=>{
        dispatch({
            type: ACTION.setIsSelected,
            payload: id
        });
        handleCategoryId?.(id);
    };
    const handleMinMax = (value)=>{
        if (value[0] === 0) {
            value[0] = priceFilterRange?.[0]?.min_price;
        }
        setMinMax(value);
        handleChangePrice(value);
    };
    const handleFilter = ()=>{
        handleChangePrice(minMax);
    };
    const categoriesCheckBoxHandler = (data)=>{
        handleCategoryId?.(data);
    };
    const content = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
        sx: {
            padding: "1rem"
        },
        spacing: 2,
        children: [
            isSmall && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomBoxFullWidth */ .uu, {
                sx: {
                    mt: "3rem"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sort_HighToLow__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                    handleSortBy: handleSortBy,
                    sortBy: sortBy
                })
            }),
            state.categories?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                fontWeight: "bold",
                color: theme.palette.neutral[1000],
                children: t("Categories")
            }),
            state.categories?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomPaperBox, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
                    p: "1rem",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_srollbar__WEBPACK_IMPORTED_MODULE_2__/* .Scrollbar */ .L, {
                        style: {
                            maxHeight: "300px"
                        },
                        scrollbarMinSize: 5,
                        children: state.categories?.length > 0 && state.categories?.map((item, index)=>{
                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CheckboxWithChild__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                item: item,
                                checkHandler: categoriesCheckBoxHandler,
                                selectedItems: selectedCategories
                            }, index);
                        })
                    })
                })
            }),
            isFetching && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomPaperBox, {
                children: [
                    ...Array(4)
                ].map((item, index)=>{
                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_7___default()), {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_8___default()), {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                variant: "rectangle",
                                height: "10px",
                                width: "100%"
                            })
                        })
                    }, index);
                })
            }),
            (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_18__/* .getCurrentModuleType */ .X)() === helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_16__/* .ModuleTypes.FOOD */ .J.FOOD && isSmall && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                selected: state.type,
                handleSelection: handleSelection,
                checkState: checkState,
                setCheckState: setCheckState
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
                spacing: 2,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                        fontWeight: "bold",
                        color: theme.palette.neutral[1000],
                        children: t("Price Range")
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomPaperBox, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
                            p: "1rem",
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomDivider__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {}),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_search_CustomSlider__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                                    handleChangePrice: handleMinMax,
                                    minMax: minMax,
                                    priceFilterRange: priceFilterRange?.length > 0 && priceFilterRange[0],
                                    store: true
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
                                    direction: "row",
                                    alignItems: "center",
                                    spacing: 2,
                                    pt: ".5rem",
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField, {
                                            sx: {
                                                backgroundColor: (theme)=>theme.palette.neutral[300]
                                            },
                                            variant: "outlined",
                                            value: minMax[0] <= 0 ? "" : minMax[0],
                                            onChange: (e)=>{
                                                if (e.target.value >= 0) {
                                                    setMinMax((prevState)=>[
                                                            parseFloat(e.target.value),
                                                            prevState[1]
                                                        ]);
                                                }
                                            },
                                            label: t("Min"),
                                            InputProps: {
                                                readOnly: true,
                                                startAdornment: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.InputAdornment, {
                                                    position: "start",
                                                    children: configData?.currency_symbol
                                                })
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                            children: "-"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.TextField, {
                                            sx: {
                                                backgroundColor: (theme)=>theme.palette.neutral[300]
                                            },
                                            variant: "outlined",
                                            value: minMax[1] === 0 ? "" : minMax[1],
                                            onChange: (e)=>{
                                                if (e.target.value >= 0) {
                                                    setMinMax((prevState)=>[
                                                            prevState[0],
                                                            e.target.value
                                                        ]);
                                                }
                                            },
                                            label: t("Max"),
                                            InputProps: {
                                                readOnly: true,
                                                startAdornment: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.InputAdornment, {
                                                    position: "start",
                                                    children: configData?.currency_symbol
                                                })
                                            }
                                        })
                                    ]
                                })
                            ]
                        }, "12")
                    })
                ]
            })
        ]
    });
    if (lgUp) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
            sx: {
                //backgroundColor: "paper.default",
                width: "100%",
                py: "3px",
                height: "100%"
            },
            children: content
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Drawer, {
        anchor: "right",
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                backgroundColor: "paper.default",
                width: 280
            }
        },
        sx: {
            zIndex: (theme)=>theme.zIndex.appBar + 100
        },
        variant: "temporary",
        children: content
    });
};
Sidebar.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(Sidebar));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 34538:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports handleShimmerProducts, getDiscountedPriceAmount, getHighToLow, getLowToHigh */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _custom_search_CustomSearch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33000);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _Sidebar__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(98697);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var _mui_icons_material_MenuOpen__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(24779);
/* harmony import */ var _mui_icons_material_MenuOpen__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MenuOpen__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _api_manage_hooks_react_query_stores_categories_useGetStoresCategoriesItem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(54410);
/* harmony import */ var _cards_ProductCard__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(71989);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _api_manage_hooks_react_query_store_useGetSearchedStoreItems__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(62540);
/* harmony import */ var _states__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(67454);
/* harmony import */ var _custom_empty_result__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(58797);
/* harmony import */ var _public_static_empty_png__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(18026);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(57987);
/* harmony import */ var _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(95785);
/* harmony import */ var helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(52539);
/* harmony import */ var _sort_HighToLow__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(87296);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(90603);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(89113);
/* harmony import */ var helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(42604);
/* harmony import */ var react_intersection_observer__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(44009);
/* harmony import */ var utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(81261);
/* harmony import */ var _DotSpin__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(16533);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(38017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_23__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_custom_search_CustomSearch__WEBPACK_IMPORTED_MODULE_2__, _Sidebar__WEBPACK_IMPORTED_MODULE_4__, _api_manage_hooks_react_query_stores_categories_useGetStoresCategoriesItem__WEBPACK_IMPORTED_MODULE_7__, _cards_ProductCard__WEBPACK_IMPORTED_MODULE_8__, _api_manage_hooks_react_query_store_useGetSearchedStoreItems__WEBPACK_IMPORTED_MODULE_10__, _custom_empty_result__WEBPACK_IMPORTED_MODULE_12__, react_i18next__WEBPACK_IMPORTED_MODULE_14__, _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__, _sort_HighToLow__WEBPACK_IMPORTED_MODULE_16__, react_intersection_observer__WEBPACK_IMPORTED_MODULE_20__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__]);
([_custom_search_CustomSearch__WEBPACK_IMPORTED_MODULE_2__, _Sidebar__WEBPACK_IMPORTED_MODULE_4__, _api_manage_hooks_react_query_stores_categories_useGetStoresCategoriesItem__WEBPACK_IMPORTED_MODULE_7__, _cards_ProductCard__WEBPACK_IMPORTED_MODULE_8__, _api_manage_hooks_react_query_store_useGetSearchedStoreItems__WEBPACK_IMPORTED_MODULE_10__, _custom_empty_result__WEBPACK_IMPORTED_MODULE_12__, react_i18next__WEBPACK_IMPORTED_MODULE_14__, _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__, _sort_HighToLow__WEBPACK_IMPORTED_MODULE_16__, react_intersection_observer__WEBPACK_IMPORTED_MODULE_20__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


























const handleShimmerProducts = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            ...Array(3)
        ].map((item, index)=>{
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                item: true,
                xs: 6,
                sm: 4,
                md: 3,
                lg: 3,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_ProductCard__WEBPACK_IMPORTED_MODULE_8__/* .CardWrapper */ .UK, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
                        spacing: 1,
                        alignItems: "center",
                        justifyContent: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                variant: "rectangular",
                                animation: "pulse",
                                width: "100%",
                                height: 170
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
                                padding: "1rem",
                                alignItems: "center",
                                justifyContent: "center",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                        variant: "text",
                                        animation: "wave",
                                        height: 20,
                                        width: "80%"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                        variant: "text",
                                        animation: "wave",
                                        height: 20,
                                        width: "40%"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                        variant: "text",
                                        animation: "wave",
                                        height: 20,
                                        width: "30%"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                        direction: "row",
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                                variant: "text",
                                                animation: "wave",
                                                width: 70,
                                                height: 20
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Skeleton, {
                                                variant: "text",
                                                animation: "wave",
                                                width: 70,
                                                height: 20
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            }, index);
        })
    });
};
const getDiscountedPriceAmount = (item)=>{
    return (0,helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_18__/* .getDiscountedAmount */ .fw)(item?.price, item?.discount, item?.discount_type, item?.store_discount, item?.quantity);
};
const getHighToLow = (data)=>{
    if (data?.length > 0) {
        return data.sort((a, b)=>getDiscountedPriceAmount(b) - getDiscountedPriceAmount(a));
    } else {
        return data;
    }
};
// Sort products by low to high value
const getLowToHigh = (data)=>{
    if (data?.length > 0) {
        return data.sort((a, b)=>getDiscountedPriceAmount(a) - getDiscountedPriceAmount(b));
    } else {
        return data;
    }
};
const MiddleSection = (props)=>{
    const { storeDetails , ownCategories , isSmall , storeShare , setExpanded  } = props;
    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_states__WEBPACK_IMPORTED_MODULE_11__/* .reducer */ .I6, _states__WEBPACK_IMPORTED_MODULE_11__/* .initialState */ .E3);
    const [checkState, setCheckState] = react__WEBPACK_IMPORTED_MODULE_1___default().useState({
        veg: false,
        non_veg: false
    });
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_14__.useTranslation)();
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_17__.useSelector)((state)=>state.configData);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_9__.useRouter)();
    const { id  } = router.query;
    const storeId = storeDetails?.id;
    const limit = 12;
    const { ref , inView  } = (0,react_intersection_observer__WEBPACK_IMPORTED_MODULE_20__.useInView)();
    const [offset, setOffset] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const pageParams = {
        storeId: storeId,
        categoryId: state.categoryId,
        offset: offset,
        minMax: state.minMax,
        type: state.type,
        limit: limit,
        ...storeShare
    };
    const searchPageParams = {
        storeId: storeId,
        searchKey: state.searchKey,
        offset: offset,
        type: "all",
        limit: limit,
        ...storeShare
    };
    const handleSearchSuccess = (res)=>{
        if (res) {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
                payload: res
            });
        }
    };
    const { data: searchData , refetch: refetchSearchData , isRefetching: isRefetchingSearch , isFetched , fetchNextPage: fetchNextPageSearch , hasNextPage: hasNextPageSearch  } = (0,_api_manage_hooks_react_query_store_useGetSearchedStoreItems__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(searchPageParams);
    const handleLocalStorageSave = (resProducts)=>{
        if (offset === 1) {
            let visitedStoresProducts = JSON.parse(localStorage.getItem("visitedStoresProducts"));
            if (visitedStoresProducts) {
                if (visitedStoresProducts?.length > 0) {
                    const isThisStoresProductExist = visitedStoresProducts?.filter((item)=>item?.store_id === storeDetails?.id);
                    if (isThisStoresProductExist?.length > 0) {
                        return null;
                    } else {
                        resProducts?.slice(0, 5)?.forEach((item)=>visitedStoresProducts.push(item));
                    }
                    localStorage.setItem("visitedStoresProducts", JSON.stringify(visitedStoresProducts));
                }
            } else {
                const products = resProducts?.length > 5 ? resProducts?.slice(0, 5) : resProducts;
                localStorage.setItem("visitedStoresProducts", JSON.stringify(products));
            }
        }
    };
    const handleSuccess = (res)=>{
        if (res) {
            if (res?.products?.length > 0) {
                handleLocalStorageSave(res?.products);
            }
            const initialHigh2LowSortedData = getHighToLow(res?.products);
            if (offset > 1) {
                if (state?.data) {
                    if (initialHigh2LowSortedData?.length > 0) {
                        const newArray = [
                            ...state?.data?.products,
                            ...initialHigh2LowSortedData
                        ];
                        const withoutDuplicacy = (0,utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__/* .removeDuplicates */ .R1)(newArray, "id");
                        dispatch({
                            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
                            payload: {
                                ...res,
                                products: withoutDuplicacy
                            }
                        });
                    }
                } else {
                    dispatch({
                        type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
                        payload: {
                            ...res,
                            products: initialHigh2LowSortedData
                        }
                    });
                }
                dispatch({
                    type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setIsSidebarOpen */ .om.setIsSidebarOpen,
                    payload: false
                });
            } else {
                if (state?.data) {
                    if (initialHigh2LowSortedData?.length > 0) {
                        const newArray1 = [
                            ...initialHigh2LowSortedData
                        ];
                        const withoutDuplicacy1 = (0,utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__/* .removeDuplicates */ .R1)(newArray1, "id");
                        dispatch({
                            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
                            payload: {
                                ...res,
                                products: withoutDuplicacy1
                            }
                        });
                    } else {
                        dispatch({
                            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
                            payload: {
                                ...res,
                                products: initialHigh2LowSortedData
                            }
                        });
                    }
                } else {
                    dispatch({
                        type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
                        payload: {
                            ...res,
                            products: initialHigh2LowSortedData
                        }
                    });
                }
                dispatch({
                    type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setIsSidebarOpen */ .om.setIsSidebarOpen,
                    payload: false
                });
            }
        }
    };
    const { data , refetch , isRefetching , isLoading , fetchNextPage , hasNextPage , isLoading: isLoadingStoresCategories , isFetchingNextPage  } = (0,_api_manage_hooks_react_query_stores_categories_useGetStoresCategoriesItem__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)(pageParams);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (state.searchKey === "" || !state.searchKey) {
            refetch();
        }
    }, [
        state.categoryId,
        state.type,
        id
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (state.searchKey) {
            if (searchData?.pages?.length > 0) {
                searchData?.pages?.forEach((item)=>{
                    handleSuccess(item);
                });
            }
        } else {
            if (data?.pages?.length > 0) {
                data?.pages?.forEach((item)=>{
                    handleSuccess(item);
                });
            }
        }
    }, [
        data,
        searchData,
        state.categoryId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setOffset(1);
    }, [
        storeId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (inView && limit < data?.pages[0]?.total_size) {
            if (!isLoadingStoresCategories) {
                dispatch({
                    type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setOffSet */ .om.setOffSet,
                    payload: 1
                });
                setOffset((prev)=>prev + 1);
            }
        }
    }, [
        inView
    ]);
    const handleCategoryId = (id)=>{
        setOffset(1);
        if (id?.checked) {
            const newIds = [
                ...state.categoryId,
                id?.id
            ];
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setCategoryId */ .om.setCategoryId,
                payload: [
                    ...new Set(newIds)
                ]
            });
        } else {
            const newIds1 = state.categoryId?.filter((item)=>item !== id?.id);
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setCategoryId */ .om.setCategoryId,
                payload: newIds1
            });
        }
        dispatch({
            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setIsSidebarOpen */ .om.setIsSidebarOpen,
            payload: false
        });
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (state.searchKey && state.searchKey !== "") {
            if (offset === 1) {
                refetchSearchData();
            } else {
                fetchNextPageSearch();
            }
        } else {
            if (offset === 1) {
                refetch();
            } else {
                fetchNextPage();
            }
        }
    }, [
        state.searchKey,
        offset
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (JSON.stringify(state.minMax) !== JSON.stringify([
            0,
            1
        ])) {
            refetch();
        }
    }, [
        state.minMax
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (state?.data?.products?.length > 0) {
            sortWiseDataHandle();
        }
    }, [
        state.sortBy
    ]);
    const handleChangePrice = (value)=>{
        dispatch({
            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setMinMax */ .om.setMinMax,
            payload: value
        });
        setOffset(1);
    };
    const handleSelection = ()=>{
        if (checkState?.veg && !checkState?.non_veg) {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setType */ .om.setType,
                payload: "veg"
            });
        } else if (checkState?.non_veg && !checkState?.veg) {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setType */ .om.setType,
                payload: "non_veg"
            });
        } else if (checkState?.veg && checkState?.non_veg) {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setType */ .om.setType,
                payload: "all"
            });
        } else {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setType */ .om.setType,
                payload: "all"
            });
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleSelection();
        setOffset(1);
    }, [
        checkState?.veg,
        checkState.non_veg
    ]);
    let moduleId = (0,helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_24__/* .getModuleId */ .S)() ? (0,helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_24__/* .getModuleId */ .S)() : parseInt(router.query.module_id);
    const handleSearchResult = (value)=>{
        setOffset(1);
        dispatch({
            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setOffSet */ .om.setOffSet,
            payload: 1
        });
        if (value !== "") {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setSearchKey */ .om.setSearchKey,
                payload: value
            });
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setMinMax */ .om.setMinMax,
                payload: [
                    0,
                    1
                ]
            });
        } else {
            dispatch({
                type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setSearchKey */ .om.setSearchKey,
                payload: null
            });
        }
    };
    const sortWiseDataHandle = ()=>{
        let newData;
        if (state.sortBy === "high") {
            newData = {
                ...state.data,
                products: getHighToLow(state.data.products)
            };
        } else {
            newData = {
                ...state.data,
                products: getLowToHigh(state.data.products)
            };
        }
        dispatch({
            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setData */ .om.setData,
            payload: newData
        });
    };
    const handleSortBy = (value)=>{
        dispatch({
            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setSortBy */ .om.setSortBy,
            payload: value
        });
        dispatch({
            type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setIsSidebarOpen */ .om.setIsSidebarOpen,
            payload: false
        });
    };
    const priceRangeWiseSorted = (products)=>{
        if (products.length > 0) {
            return products?.filter((newItem)=>newItem?.price >= state.minMax[0] && newItem?.price <= state.minMax[1]);
        }
    };
    const minMaxWiseSorted = (products)=>{
        if (state.minMax[0] === 0 && state.minMax[1] === 1) {
            return products;
        } else {
            return priceRangeWiseSorted(products);
        }
    };
    const getCategoryWiseProduct = (products)=>{
        const isAllExist = state.categoryId?.length === 0 ? true : false;
        if (isAllExist) {
            return minMaxWiseSorted(products);
        } else {
            const categoryToString = state.categoryId?.map(String);
            const filteredData = products?.filter((item)=>item?.category_ids.filter((item)=>categoryToString?.includes(item.id)));
            return minMaxWiseSorted(filteredData);
        }
    };
    const handleOpenSerach = ()=>{
        setOpen(!open);
    };
    if (inView) {
        setExpanded(false);
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.NoSsr, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomBoxFullWidth */ .uu, {
            children: moduleId && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                container: true,
                sx: {
                    mt: {
                        xs: "5px",
                        sm: "20px"
                    }
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 12,
                        container: true,
                        justifyContent: "center",
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 3,
                                md: 5,
                                align: "left",
                                children: (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_25__/* .getCurrentModuleType */ .X)() === "pharmacy" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                    fontSize: {
                                        xs: "13px",
                                        md: "15px"
                                    },
                                    textAlign: "start",
                                    fontWeight: "600",
                                    children: t("All Items")
                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                    fontSize: {
                                        xs: "13px",
                                        md: "15px"
                                    },
                                    textAlign: "start",
                                    fontWeight: "600",
                                    children: t("All Products")
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 9,
                                md: 7,
                                container: true,
                                spacing: 3,
                                children: isSmall ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                    item: true,
                                    xs: 12,
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
                                        direction: "row",
                                        alignItems: "center",
                                        justifyContent: "flex-end",
                                        children: [
                                            !open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                                onClick: handleOpenSerach,
                                                sx: {
                                                    color: "primary.main",
                                                    display: {
                                                        lg: "none"
                                                    }
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_23___default()), {})
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomBoxFullWidth */ .uu, {
                                                sx: {
                                                    width: open ? "200px" : "0px",
                                                    transition: "width 0.5s ease-in-out"
                                                },
                                                children: open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_search_CustomSearch__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                    label: t("Search for items..."),
                                                    selectedValue: state.searchKey,
                                                    handleSearchResult: handleSearchResult,
                                                    type2: true
                                                })
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                                onClick: ()=>dispatch({
                                                        type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setIsSidebarOpen */ .om.setIsSidebarOpen,
                                                        payload: true
                                                    }),
                                                sx: {
                                                    color: "primary.main",
                                                    display: {
                                                        lg: "none"
                                                    }
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_MenuOpen__WEBPACK_IMPORTED_MODULE_6___default()), {})
                                            }),
                                            (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_25__/* .getCurrentModuleType */ .X)() === "food" && !isSmall && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                selected: state.type,
                                                handleSelection: handleSelection,
                                                checkState: checkState,
                                                setCheckState: setCheckState
                                            })
                                        ]
                                    })
                                }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 7,
                                            md: 7.5,
                                            children: (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_25__/* .getCurrentModuleType */ .X)() === helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_19__/* .ModuleTypes.FOOD */ .J.FOOD ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                selected: state.type,
                                                handleSelection: handleSelection,
                                                checkState: checkState,
                                                setCheckState: setCheckState
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_search_CustomSearch__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                label: t("Search for items..."),
                                                selectedValue: state.searchKey,
                                                handleSearchResult: handleSearchResult,
                                                type2: true
                                            })
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 7,
                                            md: 4.5,
                                            children: (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_25__/* .getCurrentModuleType */ .X)() === helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_19__/* .ModuleTypes.FOOD */ .J.FOOD ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_search_CustomSearch__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                                label: t("Search for items..."),
                                                selectedValue: state.searchKey,
                                                handleSearchResult: handleSearchResult,
                                                type2: true
                                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_sort_HighToLow__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                                handleSortBy: handleSortBy,
                                                sortBy: state.sortBy
                                            })
                                        }),
                                        " "
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 12,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                            width: "100%",
                            sx: {
                                mt: "20px",
                                mb: "20px",
                                borderBottom: (theme)=>`2px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.alpha)(theme.palette.neutral[400], 0.2)}`
                            }
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 0,
                        sm: 0,
                        md: 0,
                        lg: 3,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Sidebar__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            ...props,
                            onClose: ()=>dispatch({
                                    type: _states__WEBPACK_IMPORTED_MODULE_11__/* .ACTION.setIsSidebarOpen */ .om.setIsSidebarOpen,
                                    payload: false
                                }),
                            open: state.isSidebarOpen,
                            handleCategoryId: handleCategoryId,
                            handleChangePrice: handleChangePrice,
                            selectedCategories: state.categoryId,
                            // priceFilterRange={handlePriceFilterRange(
                            //   storeDetails?.price_range
                            // )}
                            ownCategories: ownCategories,
                            priceFilterRange: storeDetails?.price_range,
                            storesApiLoading: isRefetching,
                            searchIsLoading: refetchSearchData,
                            storeId: id,
                            handleSortBy: handleSortBy,
                            sortBy: state.sortBy,
                            isSmall: isSmall,
                            selected: state.type,
                            handleSelection: handleSelection,
                            checkState: checkState,
                            setCheckState: setCheckState
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 12,
                        lg: 9,
                        container: true,
                        spacing: 3,
                        alignItems: "flex-start",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 12,
                                container: true,
                                spacing: 2,
                                children: [
                                    isLoading && !isFetchingNextPage ? handleShimmerProducts() : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: state.data && state.data?.products?.length > 0 && getCategoryWiseProduct(state.data?.products)?.map((item, index)=>{
                                            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                                item: true,
                                                xs: 6,
                                                sm: 4,
                                                md: 3,
                                                lg: 3,
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_ProductCard__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .ZP, {
                                                    item: item,
                                                    cardheight: "365px",
                                                    cardFor: "vertical",
                                                    cardType: "vertical-type"
                                                }, item?.id)
                                            }, index);
                                        })
                                    }),
                                    (isFetchingNextPage || isRefetchingSearch) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                        item: true,
                                        container: true,
                                        xs: 12,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                            item: true,
                                            xs: 12,
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                                sx: {
                                                    minHeight: "40vh",
                                                    marginTop: "2rem"
                                                },
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DotSpin__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {})
                                            })
                                        })
                                    }),
                                    state.data?.products?.length === 0 && !isRefetching && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                                        width: "100%",
                                        paddingTop: {
                                            xs: "0px",
                                            md: "30px"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_empty_result__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                            image: _public_static_empty_png__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z,
                                            label: "Nothing found",
                                            width: "200px",
                                            height: "200px"
                                        })
                                    })
                                ]
                            }),
                            (hasNextPage || hasNextPageSearch) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Grid, {
                                item: true,
                                xs: 12,
                                sx: {
                                    marginBottom: "2rem"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomBoxFullWidth */ .uu, {
                                    ref: ref,
                                    sx: {
                                        height: "10px"
                                    }
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().memo(MiddleSection));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 67454:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E3": () => (/* binding */ initialState),
/* harmony export */   "I6": () => (/* binding */ reducer),
/* harmony export */   "om": () => (/* binding */ ACTION)
/* harmony export */ });
const initialState = {
    data: null,
    isSidebarOpen: false,
    categoryId: [],
    offSet: 1,
    searchKey: "",
    minMax: [
        0,
        1
    ],
    type: "all",
    sortBy: "Default"
};
const reducer = (state, action)=>{
    switch(action.type){
        case "setData":
            return {
                ...state,
                data: action.payload
            };
        case "setIsSidebarOpen":
            return {
                ...state,
                isSidebarOpen: action.payload
            };
        case "setCategoryId":
            return {
                ...state,
                categoryId: action.payload
            };
        case "setOffSet":
            return {
                ...state,
                offSet: state.offSet + action.payload
            };
        case "setSearchKey":
            return {
                ...state,
                searchKey: action.payload
            };
        case "setType":
            return {
                ...state,
                type: action.payload
            };
        case "setMinMax":
            return {
                ...state,
                minMax: action.payload
            };
        case "setSortBy":
            return {
                ...state,
                sortBy: action.payload
            };
        default:
            return state;
    }
};
const ACTION = {
    setData: "setData",
    setIsSidebarOpen: "setIsSidebarOpen",
    setCategoryId: "setCategoryId",
    setOffSet: "setOffSet",
    setSearchKey: "setSearchKey",
    setMinMax: "setMinMax",
    setType: "setType",
    setSortBy: "setSortBy"
};


/***/ }),

/***/ 34361:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _api_manage_hooks_react_query_product_details_usePopularProductsInStore__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(3934);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(90603);
/* harmony import */ var helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(42604);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45269);
/* harmony import */ var _typographies_H1__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(74485);
/* harmony import */ var _settings__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(98431);
/* harmony import */ var _cards_ProductCard__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(71989);
/* harmony import */ var _api_manage_hooks_react_query_common_conditions_useGetCommonConditionStore__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(27707);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_manage_hooks_react_query_product_details_usePopularProductsInStore__WEBPACK_IMPORTED_MODULE_4__, _typographies_H1__WEBPACK_IMPORTED_MODULE_7__, _cards_ProductCard__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_common_conditions_useGetCommonConditionStore__WEBPACK_IMPORTED_MODULE_10__]);
([_api_manage_hooks_react_query_product_details_usePopularProductsInStore__WEBPACK_IMPORTED_MODULE_4__, _typographies_H1__WEBPACK_IMPORTED_MODULE_7__, _cards_ProductCard__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_common_conditions_useGetCommonConditionStore__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* eslint-disable react-hooks/exhaustive-deps */ 











const PopularInTheStore = ({ id , storeShare  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const offset = 1;
    const limit = 10;
    const getBG = ()=>{
        if ((0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_11__/* .getCurrentModuleType */ .X)()) {
            switch((0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_11__/* .getCurrentModuleType */ .X)()){
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.GROCERY */ .J.GROCERY:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.primary.main, 0.2),
                        title: "Recommended for you"
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.PHARMACY */ .J.PHARMACY:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.info.custom1, 0.1),
                        title: "Common Conditions!"
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.ECOMMERCE */ .J.ECOMMERCE:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.info.blue, 0.1),
                        title: "Recommended for you"
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.FOOD */ .J.FOOD:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.moduleTheme.food, 0.1),
                        title: "Recommended for you"
                    };
            }
        } else {
            switch(storeShare?.moduleType){
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.GROCERY */ .J.GROCERY:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.primary.main, 0.2),
                        title: "Popular in this store!"
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.PHARMACY */ .J.PHARMACY:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.info.custom1, 0.2),
                        title: "Common Conditions!"
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.ECOMMERCE */ .J.ECOMMERCE:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.info.blue, 0.1),
                        title: "Popular in this store!"
                    };
                case helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_5__/* .ModuleTypes.FOOD */ .J.FOOD:
                    return {
                        bgColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.moduleTheme.food, 0.1),
                        title: "Popular in this Restaurant!"
                    };
            }
        }
    };
    const { data , refetch , isLoading  } = (0,_api_manage_hooks_react_query_product_details_usePopularProductsInStore__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z)({
        id,
        ...storeShare
    });
    const { data: commonConditionitems , refetch: refetchCommonCondition , isLoading: isLoddingCondition  } = (0,_api_manage_hooks_react_query_common_conditions_useGetCommonConditionStore__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)({
        id,
        ...storeShare,
        offset,
        limit
    });
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        refetchCommonCondition();
        refetch();
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomBoxFullWidth */ .uu, {
        children: (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_11__/* .getCurrentModuleType */ .X)() === "pharmacy" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: commonConditionitems?.products?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .SliderCustom */ .$_, {
                nopadding: "true",
                sx: {
                    backgroundColor: getBG()?.bgColor,
                    padding: "20px 20px 20px 20px",
                    borderRadius: "4px",
                    marginTop: "12px",
                    "& .slick-slide": {
                        paddingRight: "20px",
                        paddingBottom: "10px"
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 2.2,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_H1__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            textAlign: "start",
                            text: getBG()?.title
                        }),
                        !isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                            ..._settings__WEBPACK_IMPORTED_MODULE_8__/* .settings */ .X,
                            children: commonConditionitems?.products?.map((item, index)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP, {
                                    item: item,
                                    specialCard: "true"
                                }, index);
                            })
                        })
                    ]
                })
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
            children: data?.items?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .SliderCustom */ .$_, {
                nopadding: "true",
                sx: {
                    backgroundColor: getBG()?.bgColor,
                    padding: "20px 20px 8px 20px",
                    borderRadius: "4px",
                    marginTop: "12px",
                    "& .slick-slide": {
                        paddingRight: "20px"
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 2.2,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_H1__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                            textAlign: "start",
                            text: getBG()?.title
                        }),
                        !isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
                            ..._settings__WEBPACK_IMPORTED_MODULE_8__/* .settings */ .X,
                            children: data?.items?.map((item, index)=>{
                                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_ProductCard__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .ZP, {
                                    item: item,
                                    specialCard: "true",
                                    noRecommended: true
                                }, index);
                            })
                        })
                    ]
                })
            })
        })
    });
};
PopularInTheStore.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PopularInTheStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98431:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ settings)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(46573);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(66959);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(52818);
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_4__);






const PrevWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Box)(({ theme , isdisabled  })=>({
        zIndex: 1,
        top: "50%",
        left: 0,
        display: isdisabled ? "none" : "flex",
        background: "rgba(255, 255, 255, 0.8)",
        borderRadius: "50%",
        height: "38px",
        width: "38px",
        alignItems: "center",
        justifyContent: "center",
        [theme.breakpoints.down("sm")]: {
            display: "none"
        }
    }));
const NextWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Box)(({ theme , isdisabled  })=>({
        zIndex: 1,
        right: 0,
        display: isdisabled ? "none" : "flex",
        backgroundColor: "rgba(255, 255, 255, 0.8)",
        borderRadius: "50%",
        height: "38px",
        width: "38px",
        alignItems: "center",
        justifyContent: "center",
        [theme.breakpoints.down("sm")]: {
            display: "none"
        }
    }));
const ButtonContainer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Box)(({ theme , right , isdisabled  })=>({
        top: 0,
        height: "92%",
        width: "73px",
        background: right === "true" ? "linear-gradient(270deg, rgba(75, 86, 107, 0.15) 0%, rgba(75, 86, 107, 0.00) 100%)" : "linear-gradient(to right, rgba(75, 86, 107, 0.15) 0%, rgba(75, 86, 107, 0) 100%)",
        zIndex: 1,
        right: right === "true" && 0,
        left: right !== "true" && 0,
        position: "absolute",
        alignItems: "center",
        justifyContent: "center",
        display: isdisabled ? "none" : "flex"
    }));
const Next = ({ onClick , className  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonContainer, {
        isdisabled: className?.includes("slick-disabled"),
        right: "true",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextWrapper, {
            className: `client-nav client-next ${className}`,
            onClick: onClick,
            isdisabled: className?.includes("slick-disabled"),
            children: (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_5__/* .getLanguage */ .G)() === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600]
                }
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_4___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.mode === "dark" ? theme.palette.neutral[100] : theme.palette.neutral[600]
                }
            })
        })
    });
};
const Prev = ({ onClick , className  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonContainer, {
        isdisabled: className?.includes("slick-disabled"),
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevWrapper, {
            className: `client-nav client-prev ${className}`,
            onClick: onClick,
            isdisabled: className?.includes("slick-disabled"),
            children: (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_5__/* .getLanguage */ .G)() === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_4___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600]
                }
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600]
                }
            })
        })
    });
};
const settings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 4.8,
    slidesToScroll: 1,
    nextArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Next, {}),
    prevArrow: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Prev, {}),
    responsive: [
        {
            breakpoint: 1550,
            settings: {
                slidesToShow: 4.9,
                slidesToScroll: 3,
                infinite: false
            }
        },
        {
            breakpoint: 1450,
            settings: {
                slidesToShow: 4.6,
                slidesToScroll: 3,
                infinite: false
            }
        },
        {
            breakpoint: 1250,
            settings: {
                slidesToShow: 3.5,
                slidesToScroll: 2,
                infinite: false
            }
        },
        {
            breakpoint: 1024,
            settings: {
                slidesToShow: 3.3,
                slidesToScroll: 2,
                infinite: false
            }
        },
        {
            breakpoint: 1000,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 2,
                infinite: false
            }
        },
        {
            breakpoint: 700,
            settings: {
                slidesToShow: 2.8,
                slidesToScroll: 2,
                initialSlide: 2
            }
        },
        {
            breakpoint: 600,
            settings: {
                slidesToShow: 2.5,
                slidesToScroll: 2,
                initialSlide: 2
            }
        },
        {
            breakpoint: 480,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 479,
            settings: {
                slidesToShow: 1.9,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 420,
            settings: {
                slidesToShow: 1.8,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 380,
            settings: {
                slidesToShow: 1.6,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 350,
            settings: {
                slidesToShow: 1.2,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 270,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }
    ]
};


/***/ }),

/***/ 74485:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57987);
/* harmony import */ var _utils_CommonValues__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65401);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
react_i18next__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const H1 = (props)=>{
    const { text , textAlign , textTransform , fontWeight , ...rest } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        textAlign: textAlign ? textAlign : "center",
        fontWeight: fontWeight ? fontWeight : "700",
        lineHeight: (0,_utils_CommonValues__WEBPACK_IMPORTED_MODULE_4__/* .IsSmallScreen */ .R)() ? "10px" : "30px",
        sx: {
            fontSize: {
                xs: "15px",
                md: "22px"
            }
        },
        textTransform: textTransform,
        ...rest,
        children: t(text)
    });
};
H1.propTypes = {
    text: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string.isRequired)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (H1);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 47915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 66146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 71507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddCircleOutline");

/***/ }),

/***/ 95780:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBackIosNew");

/***/ }),

/***/ 61883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForward");

/***/ }),

/***/ 91658:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForwardIos");

/***/ }),

/***/ 52081:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Call");

/***/ }),

/***/ 26616:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Campaign");

/***/ }),

/***/ 7521:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChatBubbleOutline");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Check");

/***/ }),

/***/ 66959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 52818:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronRight");

/***/ }),

/***/ 51653:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Clear");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 44486:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloudUpload");

/***/ }),

/***/ 29605:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ConfirmationNumber");

/***/ }),

/***/ 77926:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ControlPointOutlined");

/***/ }),

/***/ 99520:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Create");

/***/ }),

/***/ 83188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 88566:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Directions");

/***/ }),

/***/ 89226:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Email");

/***/ }),

/***/ 8690:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Error");

/***/ }),

/***/ 88369:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ErrorOutlineOutlined");

/***/ }),

/***/ 27372:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 6910:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 25967:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorderOutlined");

/***/ }),

/***/ 50682:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Fullscreen");

/***/ }),

/***/ 64107:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FullscreenExit");

/***/ }),

/***/ 15594:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GpsFixed");

/***/ }),

/***/ 49262:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GridViewRounded");

/***/ }),

/***/ 27549:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Group");

/***/ }),

/***/ 73467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 60357:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ImportContacts");

/***/ }),

/***/ 64845:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 99881:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 96866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LibraryBooks");

/***/ }),

/***/ 50550:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalPhone");

/***/ }),

/***/ 29246:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalShippingOutlined");

/***/ }),

/***/ 12906:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 40399:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LockOutlined");

/***/ }),

/***/ 89801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 84552:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Loyalty");

/***/ }),

/***/ 9026:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Mail");

/***/ }),

/***/ 34702:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MapsHomeWorkSharp");

/***/ }),

/***/ 63365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 24779:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MenuOpen");

/***/ }),

/***/ 31939:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Person");

/***/ }),

/***/ 15214:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Place");

/***/ }),

/***/ 19509:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Remove");

/***/ }),

/***/ 15642:
/***/ ((module) => {

module.exports = require("@mui/icons-material/RemoveRedEye");

/***/ }),

/***/ 54527:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ReportProblem");

/***/ }),

/***/ 49426:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Room");

/***/ }),

/***/ 38017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 39823:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SendToMobile");

/***/ }),

/***/ 10032:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 86983:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 6408:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartCheckout");

/***/ }),

/***/ 22749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartOutlined");

/***/ }),

/***/ 72548:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartRounded");

/***/ }),

/***/ 19766:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SmsRounded");

/***/ }),

/***/ 77849:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Star");

/***/ }),

/***/ 33378:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StarRate");

/***/ }),

/***/ 64193:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Store");

/***/ }),

/***/ 50773:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Visibility");

/***/ }),

/***/ 77749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/VisibilityOff");

/***/ }),

/***/ 9001:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Wallet");

/***/ }),

/***/ 65342:
/***/ ((module) => {

module.exports = require("@mui/icons-material/WarningAmber");

/***/ }),

/***/ 86072:
/***/ ((module) => {

module.exports = require("@mui/lab");

/***/ }),

/***/ 76829:
/***/ ((module) => {

module.exports = require("@mui/lab/LoadingButton");

/***/ }),

/***/ 65692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 83882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 94960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 8611:
/***/ ((module) => {

module.exports = require("@mui/material/Dialog");

/***/ }),

/***/ 29404:
/***/ ((module) => {

module.exports = require("@mui/material/DialogActions");

/***/ }),

/***/ 52468:
/***/ ((module) => {

module.exports = require("@mui/material/DialogTitle");

/***/ }),

/***/ 68891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 67934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 33103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 25545:
/***/ ((module) => {

module.exports = require("@mui/material/LinearProgress");

/***/ }),

/***/ 85246:
/***/ ((module) => {

module.exports = require("@mui/material/Link");

/***/ }),

/***/ 94192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 31011:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemButton");

/***/ }),

/***/ 78315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 55374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 76563:
/***/ ((module) => {

module.exports = require("@mui/material/RadioGroup");

/***/ }),

/***/ 27163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 18442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 69484:
/***/ ((module) => {

module.exports = require("@mui/styles");

/***/ }),

/***/ 97986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 73280:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ 6159:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/DateCalendar");

/***/ }),

/***/ 82433:
/***/ ((module) => {

module.exports = require("@react-google-maps/api");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 45567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 32245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 13332:
/***/ ((module) => {

module.exports = require("moment/moment");

/***/ }),

/***/ 53918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 31487:
/***/ ((module) => {

module.exports = require("react-apple-login");

/***/ }),

/***/ 66405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 66804:
/***/ ((module) => {

module.exports = require("react-facebook-login/dist/facebook-login-render-props");

/***/ }),

/***/ 11022:
/***/ ((module) => {

module.exports = require("react-geolocated");

/***/ }),

/***/ 50801:
/***/ ((module) => {

module.exports = require("react-image-magnify");

/***/ }),

/***/ 64254:
/***/ ((module) => {

module.exports = require("react-otp-input");

/***/ }),

/***/ 25452:
/***/ ((module) => {

module.exports = require("react-phone-input-2");

/***/ }),

/***/ 61175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 38096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 94172:
/***/ ((module) => {

module.exports = require("simplebar-react");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 53139:
/***/ ((module) => {

module.exports = import("@emotion/react");;

/***/ }),

/***/ 4115:
/***/ ((module) => {

module.exports = import("@emotion/styled");;

/***/ }),

/***/ 99648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 23745:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 60401:
/***/ ((module) => {

module.exports = import("firebase/auth");;

/***/ }),

/***/ 33512:
/***/ ((module) => {

module.exports = import("firebase/messaging");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 69915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 86201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

module.exports = import("react-i18next");;

/***/ }),

/***/ 44009:
/***/ ((module) => {

module.exports = import("react-intersection-observer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,676,7760,5269,5938,2177,3258,4389,762,1989,3270,3265,3423], () => (__webpack_exec__(22519)));
module.exports = __webpack_exports__;

})();
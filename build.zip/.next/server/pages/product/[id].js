"use strict";
(() => {
var exports = {};
exports.id = 6360;
exports.ids = [6360];
exports.modules = {

/***/ 48972:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(94960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(13258);
/* harmony import */ var _src_components_product_details_ProductDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(61504);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _src_components_seo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(95376);
/* harmony import */ var _src_components_container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(28332);
/* harmony import */ var api_manage_hooks_custom_hooks_useScrollToTop__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(59599);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__, _src_components_product_details_ProductDetails__WEBPACK_IMPORTED_MODULE_4__, _src_components_seo__WEBPACK_IMPORTED_MODULE_6__]);
([_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__, _src_components_product_details_ProductDetails__WEBPACK_IMPORTED_MODULE_4__, _src_components_seo__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Index = ({ configData , productDetailsData , landingPageData  })=>{
    (0,api_manage_hooks_custom_hooks_useScrollToTop__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z)();
    const { cartList , campaignItem  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useSelector)((state)=>state.cart);
    const [productDetails, setProductDetails] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleProductDetails();
    }, [
        productDetailsData,
        cartList
    ]);
    const handleProductDetails = ()=>{
        if (productDetailsData) {
            if (cartList?.length > 0) {
                const isExist = cartList?.find((item)=>item?.id === productDetailsData?.id);
                if (isExist) {
                    let tempData = {
                        ...isExist,
                        store_details: productDetailsData?.store_details
                    };
                    setProductDetails([
                        tempData
                    ]);
                } else {
                    setProductDetails([
                        productDetailsData
                    ]);
                }
            } else {
                setProductDetails([
                    productDetailsData
                ]);
            }
        } else {
            //productDetailsData only be null if this page is for campaign
            setProductDetails([
                {
                    ...campaignItem,
                    isCampaignItem: true
                }
            ]);
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_2___default()), {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_seo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                title: configData ? `${productDetailsData?.name || productDetails[0]?.name}` : "Loading...",
                image: `${configData?.base_urls?.item_image_url}/${productDetailsData?.image}`,
                businessName: configData?.business_name,
                description: `${productDetailsData?.description}`,
                configData: configData
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_layout_MainLayout__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                configData: configData,
                landingPageData: landingPageData,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_container__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    children: productDetails.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_product_details_ProductDetails__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        productDetailsData: productDetails[0],
                        configData: configData
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Index);
const getServerSideProps = async (context)=>{
    const { req  } = context;
    const language = req.cookies.languageSetting;
    const configRes = await fetch(`${"https://bite.md"}/api/v1/config`, {
        method: "GET",
        headers: {
            "X-software-id": 33571750,
            "X-server": "server",
            origin: process.env.NEXT_CLIENT_HOST_URL,
            "X-localization": language
        }
    });
    const config = await configRes.json();
    const productId = context.query.id;
    const moduleId = context.query.module_id;
    const productType = context.query?.product_type;
    let productDetails = null;
    let productDetailsData = null;
    if (!productType) {
        productDetails = await fetch(`${"https://bite.md"}/api/v1/items/details/${productId}`, {
            method: "GET",
            headers: {
                moduleId: moduleId,
                "X-localization": language
            }
        });
        productDetailsData = await productDetails.json();
    }
    const landingPageRes = await fetch(`${"https://bite.md"}/api/v1/react-landing-page`, {
        method: "GET",
        headers: {
            "X-software-id": 33571750,
            "X-server": "server",
            origin: process.env.NEXT_CLIENT_HOST_URL,
            "X-localization": language
        }
    });
    const landingPageData = await landingPageRes.json();
    return {
        props: {
            configData: config,
            productDetailsData: !productType ? productDetailsData : null,
            landingPageData: landingPageData
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 54213:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetMoreFromStores)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getData = async (pageParams)=>{
    const { productId , offset , limit  } = pageParams;
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .more_from_store */ .q8}/${productId}?offset=${offset}&limit=${limit}`);
    return data;
};
function useGetMoreFromStores(pageParams, handleSuccess) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)("stores-categories-item", ()=>getData(pageParams), {
        enabled: false,
        onSuccess: handleSuccess,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onErrorResponse */ .RJ
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 59093:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetProductReviews)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getProductReviews = async (pageParams)=>{
    const { productId , page_limits , offSet  } = pageParams;
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .product_reviews_api */ .x}/${productId}?limit=${page_limits}&offset=${offSet}`);
    return data;
};
function useGetProductReviews(pageParams) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)("product-reviews", ()=>getProductReviews(pageParams), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 7404:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetStoreDetails)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getData = async (store_id)=>{
    if (store_id) {
        const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .store_details_api */ .HR}/${store_id}`);
        return data;
    }
};
function useGetStoreDetails(store_id) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)("store-details", ()=>getData(store_id), {
        enabled: false,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 61504:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7404);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(64038);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(94156);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(86201);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var redux_slices_wishList__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(64134);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(45269);
/* harmony import */ var utils_toasterMessages__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(70557);
/* harmony import */ var _home_module_wise_components_ecommerce_SinglePoster__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(46316);
/* harmony import */ var _home_module_wise_components_pharmacy_featured_stores__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(64051);
/* harmony import */ var _details_and_reviews_DetailsAndReviews__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(73302);
/* harmony import */ var _product_details_section_ProductDetailsSection__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(79237);
/* harmony import */ var _ProductsMoreFromTheStore__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2095);
/* harmony import */ var _StoreDetails__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(85219);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_2__, api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_3__, api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_4__, i18next__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_7__, _home_module_wise_components_ecommerce_SinglePoster__WEBPACK_IMPORTED_MODULE_11__, _home_module_wise_components_pharmacy_featured_stores__WEBPACK_IMPORTED_MODULE_12__, _details_and_reviews_DetailsAndReviews__WEBPACK_IMPORTED_MODULE_13__, _product_details_section_ProductDetailsSection__WEBPACK_IMPORTED_MODULE_14__, _ProductsMoreFromTheStore__WEBPACK_IMPORTED_MODULE_15__, _StoreDetails__WEBPACK_IMPORTED_MODULE_16__]);
([api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_2__, api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_3__, api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_4__, i18next__WEBPACK_IMPORTED_MODULE_5__, react_hot_toast__WEBPACK_IMPORTED_MODULE_7__, _home_module_wise_components_ecommerce_SinglePoster__WEBPACK_IMPORTED_MODULE_11__, _home_module_wise_components_pharmacy_featured_stores__WEBPACK_IMPORTED_MODULE_12__, _details_and_reviews_DetailsAndReviews__WEBPACK_IMPORTED_MODULE_13__, _product_details_section_ProductDetailsSection__WEBPACK_IMPORTED_MODULE_14__, _ProductsMoreFromTheStore__WEBPACK_IMPORTED_MODULE_15__, _StoreDetails__WEBPACK_IMPORTED_MODULE_16__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);


















const ProductDetails = ({ productDetailsData , configData  })=>{
    const storeImageBaseUrl = configData?.base_urls?.store_image_url;
    const reduxDispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_8__.useDispatch)();
    const [isWishlisted, setIsWishlisted] = (0,react__WEBPACK_IMPORTED_MODULE_6__.useState)(false);
    const { mutate: addFavoriteMutation  } = (0,api_manage_hooks_react_query_wish_list_useAddWishList__WEBPACK_IMPORTED_MODULE_3__/* .useAddToWishlist */ .x)();
    const { mutate  } = (0,api_manage_hooks_react_query_wish_list_useWishListDelete__WEBPACK_IMPORTED_MODULE_4__/* .useWishListDelete */ .V)();
    const { data: storeData , refetch  } = (0,api_manage_hooks_react_query_store_useGetStoreDetails__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(productDetailsData?.store_id);
    (0,react__WEBPACK_IMPORTED_MODULE_6__.useEffect)(()=>{
        if (productDetailsData?.store_id) {
            refetch();
        }
    }, []);
    const addToWishlistHandler = (e)=>{
        e.stopPropagation();
        let token = undefined;
        if (false) {}
        if (token) {
            addFavoriteMutation(productDetailsData?.id, {
                onSuccess: (response)=>{
                    if (response) {
                        reduxDispatch((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_9__/* .addWishList */ .TM)(productDetailsData));
                        setIsWishlisted(true);
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_7__["default"].success(response?.message);
                    }
                },
                onError: (error)=>{
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_7__["default"].error(error.response.data.message);
                }
            });
        } else react_hot_toast__WEBPACK_IMPORTED_MODULE_7__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_5__.t)(utils_toasterMessages__WEBPACK_IMPORTED_MODULE_17__/* .not_logged_in_message */ .XO));
    };
    const removeFromWishlistHandler = (e)=>{
        e.stopPropagation();
        const onSuccessHandlerForDelete = (res)=>{
            reduxDispatch((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_9__/* .removeWishListItem */ .$8)(productDetailsData?.id));
            setIsWishlisted(false);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_7__["default"].success(res.message, {
                id: "wishlist"
            });
        };
        mutate(productDetailsData?.id, {
            onSuccess: onSuccessHandlerForDelete,
            onError: (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_7__["default"].error(error.response.data.message);
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__/* .CustomStackFullWidth */ .Xw, {
        spacing: 5,
        paddingTop: {
            xs: "1.25rem",
            md: "2.5rem"
        },
        paddingBottom: "2.5rem",
        sx: {
            minHeight: "100vh"
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            spacing: 2,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 8,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__/* .CustomStackFullWidth */ .Xw, {
                        spacing: 5,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_section_ProductDetailsSection__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z, {
                                productDetailsData: productDetailsData,
                                configData: configData,
                                addToWishlistHandler: addToWishlistHandler,
                                removeFromWishlistHandler: removeFromWishlistHandler,
                                isWishlisted: isWishlisted
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_details_and_reviews_DetailsAndReviews__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                configData: configData,
                                description: productDetailsData?.description,
                                reviews: productDetailsData?.reviews,
                                productId: productDetailsData?.id,
                                storename: productDetailsData?.store_details?.name
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__/* .CustomStackFullWidth */ .Xw, {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_module_wise_components_pharmacy_featured_stores__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                                    slide: "3",
                                    title: "Popular Store",
                                    configData: configData
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    md: 4,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_10__/* .CustomStackFullWidth */ .Xw, {
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_StoreDetails__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                storeDetails: productDetailsData?.store_details ?? storeData,
                                storeImageBaseUrl: storeImageBaseUrl
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductsMoreFromTheStore__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                productDetails: productDetailsData
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 12,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_home_module_wise_components_ecommerce_SinglePoster__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {})
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductDetails);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 49007:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _product_details_section_ProductReviewCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5274);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(88278);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(61598);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(22021);
/* harmony import */ var _custom_pagination__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(92704);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_product_details_section_ProductReviewCard__WEBPACK_IMPORTED_MODULE_4__, i18next__WEBPACK_IMPORTED_MODULE_7__]);
([_product_details_section_ProductReviewCard__WEBPACK_IMPORTED_MODULE_4__, i18next__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const ProductReviews = ({ reviews , configData , offSet , total_size , setOffSet , page_limits , isExpanded , storename  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const SliderRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomBoxFullWidth */ .uu, {
            children: reviews?.length > 0 ? reviews?.map((review)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_section_ProductReviewCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                    review: review,
                    configData: configData,
                    storename: storename
                }, review?.id);
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: isExpanded === "true" && (0,i18next__WEBPACK_IMPORTED_MODULE_7__.t)("No reviews found")
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductReviews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2095:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_manage_hooks_react_query_product_details_useGetMoreFromStore__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(54213);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _cards_ProductCard__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71989);
/* harmony import */ var _typographies_H1__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(74485);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_api_manage_hooks_react_query_product_details_useGetMoreFromStore__WEBPACK_IMPORTED_MODULE_2__, _cards_ProductCard__WEBPACK_IMPORTED_MODULE_4__, _typographies_H1__WEBPACK_IMPORTED_MODULE_5__]);
([_api_manage_hooks_react_query_product_details_useGetMoreFromStore__WEBPACK_IMPORTED_MODULE_2__, _cards_ProductCard__WEBPACK_IMPORTED_MODULE_4__, _typographies_H1__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const ProductsMoreFromTheStore = ({ productDetails  })=>{
    const [offSet, setOffSet] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const [moreItem, setMoreItem] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const limit = 10;
    const pageParams = {
        productId: productDetails?.id,
        offset: offSet,
        limit: limit
    };
    const handleSuccess = (res)=>{
        if (res) {
            setMoreItem(res);
        }
    };
    const { refetch  } = (0,_api_manage_hooks_react_query_product_details_useGetMoreFromStore__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)(pageParams, handleSuccess);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        refetch();
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_H1__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                textAlign: "start",
                text: "More From This Store!",
                component: "h2"
            }),
            moreItem?.slice(0, 4)?.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_cards_ProductCard__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .ZP, {
                    item: item,
                    cardWidth: "350px",
                    cardheight: "160px",
                    horizontalcard: "true",
                    cardFor: "popular items"
                }, index);
            })
        ]
    });
};
ProductsMoreFromTheStore.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsMoreFromTheStore);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 85219:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53139);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6910);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(80697);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(93706);
/* harmony import */ var helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(89113);
/* harmony import */ var helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(52539);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(86201);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(57987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var redux_slices_wishList__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(64134);
/* harmony import */ var styled_components_CustomButtons_style__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(81029);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(45269);
/* harmony import */ var utils_toasterMessages__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(70557);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(58861);
/* harmony import */ var _search_CustomRatings__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(27559);
/* harmony import */ var _product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(53357);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react__WEBPACK_IMPORTED_MODULE_1__, api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_6__, api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_7__, react_hot_toast__WEBPACK_IMPORTED_MODULE_12__, react_i18next__WEBPACK_IMPORTED_MODULE_13__]);
([_emotion_react__WEBPACK_IMPORTED_MODULE_1__, api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_6__, api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_7__, react_hot_toast__WEBPACK_IMPORTED_MODULE_12__, react_i18next__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























const CustomWrapper = (0,_mui_system__WEBPACK_IMPORTED_MODULE_5__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Paper)(({ theme  })=>({
        padding: "20px",
        borderRadius: "5px",
        background: theme.palette.background.paper,
        boxShadow: "0px 10px 20px -3px rgba(145, 158, 171, 0.05), 0px 0px 2px 0px rgba(145, 158, 171, 0.20)"
    }));
const StoreDetails = ({ storeDetails , storeImageBaseUrl  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_13__.useTranslation)();
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_10__.useRouter)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)(theme.breakpoints.down("sm"));
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.configData);
    const dispatchRedux = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useDispatch)();
    const { wishLists  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.wishList);
    const { mutate  } = (0,api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_7__/* .useWishListStoreDelete */ .K)();
    const { mutate: addFavoriteMutation  } = (0,api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_6__/* .useAddStoreToWishlist */ .v)();
    let token = undefined;
    if (false) {}
    const onSuccessHandlerForDelete = (res)=>{
        dispatchRedux((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_15__/* .removeWishListStore */ .$X)(storeDetails?.id));
        react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].success(res.message, {
            id: "wishlist"
        });
    };
    const addToFavorite = ()=>{
        if (token) {
            addFavoriteMutation(storeDetails?.id, {
                onSuccess: (response)=>{
                    if (response) {
                        dispatchRedux((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_15__/* .addWishListStore */ .KO)(storeDetails));
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].success(response?.message);
                    }
                },
                onError: (error)=>{
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error(error.response.data.message);
                }
            });
        } else react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error(t(utils_toasterMessages__WEBPACK_IMPORTED_MODULE_21__/* .not_logged_in_message */ .XO));
    };
    const isInWishList = (id)=>{
        return !!wishLists?.store?.find((wishStore)=>wishStore.id === storeDetails?.id);
    };
    const deleteWishlistStore = (id)=>{
        mutate(id, {
            onSuccess: onSuccessHandlerForDelete,
            onError: (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_12__["default"].error(error.response.data.message);
            }
        });
    };
    const delievryTime = storeDetails?.delivery_time?.split(" ");
    const handleClick = ()=>{
        router.push({
            pathname: "/profile",
            query: {
                page: "inbox",
                type: "vendor",
                id: storeDetails?.vendor_id,
                routeName: "vendor_id",
                chatFrom: "true"
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomWrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
            container: true,
            spacing: 2.5,
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                    item: true,
                    xs: 12,
                    container: true,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                            item: true,
                            xs: 10,
                            alignSelf: "center",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                direction: "raw",
                                alignItems: "center",
                                sx: {
                                    flex: "0 0 60px",
                                    gap: "10px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomBoxFullWidth */ .uu, {
                                        sx: {
                                            position: "relative",
                                            height: "60px",
                                            width: "80px",
                                            borderRadius: "50%",
                                            border: (theme)=>`1px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.alpha)(theme.palette.neutral[300], 0.3)}`
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                            src: storeDetails?.logo_full_url,
                                            // alt={item?.name}
                                            height: "100%",
                                            width: "100%",
                                            obejctfit: "contain",
                                            borderRadius: "50%"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                        spacing: 0.5,
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                variant: "h7",
                                                component: "h2",
                                                children: storeDetails?.name
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                                direction: "row",
                                                alignItems: "center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_search_CustomRatings__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                                        ratingValue: storeDetails?.avg_rating,
                                                        color: theme.palette.warning.main,
                                                        readOnly: true
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                        fontSize: "12px",
                                                        color: "customColor.textGray",
                                                        children: [
                                                            "(",
                                                            storeDetails?.rating_count,
                                                            ")"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                fontSize: "14px",
                                                component: "h3",
                                                children: [
                                                    storeDetails?.total_items - 1,
                                                    "+ ",
                                                    t("Products")
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                            item: true,
                            xs: 2,
                            children: [
                                !isInWishList(storeDetails?.id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                                    text: "Add to cart",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_20__/* .RoundedIconButton */ .n, {
                                        sx: {
                                            filter: "drop-shadow(0px 4px 8px rgba(0, 0, 0, 0.05))"
                                        },
                                        onClick: addToFavorite,
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            color: "primary",
                                            size: "small"
                                        })
                                    })
                                }),
                                isInWishList(storeDetails?.id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Tooltip, {
                                    text: "Add to cart",
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_product_details_section_ProductsThumbnailsSettings__WEBPACK_IMPORTED_MODULE_20__/* .RoundedIconButton */ .n, {
                                        onClick: ()=>deleteWishlistStore(storeDetails?.id),
                                        sx: {
                                            filter: "drop-shadow(0px 4px 8px rgba(0, 0, 0, 0.05))"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            color: "primary",
                                            size: "small"
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                    item: true,
                    xs: 12,
                    container: true,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                            item: true,
                            xs: 4,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                alignItems: "flex-start",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        sx: {
                                            fontSize: "18px",
                                            fontWeight: "bold"
                                        },
                                        children: [
                                            storeDetails?.positive_rating.toFixed(1),
                                            "%"
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        sx: {
                                            color: (theme)=>theme.palette.customColor.textGray,
                                            fontSize: isSmall ? "12px" : "inherit"
                                        },
                                        children: t("Positive Review")
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                            item: true,
                            xs: 4,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                alignItems: "flex-start",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        sx: {
                                            fontSize: "18px",
                                            fontWeight: "bold"
                                        },
                                        children: (0,helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_8__/* .getAmountWithSign */ .B9)(storeDetails?.minimum_order)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        sx: {
                                            color: (theme)=>theme.palette.customColor.textGray,
                                            fontSize: isSmall ? "12px" : "inherit"
                                        },
                                        children: t("Minimum Order")
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                            item: true,
                            xs: 4,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                alignItems: "flex-start",
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_17__/* .CustomStackFullWidth */ .Xw, {
                                        direction: "raw",
                                        alignItems: "center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                sx: {
                                                    fontSize: "18px",
                                                    fontWeight: "bold"
                                                },
                                                children: delievryTime?.[0]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                sx: {
                                                    fontSize: "18px"
                                                },
                                                children: delievryTime?.[1]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        sx: {
                                            color: (theme)=>theme.palette.customColor.textGray,
                                            fontSize: isSmall ? "12px" : "inherit"
                                        },
                                        children: t("Delivery Time")
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                    item: true,
                    xs: 12,
                    container: true,
                    spacing: 2,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Grid, {
                        item: true,
                        xs: 12,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_9___default()), {
                            href: {
                                pathname: "/store/[id]",
                                query: {
                                    id: `${storeDetails?.id}`,
                                    module_id: `${(0,helper_functions_getModuleId__WEBPACK_IMPORTED_MODULE_22__/* .getModuleId */ .S)()}`
                                }
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomButtons_style__WEBPACK_IMPORTED_MODULE_16__/* .CustomButtonPrimary */ .TG, {
                                fullwidth: "true",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                    children: t("Visit Store")
                                })
                            })
                        })
                    })
                })
            ]
        })
    });
};
StoreDetails.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_11___default().memo(StoreDetails));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 35168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);




const Details = ({ description  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
        color: "customColor.textGray",
        children: description
    });
};
Details.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Details);


/***/ }),

/***/ 73302:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var _Details__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(35168);
/* harmony import */ var _api_manage_hooks_react_query_product_details_useProductReviews__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(59093);
/* harmony import */ var _ProductReviews__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49007);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _api_manage_hooks_react_query_product_details_useProductReviews__WEBPACK_IMPORTED_MODULE_7__, _ProductReviews__WEBPACK_IMPORTED_MODULE_8__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_4__, _api_manage_hooks_react_query_product_details_useProductReviews__WEBPACK_IMPORTED_MODULE_7__, _ProductReviews__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);









const Wrapper = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper)(({ theme  })=>({
        padding: "16px",
        borderRadius: "5px",
        background: theme.palette.background.paper,
        boxShadow: "0px 10px 20px -3px rgba(145, 158, 171, 0.05), 0px 0px 2px 0px rgba(145, 158, 171, 0.20)"
    }));
const tabsData = [
    "Product Details",
    "Reviews"
];
const Tab = ({ item , selected , handleClick  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        alignItems: "center",
        justifyContent: "center",
        sx: {
            backgroundColor: (theme)=>selected === "true" && theme.palette.primary.main,
            padding: "10px 15px",
            borderRadius: "5px",
            color: (theme)=>selected === "true" && theme.palette.neutral[100],
            cursor: "pointer"
        },
        onClick: handleClick,
        children: item
    });
};
const CustomHeader = ({ info  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
        alignItems: "flex-start",
        justifyContent: "center",
        sx: {
            padding: "11px 30px",
            backgroundColor: (theme)=>theme.palette.neutral[300]
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
            fontWeight: "bold",
            component: "h2",
            children: t(info)
        })
    });
};
const DetailsAndReviews = (props)=>{
    const { description , reviews , configData , productId , storename  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const [tabs, setTabs] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(0);
    const [expanded, setExpanded] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(false);
    const contentRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    const [offSet, setOffSet] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(1);
    const [page_limits, setPageLimits] = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(10);
    const minHeightToShowButton = 200; // Replace with your specific height threshold
    const { data , refetch  } = (0,_api_manage_hooks_react_query_product_details_useProductReviews__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z)({
        productId,
        offSet,
        page_limits
    });
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        if (contentRef.current && contentRef.current.clientHeight > minHeightToShowButton) {
            setExpanded(true);
        }
    }, [
        minHeightToShowButton
    ]);
    const handleSeeMore = ()=>{
        setExpanded(true);
    };
    const handleSeeLess = ()=>{
        setExpanded(false);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        refetch();
    }, [
        productId,
        offSet
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
            alignItems: "center",
            justifyContent: "center",
            spacing: 2,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
                    alignItems: "center",
                    justifyContent: "center",
                    direction: "row",
                    spacing: 0.5,
                    children: tabsData.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Tab, {
                            item: item,
                            handleClick: ()=>setTabs(index),
                            selected: tabs === index ? "true" : "false"
                        }, index);
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomHeader, {
                    info: tabs === 0 ? "Description" : " Reviews"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw, {
                    p: "0px 30px",
                    children: [
                        tabs !== 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductReviews__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            reviews: data?.reviews?.slice(0, 1),
                            configData: configData,
                            total_size: data?.total_size,
                            offSet: offSet,
                            setOffSet: setOffSet,
                            page_limits: page_limits,
                            isExpanded: "true"
                        }),
                        tabs === 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Details__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                            description: description?.slice(0, 210)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Collapse, {
                            in: expanded,
                            children: tabs === 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Details__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                description: description?.slice(210)
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ProductReviews__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                                reviews: data?.reviews?.slice(1),
                                configData: configData,
                                total_size: data?.total_size,
                                offSet: offSet,
                                setOffSet: setOffSet,
                                page_limits: page_limits,
                                isExpanded: "false",
                                storename: storename
                            })
                        }),
                        tabs === 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                !expanded && description?.length > 110 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    sx: {
                                        textDecoration: "underline"
                                    },
                                    onClick: handleSeeMore,
                                    children: t("View More")
                                }),
                                expanded && description?.length > 110 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    sx: {
                                        textDecoration: "underline"
                                    },
                                    onClick: handleSeeLess,
                                    children: t("View Less")
                                })
                            ]
                        }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                            children: [
                                !expanded && data?.reviews?.length > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    sx: {
                                        textDecoration: "underline"
                                    },
                                    onClick: handleSeeMore,
                                    children: t("View More")
                                }),
                                expanded && data?.reviews?.length > 1 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                    sx: {
                                        textDecoration: "underline"
                                    },
                                    onClick: handleSeeLess,
                                    children: t("View Less")
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
DetailsAndReviews.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DetailsAndReviews);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5274:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(58861);
/* harmony import */ var _search_CustomRatings__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(27559);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(86390);
/* harmony import */ var _srollbar__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(92391);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(67934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_icons_material_Star__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(77849);
/* harmony import */ var _mui_icons_material_Star__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Star__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(81261);
/* harmony import */ var components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(7188);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_modal__WEBPACK_IMPORTED_MODULE_8__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_13__, components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_14__]);
([_modal__WEBPACK_IMPORTED_MODULE_8__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_13__, components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_14__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);















const ProductReviewCard = ({ review , storename  })=>{
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_7__.useSelector)((state)=>state.configData);
    const [openModal, setOpenModal] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const userImageUrl = configData?.base_urls?.customer_image_url;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                spacing: 7,
                sx: {
                    marginBottom: "35px"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                        direction: "row",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Avatar, {
                                src: `${userImageUrl}/${review?.customer?.image}`,
                                width: "42px",
                                height: "42px"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                        fontSize: "11px",
                                        fontWeight: "700",
                                        sx: {
                                            overflow: "hidden",
                                            textOverflow: "ellipsis",
                                            display: "-webkit-box",
                                            WebkitLineClamp: "1",
                                            WebkitBoxOrient: "vertical"
                                        },
                                        children: `${review?.customer?.f_name}` + " " + `${review?.customer?.l_name}`
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                        direction: "row",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Star__WEBPACK_IMPORTED_MODULE_12___default()), {
                                                color: "warning",
                                                style: {
                                                    width: "15px",
                                                    height: "15px"
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                component: "span",
                                                fontSize: "12px",
                                                ml: "5px",
                                                children: `${review?.rating}/5`
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                fontSize: "12px",
                                children: review?.comment
                            }),
                            review.reply && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box, {
                                sx: {
                                    background: theme.palette.neutral[300],
                                    padding: "13px",
                                    borderRadius: "9px"
                                },
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                        direction: "row",
                                        justifyContent: "space-between",
                                        alignItems: "center",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                fontSize: "12px",
                                                fontWeight: "500",
                                                color: theme.palette.text.primary,
                                                children: storename
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                                fontSize: "10px",
                                                fontWeight: "400",
                                                color: "text.secondary",
                                                children: (0,utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_13__/* .getDateFormat */ .mh)(review.updated_at)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                        mt: "5px",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_store_details_ReadMore__WEBPACK_IMPORTED_MODULE_14__/* .ReadMore */ .y, {
                                            font: "12px",
                                            color: theme.palette.text.secondary,
                                            limits: "130",
                                            children: review.reply
                                        })
                                    })
                                ]
                            }),
                            review?.attachment?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                                direction: "row",
                                spacing: 1,
                                children: JSON.parse(review?.attachment)?.map((item, index)=>{
                                    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        src: review?.customer?.image_full_url,
                                        width: "55px",
                                        height: "55px"
                                    }, index);
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_modal__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                openModal: openModal,
                handleClose: ()=>setOpenModal(false),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                    backgroundColor: theme.palette.neutral[300],
                    padding: "20px",
                    spacing: 1.5,
                    sx: {
                        borderRadius: ".9rem",
                        width: {
                            xs: "300px",
                            sm: "550px"
                        },
                        cursor: "pointer",
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                            onClick: ()=>setOpenModal(false),
                            sx: {
                                position: "absolute",
                                top: 0,
                                right: 3,
                                width: "45px",
                                borderRadius: "50%"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_10___default()), {})
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            src: review?.customer?.image_full_url,
                            width: "100%",
                            height: "100%"
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductReviewCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 47915:
/***/ ((module) => {

module.exports = require("@mui/icons-material");

/***/ }),

/***/ 1883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AccountCircle");

/***/ }),

/***/ 66146:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Add");

/***/ }),

/***/ 71507:
/***/ ((module) => {

module.exports = require("@mui/icons-material/AddCircleOutline");

/***/ }),

/***/ 95780:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowBackIosNew");

/***/ }),

/***/ 61883:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForward");

/***/ }),

/***/ 91658:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForwardIos");

/***/ }),

/***/ 71236:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ArrowForwardSharp");

/***/ }),

/***/ 52081:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Call");

/***/ }),

/***/ 7521:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChatBubbleOutline");

/***/ }),

/***/ 6959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Check");

/***/ }),

/***/ 39678:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CheckCircleOutlineOutlined");

/***/ }),

/***/ 66959:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronLeft");

/***/ }),

/***/ 52818:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ChevronRight");

/***/ }),

/***/ 51653:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Clear");

/***/ }),

/***/ 4173:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Close");

/***/ }),

/***/ 44486:
/***/ ((module) => {

module.exports = require("@mui/icons-material/CloudUpload");

/***/ }),

/***/ 29605:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ConfirmationNumber");

/***/ }),

/***/ 77926:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ControlPointOutlined");

/***/ }),

/***/ 99520:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Create");

/***/ }),

/***/ 83188:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Delete");

/***/ }),

/***/ 88566:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Directions");

/***/ }),

/***/ 89226:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Email");

/***/ }),

/***/ 8690:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Error");

/***/ }),

/***/ 88369:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ErrorOutlineOutlined");

/***/ }),

/***/ 27372:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Favorite");

/***/ }),

/***/ 6910:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorder");

/***/ }),

/***/ 25967:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FavoriteBorderOutlined");

/***/ }),

/***/ 77943:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FiberManualRecord");

/***/ }),

/***/ 9970:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FilterAltOutlined");

/***/ }),

/***/ 43866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FilterList");

/***/ }),

/***/ 50682:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Fullscreen");

/***/ }),

/***/ 64107:
/***/ ((module) => {

module.exports = require("@mui/icons-material/FullscreenExit");

/***/ }),

/***/ 15594:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GpsFixed");

/***/ }),

/***/ 74209:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GradeRounded");

/***/ }),

/***/ 49262:
/***/ ((module) => {

module.exports = require("@mui/icons-material/GridViewRounded");

/***/ }),

/***/ 27549:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Group");

/***/ }),

/***/ 73467:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Home");

/***/ }),

/***/ 60357:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ImportContacts");

/***/ }),

/***/ 64845:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowDown");

/***/ }),

/***/ 57834:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowLeft");

/***/ }),

/***/ 70547:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowRight");

/***/ }),

/***/ 99881:
/***/ ((module) => {

module.exports = require("@mui/icons-material/KeyboardArrowUp");

/***/ }),

/***/ 96866:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LibraryBooks");

/***/ }),

/***/ 50550:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalPhone");

/***/ }),

/***/ 29246:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocalShippingOutlined");

/***/ }),

/***/ 72625:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LocationOn");

/***/ }),

/***/ 12906:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Lock");

/***/ }),

/***/ 40399:
/***/ ((module) => {

module.exports = require("@mui/icons-material/LockOutlined");

/***/ }),

/***/ 89801:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Logout");

/***/ }),

/***/ 84552:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Loyalty");

/***/ }),

/***/ 9026:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Mail");

/***/ }),

/***/ 34702:
/***/ ((module) => {

module.exports = require("@mui/icons-material/MapsHomeWorkSharp");

/***/ }),

/***/ 63365:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Menu");

/***/ }),

/***/ 38996:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Pause");

/***/ }),

/***/ 52544:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PauseCircle");

/***/ }),

/***/ 31939:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Person");

/***/ }),

/***/ 86872:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Phone");

/***/ }),

/***/ 15214:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Place");

/***/ }),

/***/ 99272:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PlayArrow");

/***/ }),

/***/ 98618:
/***/ ((module) => {

module.exports = require("@mui/icons-material/PlayCircle");

/***/ }),

/***/ 19509:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Remove");

/***/ }),

/***/ 15642:
/***/ ((module) => {

module.exports = require("@mui/icons-material/RemoveRedEye");

/***/ }),

/***/ 49355:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Replay");

/***/ }),

/***/ 54527:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ReportProblem");

/***/ }),

/***/ 49426:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Room");

/***/ }),

/***/ 38017:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Search");

/***/ }),

/***/ 39823:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SendToMobile");

/***/ }),

/***/ 10032:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Settings");

/***/ }),

/***/ 74431:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShareLocation");

/***/ }),

/***/ 86983:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingBag");

/***/ }),

/***/ 6408:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartCheckout");

/***/ }),

/***/ 22749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartOutlined");

/***/ }),

/***/ 72548:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ShoppingCartRounded");

/***/ }),

/***/ 19766:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SmsRounded");

/***/ }),

/***/ 77849:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Star");

/***/ }),

/***/ 25776:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StarBorderSharp");

/***/ }),

/***/ 33378:
/***/ ((module) => {

module.exports = require("@mui/icons-material/StarRate");

/***/ }),

/***/ 64193:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Store");

/***/ }),

/***/ 86520:
/***/ ((module) => {

module.exports = require("@mui/icons-material/SwitchAccessShortcut");

/***/ }),

/***/ 73247:
/***/ ((module) => {

module.exports = require("@mui/icons-material/TextsmsRounded");

/***/ }),

/***/ 80858:
/***/ ((module) => {

module.exports = require("@mui/icons-material/ViewList");

/***/ }),

/***/ 50773:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Visibility");

/***/ }),

/***/ 77749:
/***/ ((module) => {

module.exports = require("@mui/icons-material/VisibilityOff");

/***/ }),

/***/ 9001:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Wallet");

/***/ }),

/***/ 65342:
/***/ ((module) => {

module.exports = require("@mui/icons-material/WarningAmber");

/***/ }),

/***/ 58979:
/***/ ((module) => {

module.exports = require("@mui/icons-material/Window");

/***/ }),

/***/ 86072:
/***/ ((module) => {

module.exports = require("@mui/lab");

/***/ }),

/***/ 76829:
/***/ ((module) => {

module.exports = require("@mui/lab/LoadingButton");

/***/ }),

/***/ 65692:
/***/ ((module) => {

module.exports = require("@mui/material");

/***/ }),

/***/ 83882:
/***/ ((module) => {

module.exports = require("@mui/material/AppBar");

/***/ }),

/***/ 19:
/***/ ((module) => {

module.exports = require("@mui/material/Box");

/***/ }),

/***/ 53819:
/***/ ((module) => {

module.exports = require("@mui/material/Button");

/***/ }),

/***/ 73691:
/***/ ((module) => {

module.exports = require("@mui/material/CardActions");

/***/ }),

/***/ 58455:
/***/ ((module) => {

module.exports = require("@mui/material/CardContent");

/***/ }),

/***/ 94960:
/***/ ((module) => {

module.exports = require("@mui/material/CssBaseline");

/***/ }),

/***/ 8611:
/***/ ((module) => {

module.exports = require("@mui/material/Dialog");

/***/ }),

/***/ 29404:
/***/ ((module) => {

module.exports = require("@mui/material/DialogActions");

/***/ }),

/***/ 1094:
/***/ ((module) => {

module.exports = require("@mui/material/DialogContent");

/***/ }),

/***/ 52468:
/***/ ((module) => {

module.exports = require("@mui/material/DialogTitle");

/***/ }),

/***/ 68891:
/***/ ((module) => {

module.exports = require("@mui/material/FormControl");

/***/ }),

/***/ 88185:
/***/ ((module) => {

module.exports = require("@mui/material/FormControlLabel");

/***/ }),

/***/ 76096:
/***/ ((module) => {

module.exports = require("@mui/material/FormLabel");

/***/ }),

/***/ 67934:
/***/ ((module) => {

module.exports = require("@mui/material/IconButton");

/***/ }),

/***/ 33103:
/***/ ((module) => {

module.exports = require("@mui/material/InputAdornment");

/***/ }),

/***/ 25545:
/***/ ((module) => {

module.exports = require("@mui/material/LinearProgress");

/***/ }),

/***/ 85246:
/***/ ((module) => {

module.exports = require("@mui/material/Link");

/***/ }),

/***/ 94192:
/***/ ((module) => {

module.exports = require("@mui/material/List");

/***/ }),

/***/ 31011:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemButton");

/***/ }),

/***/ 78315:
/***/ ((module) => {

module.exports = require("@mui/material/ListItemText");

/***/ }),

/***/ 55374:
/***/ ((module) => {

module.exports = require("@mui/material/Radio");

/***/ }),

/***/ 76563:
/***/ ((module) => {

module.exports = require("@mui/material/RadioGroup");

/***/ }),

/***/ 40441:
/***/ ((module) => {

module.exports = require("@mui/material/Skeleton");

/***/ }),

/***/ 27229:
/***/ ((module) => {

module.exports = require("@mui/material/Tooltip");

/***/ }),

/***/ 27163:
/***/ ((module) => {

module.exports = require("@mui/material/Typography");

/***/ }),

/***/ 18442:
/***/ ((module) => {

module.exports = require("@mui/material/styles");

/***/ }),

/***/ 69484:
/***/ ((module) => {

module.exports = require("@mui/styles");

/***/ }),

/***/ 97986:
/***/ ((module) => {

module.exports = require("@mui/system");

/***/ }),

/***/ 73280:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers");

/***/ }),

/***/ 6159:
/***/ ((module) => {

module.exports = require("@mui/x-date-pickers/DateCalendar");

/***/ }),

/***/ 82433:
/***/ ((module) => {

module.exports = require("@react-google-maps/api");

/***/ }),

/***/ 75184:
/***/ ((module) => {

module.exports = require("@reduxjs/toolkit");

/***/ }),

/***/ 2574:
/***/ ((module) => {

module.exports = require("base-64");

/***/ }),

/***/ 2296:
/***/ ((module) => {

module.exports = require("formik");

/***/ }),

/***/ 45567:
/***/ ((module) => {

module.exports = require("jwt-decode");

/***/ }),

/***/ 32245:
/***/ ((module) => {

module.exports = require("moment");

/***/ }),

/***/ 13332:
/***/ ((module) => {

module.exports = require("moment/moment");

/***/ }),

/***/ 83961:
/***/ ((module) => {

module.exports = require("next/dist/compiled/@edge-runtime/primitives/encoding");

/***/ }),

/***/ 53918:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 45732:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 92796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 69274:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 34014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 64486:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 50744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 35843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 99552:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 78524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 95832:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 78020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 64406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 24964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 11751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 46220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 10299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 23938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 29565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 35789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 28854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 91292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 34567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 80979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 93297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 36052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 84226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 82470:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 59232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 40618:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 40968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 71853:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 580:
/***/ ((module) => {

module.exports = require("prop-types");

/***/ }),

/***/ 16689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 31487:
/***/ ((module) => {

module.exports = require("react-apple-login");

/***/ }),

/***/ 14449:
/***/ ((module) => {

module.exports = require("react-countdown");

/***/ }),

/***/ 66405:
/***/ ((module) => {

module.exports = require("react-dom");

/***/ }),

/***/ 66804:
/***/ ((module) => {

module.exports = require("react-facebook-login/dist/facebook-login-render-props");

/***/ }),

/***/ 11022:
/***/ ((module) => {

module.exports = require("react-geolocated");

/***/ }),

/***/ 50801:
/***/ ((module) => {

module.exports = require("react-image-magnify");

/***/ }),

/***/ 64254:
/***/ ((module) => {

module.exports = require("react-otp-input");

/***/ }),

/***/ 25452:
/***/ ((module) => {

module.exports = require("react-phone-input-2");

/***/ }),

/***/ 28924:
/***/ ((module) => {

module.exports = require("react-player");

/***/ }),

/***/ 61175:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 6022:
/***/ ((module) => {

module.exports = require("react-redux");

/***/ }),

/***/ 38096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 20997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 14161:
/***/ ((module) => {

module.exports = require("redux-persist");

/***/ }),

/***/ 98936:
/***/ ((module) => {

module.exports = require("redux-persist/lib/storage");

/***/ }),

/***/ 94172:
/***/ ((module) => {

module.exports = require("simplebar-react");

/***/ }),

/***/ 93195:
/***/ ((module) => {

module.exports = require("stylis-plugin-rtl");

/***/ }),

/***/ 75609:
/***/ ((module) => {

module.exports = require("yup");

/***/ }),

/***/ 8440:
/***/ ((module) => {

module.exports = import("@emotion/cache");;

/***/ }),

/***/ 53139:
/***/ ((module) => {

module.exports = import("@emotion/react");;

/***/ }),

/***/ 4115:
/***/ ((module) => {

module.exports = import("@emotion/styled");;

/***/ }),

/***/ 99648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 23745:
/***/ ((module) => {

module.exports = import("firebase/app");;

/***/ }),

/***/ 60401:
/***/ ((module) => {

module.exports = import("firebase/auth");;

/***/ }),

/***/ 33512:
/***/ ((module) => {

module.exports = import("firebase/messaging");;

/***/ }),

/***/ 22021:
/***/ ((module) => {

module.exports = import("i18next");;

/***/ }),

/***/ 69915:
/***/ ((module) => {

module.exports = import("js-cookie");;

/***/ }),

/***/ 86201:
/***/ ((module) => {

module.exports = import("react-hot-toast");;

/***/ }),

/***/ 57987:
/***/ ((module) => {

module.exports = import("react-i18next");;

/***/ }),

/***/ 44009:
/***/ ((module) => {

module.exports = import("react-intersection-observer");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [3121,676,7760,9332,5269,5938,2177,3258,5899,4389,762,7251,2161,7145,1989,7847,3270,1074,5099,3265,4692,5694,9419,1741,4371,3423,2704], () => (__webpack_exec__(48972)));
module.exports = __webpack_exports__;

})();
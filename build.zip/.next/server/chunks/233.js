"use strict";
exports.id = 233;
exports.ids = [233,3602];
exports.modules = {

/***/ 10550:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useWishListGet)
/* harmony export */ });
/* unused harmony export WishList */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60274);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__]);
_MainApi__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const WishList = async ()=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .get_wish_list_api */ .RY}`);
    return data;
};
const useWishListGet = (onSuccessHandler)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)("wishlist", ()=>WishList(), {
        enabled: false,
        retry: false,
        onSuccess: onSuccessHandler
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 80233:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _map_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(76714);
/* harmony import */ var _landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(77591);
/* harmony import */ var _UseCurrentLocation__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60405);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45269);
/* harmony import */ var _mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(49426);
/* harmony import */ var _mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(57987);
/* harmony import */ var _api_manage_hooks_react_query_google_api_usePlaceAutoComplete__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(52073);
/* harmony import */ var _api_manage_hooks_react_query_google_api_useGetGeoCode__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(3586);
/* harmony import */ var _api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(55496);
/* harmony import */ var _api_manage_hooks_react_query_google_api_useGetPlaceDetails__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(99895);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _GoogleMapComponent__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(59138);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(86201);
/* harmony import */ var simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(48710);
/* harmony import */ var simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(simplebar_react_dist_simplebar_min_css__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(94172);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(simplebar_react__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _landing_page_hero_section_module_selection__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(44442);
/* harmony import */ var react_geolocated__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(11022);
/* harmony import */ var react_geolocated__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(react_geolocated__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var src_utils_toasterMessages__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(70557);
/* harmony import */ var _loading_spinners_FacebookLoading__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(70977);
/* harmony import */ var src_redux_slices_wishList__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(64134);
/* harmony import */ var src_api_manage_hooks_react_query_wish_list_useWishListGet__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(10550);
/* harmony import */ var src_helper_functions_getToken__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(61859);
/* harmony import */ var _ModalExtendShrink__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(44517);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_UseCurrentLocation__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_google_api_usePlaceAutoComplete__WEBPACK_IMPORTED_MODULE_10__, _api_manage_hooks_react_query_google_api_useGetGeoCode__WEBPACK_IMPORTED_MODULE_11__, _api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_12__, _api_manage_hooks_react_query_google_api_useGetPlaceDetails__WEBPACK_IMPORTED_MODULE_13__, react_hot_toast__WEBPACK_IMPORTED_MODULE_16__, _landing_page_hero_section_module_selection__WEBPACK_IMPORTED_MODULE_20__, src_api_manage_hooks_react_query_wish_list_useWishListGet__WEBPACK_IMPORTED_MODULE_24__]);
([_UseCurrentLocation__WEBPACK_IMPORTED_MODULE_5__, react_i18next__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_google_api_usePlaceAutoComplete__WEBPACK_IMPORTED_MODULE_10__, _api_manage_hooks_react_query_google_api_useGetGeoCode__WEBPACK_IMPORTED_MODULE_11__, _api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_12__, _api_manage_hooks_react_query_google_api_useGetPlaceDetails__WEBPACK_IMPORTED_MODULE_13__, react_hot_toast__WEBPACK_IMPORTED_MODULE_16__, _landing_page_hero_section_module_selection__WEBPACK_IMPORTED_MODULE_20__, src_api_manage_hooks_react_query_wish_list_useWishListGet__WEBPACK_IMPORTED_MODULE_24__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




























const MapModal = ({ open , handleClose , locationLoading , toparcel , handleLocation , disableAutoFocus , fromReceiver , fromStore , selectedLocation  })=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_19__.useRouter)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const isXSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.down("sm"));
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useSelector)((state)=>state.configData);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_9__.useTranslation)();
    const [searchKey, setSearchKey] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [enabled, setEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [geoLocationEnable, setGeoLocationEnable] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [predictions, setPredictions] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const [placeDetailsEnabled, setPlaceDetailsEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [locationEnabled, setLocationEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [placeId, setPlaceId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const [placeDescription, setPlaceDescription] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    const [location, setLocation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(selectedLocation ? selectedLocation : configData?.default_location);
    const [zoneId, setZoneId] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(undefined);
    const [isLoadingCurrentLocation, setLoadingCurrentLocation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [currentLocation, setCurrentLocation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({});
    const [rerenderMap, setRerenderMap] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [zoneIdEnabled, setZoneIdEnabled] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const [loadingAuto, setLoadingAuto] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isDisablePickButton, setDisablePickButton] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [isModalExpand, setIsModalExpand] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [currentLocationValue, setCurrentLactionValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        description: null
    });
    const [openModuleSelection, setOpenModuleSelection] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { data: places , isLoading: placesIsLoading  } = (0,_api_manage_hooks_react_query_google_api_usePlaceAutoComplete__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z)(searchKey, enabled);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_14__.useDispatch)();
    const { coords , isGeolocationAvailable , isGeolocationEnabled , getPosition  } = (0,react_geolocated__WEBPACK_IMPORTED_MODULE_21__.useGeolocated)({
        positionOptions: {
            enableHighAccuracy: false
        },
        userDecisionTimeout: 5000,
        isGeolocationEnabled: true
    });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (places) {
            setPredictions(places?.predictions);
        }
    }, [
        places
    ]);
    const { data: geoCodeResults , refetch: refetchCurrentLocation  } = (0,_api_manage_hooks_react_query_google_api_useGetGeoCode__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z)(location, geoLocationEnable);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (geoCodeResults) {
            setCurrentLactionValue({
                description: geoCodeResults?.results[0]?.formatted_address
            });
        } else {
            setCurrentLactionValue({
                description: ""
            });
        }
    }, [
        geoCodeResults
    ]);
    const { data: zoneData , error: errorLocation , isLoading  } = (0,_api_manage_hooks_react_query_google_api_useGetZone__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z)(location, zoneIdEnabled);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (false) {}
    }, [
        zoneData
    ]);
    const successHandler = ()=>{
        setLoadingAuto(false);
    };
    const { isLoading: isLoading2 , data: placeDetails  } = (0,_api_manage_hooks_react_query_google_api_useGetPlaceDetails__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)(placeId, placeDetailsEnabled, successHandler);
    //
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (placeDetails) {
            setLocation(placeDetails?.result?.geometry?.location);
        }
    }, [
        placeDetails
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (placeDescription) {
            setCurrentLocation(placeDescription);
        }
    }, [
        placeDescription
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (coords) {
            setCurrentLocation({
                lat: coords.latitude,
                lng: coords.longitude
            });
        }
    }, []);
    const handleLocationSelection = (value)=>{
        setPlaceId(value?.place_id);
        setPlaceDescription(value?.description);
    };
    const handleLocationSet = (values)=>{
        setLocation(values);
    };
    // get module from localstorage
    let selectedModule = undefined;
    if (false) {}
    const onSuccessHandler = (response)=>{
        dispatch((0,src_redux_slices_wishList__WEBPACK_IMPORTED_MODULE_23__/* .setWishList */ .Q5)(response));
    };
    const { refetch: wishlistRefetch , isLoading: isLoadingWishlist  } = (0,src_api_manage_hooks_react_query_wish_list_useWishListGet__WEBPACK_IMPORTED_MODULE_24__/* .useWishListGet */ .F)(onSuccessHandler);
    const handlePickLocationOnClick = ()=>{
        if (zoneId && geoCodeResults && location) {
            if ((0,src_helper_functions_getToken__WEBPACK_IMPORTED_MODULE_26__/* .getToken */ .L)()) {
                wishlistRefetch();
            }
            if (fromReceiver !== "1") {
                localStorage.setItem("zoneid", zoneId);
            }
            if (fromReceiver !== "1") {
                localStorage.setItem("location", geoCodeResults?.results[0]?.formatted_address);
                localStorage.setItem("currentLatLng", JSON.stringify(location));
            } else {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_16__["default"].success(t("New location has been set."));
            }
            if (toparcel === "1") {
                handleLocation(location, geoCodeResults?.results[0]?.formatted_address);
                handleClose();
            } else {
                if (fromStore) {
                    handleClose();
                } else {
                    setOpenModuleSelection(true);
                }
            }
        }
    };
    const handleCloseModuleModal = (item)=>{
        if (item) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_16__["default"].success(t(src_utils_toasterMessages__WEBPACK_IMPORTED_MODULE_27__/* .module_select_success */ .Zq));
            router.push("/home", undefined, {
                shallow: true
            });
        }
        setOpenModuleSelection(false);
        handleClose?.();
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Modal, {
                open: open,
                onClose: handleClose,
                closeAfterTransition: true,
                slots: {
                    backdrop: _mui_material__WEBPACK_IMPORTED_MODULE_2__.Backdrop
                },
                slotProps: {
                    backdrop: {
                        timeout: 500
                    }
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_map_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomBoxWrapper */ .A7, {
                    expand: isModalExpand ? "true" : "false",
                    sx: {
                        display: openModuleSelection ? "none" : "inherit",
                        padding: {
                            xs: "15px",
                            md: "2rem"
                        },
                        borderRadius: isModalExpand ? "0px" : {
                            xs: "8px",
                            md: "20px"
                        },
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton, {
                            onClick: handleClose,
                            sx: {
                                position: "absolute",
                                top: 5,
                                right: 8,
                                zIndex: 999
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_6___default()), {
                                sx: {
                                    fontSize: {
                                        xs: "18px",
                                        md: "24px"
                                    }
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomStackFullWidth */ .Xw, {
                            spacing: 2,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((simplebar_react__WEBPACK_IMPORTED_MODULE_18___default()), {
                                style: {
                                    maxHeight: isModalExpand ? "100vh" : "65vh",
                                    paddingRight: "15px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontSize: {
                                            xs: "14px",
                                            md: "1rem"
                                        },
                                        fontWeight: 500,
                                        children: t("Pick Location")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        fontSize: {
                                            xs: "12px",
                                            md: "14px"
                                        },
                                        fontWeight: 400,
                                        color: theme.palette.neutral[500],
                                        children: t("Sharing your accurate location enhances precision in search results and delivery estimates, ensures effortless order delivery.")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomStackFullWidth */ .Xw, {
                                        children: loadingAuto ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                                            width: "100%",
                                            height: "40px",
                                            variant: "rectangular"
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Autocomplete, {
                                            fullWidth: true,
                                            freeSolo: true,
                                            id: "combo-box-demo",
                                            getOptionLabel: (option)=>option.description,
                                            options: predictions,
                                            onChange: (event, value)=>{
                                                if (value) {
                                                    if (value !== "" && typeof value === "string") {
                                                        setLoadingAuto(true);
                                                        const value1 = places?.predictions?.[0];
                                                        handleLocationSelection(value1);
                                                    } else {
                                                        handleLocationSelection(value);
                                                    }
                                                }
                                                setPlaceDetailsEnabled(true);
                                            },
                                            clearOnBlur: false,
                                            value: currentLocationValue,
                                            loading: placesIsLoading,
                                            loadingText: t("Search suggestions are loading..."),
                                            renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_4__/* .SearchLocationTextField */ .l7, {
                                                    sx: {
                                                        borderRadius: "4px",
                                                        border: (theme)=>`1px solid ${theme.palette.neutral[200]}`
                                                    },
                                                    frommap: "true",
                                                    label: null,
                                                    ...params,
                                                    placeholder: t("Search location"),
                                                    onChange: (event)=>{
                                                        setSearchKey(event.target.value);
                                                        if (event.target.value) {
                                                            setEnabled(true);
                                                        } else {
                                                            setEnabled(false);
                                                        }
                                                    },
                                                    onKeyPress: (e)=>{
                                                        if (e.key === "Enter") {
                                                            setSearchKey(e.target.value);
                                                        }
                                                    }
                                                })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomBoxFullWidth */ .uu, {
                                        sx: {
                                            mt: 2,
                                            color: (theme)=>theme.palette.neutral[1000],
                                            p: "5px",
                                            position: "relative"
                                        },
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_map_style__WEBPACK_IMPORTED_MODULE_3__/* .LocationView */ .zY, {
                                                children: geoCodeResults?.results?.length > 0 ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: [
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Room__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                            fontSize: "small",
                                                            color: "primary"
                                                        }),
                                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                            children: geoCodeResults?.results[0]?.formatted_address
                                                        })
                                                    ]
                                                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Skeleton, {
                                                        variant: "rounded",
                                                        width: 300,
                                                        height: 20
                                                    })
                                                })
                                            }),
                                            !!location ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_GoogleMapComponent__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                                                setDisablePickButton: setDisablePickButton,
                                                setLocationEnabled: setLocationEnabled,
                                                setLocation: handleLocationSet,
                                                setCurrentLocation: setCurrentLocation,
                                                locationLoading: locationLoading,
                                                location: location,
                                                setPlaceDetailsEnabled: setPlaceDetailsEnabled,
                                                placeDetailsEnabled: placeDetailsEnabled,
                                                locationEnabled: locationEnabled,
                                                setPlaceDescription: setPlaceDescription,
                                                isModalExpand: isModalExpand
                                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomStackFullWidth */ .Xw, {
                                                alignItems: "center",
                                                justifyContent: "center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_loading_spinners_FacebookLoading__WEBPACK_IMPORTED_MODULE_22__/* .FacebookCircularProgress */ .V, {}),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomTypographyGray */ .mI, {
                                                        nodefaultfont: "true",
                                                        children: t("Please wait sometimes")
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_map_style__WEBPACK_IMPORTED_MODULE_3__/* .WrapperCurrentLocationPick */ .b4, {
                                                alignItems: "center",
                                                isXsmall: isXSmall,
                                                spacing: {
                                                    xs: 1,
                                                    md: 2
                                                },
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ModalExtendShrink__WEBPACK_IMPORTED_MODULE_25__/* ["default"] */ .Z, {
                                                        isModalExpand: isModalExpand,
                                                        setIsModalExpand: setIsModalExpand,
                                                        t: t
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_UseCurrentLocation__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                                        setLoadingCurrentLocation: setLoadingCurrentLocation,
                                                        setLocationEnabled: setLocationEnabled,
                                                        setLocation: setLocation,
                                                        coords: coords,
                                                        refetchCurrentLocation: refetchCurrentLocation,
                                                        setRerenderMap: setRerenderMap,
                                                        isLoadingCurrentLocation: isLoadingCurrentLocation,
                                                        isGeolocationEnabled: isGeolocationEnabled
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CustomStackFullWidth */ .Xw, {
                                        justifyCenter: "center",
                                        alignItems: "center",
                                        children: errorLocation?.response?.data ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button, {
                                            "aria-label": "picklocation",
                                            sx: {
                                                flex: "1 0",
                                                width: "100%",
                                                top: "-3rem"
                                            },
                                            disabled: locationLoading,
                                            variant: "contained",
                                            color: "error",
                                            onClick: ()=>{
                                                if (zoneId) {
                                                    localStorage.setItem("zoneid", zoneId);
                                                }
                                                handleClose();
                                            },
                                            children: errorLocation?.response?.data?.errors[0]?.message
                                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_map_style__WEBPACK_IMPORTED_MODULE_3__/* .PrimaryButton */ .KM, {
                                            disabled: isLoading || !geoCodeResults?.results[0]?.formatted_address,
                                            variant: "contained",
                                            onClick: ()=>handlePickLocationOnClick(),
                                            children: t("Pick Locations")
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            openModuleSelection && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_landing_page_hero_section_module_selection__WEBPACK_IMPORTED_MODULE_20__/* .ModuleSelection */ .U, {
                location: currentLocation,
                closeModal: handleCloseModuleModal,
                disableAutoFocus: disableAutoFocus
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (/*#__PURE__*/(0,react__WEBPACK_IMPORTED_MODULE_1__.memo)(MapModal));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 44517:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_Fullscreen__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(50682);
/* harmony import */ var _mui_icons_material_Fullscreen__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Fullscreen__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_FullscreenExit__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64107);
/* harmony import */ var _mui_icons_material_FullscreenExit__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FullscreenExit__WEBPACK_IMPORTED_MODULE_5__);






const Wrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.IconButton)(({ theme , isXSmall  })=>({
        boxShadow: "0px 4.48276px 11.2069px rgba(0, 0, 0, 0.1)",
        borderRadius: "3.36207px",
        width: isXSmall ? "28px" : "35px",
        height: isXSmall ? "28px" : "35px",
        position: "relative",
        color: theme.palette.primary.main,
        backgroundColor: theme.palette.background.paper,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer"
    }));
const ModalExtendShrink = (props)=>{
    const { isModalExpand , setIsModalExpand , t  } = props;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    const isXSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
        isXSmall: isXSmall,
        onClick: ()=>setIsModalExpand((prev)=>!prev),
        children: isModalExpand ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
            title: t("Close fullscreen"),
            arrow: true,
            placement: "top",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FullscreenExit__WEBPACK_IMPORTED_MODULE_5___default()), {
                sx: {
                    fontSize: {
                        xs: "18px",
                        md: "24px"
                    }
                }
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
            title: t("Fullscreen"),
            arrow: true,
            placement: "top",
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Fullscreen__WEBPACK_IMPORTED_MODULE_4___default()), {
                sx: {
                    fontSize: {
                        xs: "18px",
                        md: "24px"
                    }
                }
            })
        })
    });
};
ModalExtendShrink.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModalExtendShrink);


/***/ }),

/***/ 60405:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(76829);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15594);
/* harmony import */ var _mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22021);
/* harmony import */ var _AllowLocationDialog__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(17009);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_4__, _AllowLocationDialog__WEBPACK_IMPORTED_MODULE_5__]);
([i18next__WEBPACK_IMPORTED_MODULE_4__, _AllowLocationDialog__WEBPACK_IMPORTED_MODULE_5__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const UseCurrentLocation = ({ isLoadingCurrentLocation , setLoadingCurrentLocation , setLocationEnabled , setLocation , zoneId , refetchCurrentLocation , setRerenderMap , isGeolocationEnabled , coords  })=>{
    const [openLocation, setOpenLocation] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const handleCloseLocation = ()=>{
        setOpenLocation(false);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.IconButton, {
                sx: {
                    borderRadius: "50%",
                    color: (theme)=>theme.palette.primary.main,
                    backgroundColor: "background.paper",
                    boxShadow: "0px 4.48276px 11.2069px rgba(0, 0, 0, 0.1)",
                    width: {
                        xs: "28px",
                        md: "35px"
                    },
                    height: {
                        xs: "28px",
                        md: "35px"
                    },
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center"
                },
                onClick: async (e)=>{
                    e.preventDefault();
                    if (coords) {
                        setLoadingCurrentLocation(true);
                        setLocationEnabled(true);
                        setLocation({
                            lat: coords?.latitude,
                            lng: coords?.longitude
                        });
                        setLoadingCurrentLocation(false);
                        if (zoneId) {
                            localStorage.setItem("zoneid", zoneId);
                        // router.push('/home')
                        // handleClose()
                        }
                        await refetchCurrentLocation();
                        setRerenderMap((prevState)=>!prevState);
                    } else {
                        setOpenLocation(true);
                    }
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_3___default()), {
                    sx: {
                        fontSize: {
                            xs: "18px",
                            md: "24px"
                        }
                    }
                })
            }),
            openLocation && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_AllowLocationDialog__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                handleCloseLocation: handleCloseLocation,
                openLocation: openLocation,
                isGeolocationEnabled: isGeolocationEnabled
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (UseCurrentLocation);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 70977:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V": () => (/* binding */ FacebookCircularProgress)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



function FacebookCircularProgress(props) {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            position: "relative"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                variant: "determinate",
                sx: {
                    color: (theme)=>theme.palette.grey[theme.palette.mode === "light" ? 200 : 800]
                },
                size: 25,
                thickness: 4,
                ...props,
                value: 100
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
                variant: "indeterminate",
                disableShrink: true,
                sx: {
                    color: (theme)=>theme.palette.primary.main,
                    animationDuration: "550ms",
                    position: "absolute",
                    left: 0,
                    [`& .${_mui_material__WEBPACK_IMPORTED_MODULE_2__.circularProgressClasses.circle}`]: {
                        strokeLinecap: "round"
                    }
                },
                size: 25,
                thickness: 4,
                ...props
            })
        ]
    });
}


/***/ })

};
;
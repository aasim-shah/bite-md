"use strict";
exports.id = 762;
exports.ids = [762];
exports.modules = {

/***/ 34199:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(15214);
/* harmony import */ var _mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_3__);




const PlaceIconComponent = (props)=>{
    const { fontSize , color  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Place__WEBPACK_IMPORTED_MODULE_3___default()), {
            sx: {
                fontSize: fontSize,
                color: color
            }
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlaceIconComponent);


/***/ }),

/***/ 77994:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(33378);
/* harmony import */ var _mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_3__);




const RatingStar = (props)=>{
    const { fontSize , color  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_3___default()), {
            sx: {
                fontSize: fontSize,
                color: color
            }
        })
    });
};
RatingStar.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (RatingStar);


/***/ }),

/***/ 20762:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "o": () => (/* binding */ HeartWrapper)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(83188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6910);
/* harmony import */ var _mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22021);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(86201);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(80697);
/* harmony import */ var _api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(93706);
/* harmony import */ var _redux_slices_wishList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(64134);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(45269);
/* harmony import */ var _styled_components_TextWithEllipsis__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(53556);
/* harmony import */ var _utils_toasterMessages__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(70557);
/* harmony import */ var _closed_now__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(9076);
/* harmony import */ var _custom_dialog_confirm_CustomDialogConfirm__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2922);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(58861);
/* harmony import */ var _PlaceIconComponent__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(34199);
/* harmony import */ var _RatingStar__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(77994);
/* harmony import */ var utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(81261);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_6__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_11__, _api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_12__, _closed_now__WEBPACK_IMPORTED_MODULE_16__, _custom_dialog_confirm_CustomDialogConfirm__WEBPACK_IMPORTED_MODULE_17__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__]);
([i18next__WEBPACK_IMPORTED_MODULE_6__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, _api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_11__, _api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_12__, _closed_now__WEBPACK_IMPORTED_MODULE_16__, _custom_dialog_confirm_CustomDialogConfirm__WEBPACK_IMPORTED_MODULE_17__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_21__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























const CardWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Paper)(({ theme  })=>({
        padding: "2rem 1rem",
        height: "100%",
        boxShadow: "0px 5px 15px -3px rgba(0, 0, 0, 0.1)",
        cursor: "pointer",
        position: "relative",
        "&:hover": {
            boxShadow: "10px 25px 45px -3px rgba(0, 0, 0, 0.1)"
        }
    }));
const ImageWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Box)(({ theme  })=>({
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        height: "80px",
        width: "80px",
        borderRadius: "50%",
        border: "3px solid",
        borderColor: theme.palette.secondary.light,
        position: "relative"
    }));
const HeartWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton)(({ theme , top , right  })=>({
        zIndex: 1,
        width: "30px",
        height: "30px",
        boxShadow: "0px 4px 4px rgba(0, 0, 0, 0.1)",
        position: "absolute",
        top: top,
        textAlign: "center",
        right: right,
        color: theme.palette.pink.main
    }));
const StoresInfoCard = (props)=>{
    const { data , wishlistcard  } = props;
    const id = data?.id ? data?.id : data?.slug;
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.configData);
    const store_image_url = `${configData?.base_urls?.store_image_url}`;
    const moduleId = JSON.parse(window.localStorage.getItem("module"))?.id;
    const [openModal, setOpenModal] = react__WEBPACK_IMPORTED_MODULE_8___default().useState(false);
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useDispatch)();
    const [fav, setFav] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const classes = (0,_styled_components_TextWithEllipsis__WEBPACK_IMPORTED_MODULE_15__/* .textWithEllipsis */ .C)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.useTheme)();
    const gray = theme.palette.neutral[400];
    const { wishLists  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_10__.useSelector)((state)=>state.wishList);
    let token = undefined;
    if (false) {}
    const { mutate: addFavoriteMutation  } = (0,_api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_11__/* .useAddStoreToWishlist */ .v)();
    const addToFavorite = ()=>{
        if (token) {
            addFavoriteMutation(id, {
                onSuccess: (response)=>{
                    if (response) {
                        dispatch((0,_redux_slices_wishList__WEBPACK_IMPORTED_MODULE_13__/* .addWishListStore */ .KO)(data));
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].success(response?.message);
                    }
                },
                onError: (error)=>{
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error(error.response.data.message);
                }
            });
        } else react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)(_utils_toasterMessages__WEBPACK_IMPORTED_MODULE_22__/* .not_logged_in_message */ .XO));
    };
    const isInList = (id)=>{
        return !!wishLists?.store?.find((wishStore)=>wishStore.id === id);
    };
    const onSuccessHandlerForDelete = (res)=>{
        dispatch((0,_redux_slices_wishList__WEBPACK_IMPORTED_MODULE_13__/* .removeWishListStore */ .$X)(id));
        react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].success(res.message, {
            id: "wishlist"
        });
    };
    const { mutate  } = (0,_api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_12__/* .useWishListStoreDelete */ .K)();
    const deleteWishlistStore = (id)=>{
        mutate(id, {
            onSuccess: onSuccessHandlerForDelete,
            onError: (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error(error.response.data.message);
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
        sx: {
            position: "relative",
            height: "100%"
        },
        children: [
            wishlistcard === "true" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeartWrapper, {
                onClick: ()=>setOpenModal(true),
                top: "4%",
                right: "5%",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_1___default()), {
                    style: {
                        color: theme.palette.error.light
                    }
                })
            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    !isInList(id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeartWrapper, {
                        onClick: addToFavorite,
                        top: "4%",
                        right: "5%",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FavoriteBorder__WEBPACK_IMPORTED_MODULE_3___default()), {})
                    }),
                    isInList(id) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(HeartWrapper, {
                        onClick: ()=>deleteWishlistStore(id),
                        top: "4%",
                        right: "5%",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_2___default()), {})
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_7___default()), {
                href: {
                    pathname: "/store/[id]",
                    query: {
                        id: `${id}`,
                        module_id: `${moduleId}`
                    },
                    store_zone_id: `${data?.zone_id}`
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CardWrapper, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_14__/* .CustomStackFullWidth */ .Xw, {
                        alignItems: "center",
                        justifyContent: "center",
                        spacing: 0.5,
                        sx: {
                            height: "100%"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ImageWrapper, {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z, {
                                        src: data?.logo_full_url,
                                        alt: data?.name,
                                        height: "100%",
                                        width: "100%",
                                        objectFit: "cover",
                                        borderRadius: "50%"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_closed_now__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                        active: data?.active,
                                        open: data?.open,
                                        borderRadius: "50%"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                textAlign: "center",
                                fontWeight: "bold",
                                className: classes.multiLineEllipsis,
                                maxHeight: "40px",
                                children: data?.name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                                direction: "row",
                                alignItems: "center",
                                justifyContent: "center",
                                spacing: 0.5,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        fontWeight: "bold",
                                        children: data?.avg_rating.toFixed(1)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_RatingStar__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {
                                        fontSize: "16px",
                                        color: "warning.dark"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                                direction: "row",
                                alignItems: "center",
                                justifyContent: "center",
                                spacing: 0.5,
                                alignSelf: wishlistcard === "true" ? "center" : "flex-end",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_PlaceIconComponent__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                                        fontSize: "20px",
                                        color: gray
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        variant: "body2",
                                        color: gray,
                                        className: classes.multiLineEllipsis,
                                        children: data?.address
                                    })
                                ]
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_dialog_confirm_CustomDialogConfirm__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                dialogTexts: (0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Are you sure you want to  delete this item?"),
                open: openModal,
                onClose: ()=>setOpenModal(false),
                onSuccess: ()=>deleteWishlistStore(id)
            })
        ]
    });
};
StoresInfoCard.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StoresInfoCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
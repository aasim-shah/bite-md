"use strict";
exports.id = 3265;
exports.ids = [3265];
exports.modules = {

/***/ 82940:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(53139);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(46573);
/* harmony import */ var _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(95785);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react__WEBPACK_IMPORTED_MODULE_1__, _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react__WEBPACK_IMPORTED_MODULE_1__, _group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const CustomCheckbox = (props)=>{
    const { item , checkHandler , isChecked , selectedId  } = props;
    const [checked, setChecked] = react__WEBPACK_IMPORTED_MODULE_3___default().useState(false);
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const checkboxRef = (0,react__WEBPACK_IMPORTED_MODULE_3__.useRef)(null);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        setChecked(isChecked);
    }, [
        isChecked
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_3__.useEffect)(()=>{
        checkboxRef.current.focus();
    }, [
        checked
    ]);
    const handleChange = (event)=>{
        setChecked(event.target.checked);
        checkHandler?.({
            checked: event.target.checked,
            id: item?.id,
            value: event.target.value
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.FormControlLabel, {
        ref: checkboxRef,
        control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_group_buttons_OutlinedGroupButtons__WEBPACK_IMPORTED_MODULE_4__/* .StyleCheckBox */ .w, {
            ref: checkboxRef,
            module: (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_5__/* .getModule */ .r)()?.module_type,
            value: item?.value,
            checked: checked,
            onChange: handleChange,
            inputProps: {
                "aria-label": "controlled"
            }
        }),
        label: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
            color: theme.palette.text.primary,
            fontSize: "13px",
            children: item?.name
        })
    });
};
CustomCheckbox.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomCheckbox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 33000:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(38017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57987);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(76829);
/* harmony import */ var _mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(45269);
/* harmony import */ var _CustomSearch_style__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(63270);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(90603);
/* harmony import */ var helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(42604);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
react_i18next__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];











const CustomSearch = ({ handleSearchResult , label , isLoading , selectedValue , setIsEmpty , setSearchValue , type2  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    const [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    let language_direction = undefined;
    if (false) {}
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (selectedValue) {
            setValue(selectedValue);
        } else {
            setValue("");
        }
    }, [
        selectedValue
    ]);
    const handleKeyPress = (e)=>{
        if (e.key === "Enter") {
            handleSearchResult(e.target.value);
            e.preventDefault();
        }
    };
    const remove = "true";
    const handleReset = ()=>{
        setValue("");
        handleSearchResult?.("", remove);
        setIsEmpty?.(true);
    };
    const handleChange = (value)=>{
        if (value === "") {
            handleSearchResult?.("");
            setIsEmpty?.(true);
        } else {
            setIsEmpty?.(false);
        }
        setValue(value);
        setSearchValue?.(value);
    };
    const getTypeWiseChanges = ()=>{
        if (type2) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_2___default()), {
                        sx: {
                            color: (theme)=>(0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_10__/* .getCurrentModuleType */ .X)() === helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_9__/* .ModuleTypes.FOOD */ .J.FOOD ? theme.palette.moduleTheme.food : "primary.main",
                            marginInlineStart: "15px",
                            marginInlineEnd: "-8px"
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomSearch_style__WEBPACK_IMPORTED_MODULE_8__/* .StyledInputBase */ .e, {
                        placeholder: t(label),
                        value: value,
                        onChange: (e)=>handleChange(e.target.value),
                        onKeyPress: (e)=>handleKeyPress(e),
                        language_direction: language_direction
                    })
                ]
            });
        } else {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomSearch_style__WEBPACK_IMPORTED_MODULE_8__/* .StyledInputBase */ .e, {
                        placeholder: t(label),
                        value: value,
                        onChange: (e)=>handleChange(e.target.value),
                        onKeyPress: (e)=>handleKeyPress(e),
                        language_direction: language_direction
                    }),
                    value === "" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_2___default()), {
                        sx: {
                            marginInlineEnd: "12px"
                        }
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: isLoading ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CloseIconWrapper */ .B7, {
                            right: -1,
                            language_direction: language_direction,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_lab_LoadingButton__WEBPACK_IMPORTED_MODULE_6___default()), {
                                loading: true,
                                variant: "text",
                                sx: {
                                    width: "10px"
                                }
                            })
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_7__/* .CloseIconWrapper */ .B7, {
                            onClick: ()=>handleReset(),
                            language_direction: language_direction,
                            right: "20px",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.IconButton, {
                                sx: {
                                    marginRight: "-4px !important"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    fontSize: "small"
                                })
                            })
                        })
                    })
                ]
            });
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("form", {
        onSubmit: handleKeyPress,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomSearch_style__WEBPACK_IMPORTED_MODULE_8__/* .Search */ .o, {
            direction: "row",
            alignItems: "center",
            type2: type2,
            children: getTypeWiseChanges()
        })
    });
};
CustomSearch.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomSearch);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 95785:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "w": () => (/* binding */ StyleCheckBox)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _store_details_buttonsData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(43877);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57987);
/* harmony import */ var _CustomCheckbox__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(82940);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__, _CustomCheckbox__WEBPACK_IMPORTED_MODULE_7__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_6__, _CustomCheckbox__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const StyleCheckBox = (0,_mui_system__WEBPACK_IMPORTED_MODULE_3__.styled)(({ checkedColor , ...other })=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Checkbox, {
        ...other
    }))(({ checkedColor , module , theme  })=>({
        "& .MuiIconButton-label": {
            color: checkedColor
        },
        "&.Mui-checked": {
            color: module === "food" ? theme.palette.moduleTheme.food : theme.palette.mian,
            "& .MuiIconButton-label": {
                color: theme.palette.neutral[100]
            }
        }
    }));
const VegNonVegCheckBox = (props)=>{
    const { data , selected , handleSelection , setCheckState , checkState  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useTheme)();
    const handleChange = (event)=>{
        setCheckState({
            ...checkState,
            [event.target.name]: event.target.checked
        });
    };
    const getModule = ()=>{
        return JSON.parse(window.localStorage.getItem("module"));
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Stack, {
        direction: "row",
        alignItems: "center",
        spacing: 2,
        width: "100%",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormControlLabel, {
                control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyleCheckBox, {
                    module: getModule()?.module_type,
                    checked: checkState?.veg,
                    onChange: handleChange,
                    name: "veg"
                }),
                label: t("Veg")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.FormControlLabel, {
                control: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StyleCheckBox, {
                    module: getModule()?.module_type,
                    checked: checkState?.non_veg,
                    onChange: handleChange,
                    name: "non_veg"
                }),
                label: t("Non-Veg")
            })
        ]
    });
};
VegNonVegCheckBox.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VegNonVegCheckBox);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 11629:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ search_CustomSlider)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(65692);
// EXTERNAL MODULE: external "react-redux"
var external_react_redux_ = __webpack_require__(6022);
;// CONCATENATED MODULE: ./src/components/first-render-useeffect-controller/useIsMount.js

const useIsMount = ()=>{
    const isMountRef = (0,external_react_.useRef)(true);
    (0,external_react_.useEffect)(()=>{
        isMountRef.current = false;
    }, []);
    return isMountRef.current;
};

;// CONCATENATED MODULE: ./src/components/search/CustomSlider.js





const StyledSlider = (0,material_.styled)(material_.Slider)(({ theme  })=>({
        "& .MuiSlider-rail": {
            height: "5px",
            marginLeft: "10px",
            backgroundColor: theme.palette.neutral[600]
        },
        "& .MuiSlider-thumb": {
            backgroundColor: theme.palette.neutral[100],
            border: `4px solid ${theme.palette.primary.main}`,
            boxShadow: "0px 2px 4px rgba(9, 87, 203, 0.15)"
        }
    }));
const CustomSlider = ({ handleChangePrice , minMax , priceFilterRange , store  })=>{
    const { filterData  } = (0,external_react_redux_.useSelector)((state)=>state.searchFilterStore);
    const [value, setValue] = (0,external_react_.useState)(minMax);
    const minDistance = 1;
    const isMount = useIsMount();
    const handleChange = (event, newValue, activeThumb)=>{
        if (!Array.isArray(newValue)) {
            return;
        }
        if (activeThumb === 0) {
            setValue([
                Math.min(newValue[0], value[1] - minDistance),
                value[1]
            ]);
        } else {
            setValue([
                value[0],
                Math.max(newValue[1], value[0] + minDistance)
            ]);
        }
    };
    const handleChangeCommitted = (event, newValue)=>{
        handleChangePrice(newValue);
    };
    // useEffect(() => {
    //   if (!isMount) {
    //     handleChangePrice(value);
    //   }
    // }, [value]);
    return /*#__PURE__*/ jsx_runtime_.jsx(material_.Stack, {
        direction: "row",
        sx: {
            mb: 1,
            ml: 1
        },
        alignItems: "center",
        spacing: 1,
        px: ".7rem",
        children: /*#__PURE__*/ jsx_runtime_.jsx(StyledSlider, {
            value: value,
            onChange: handleChange,
            onChangeCommitted: handleChangeCommitted,
            valueLabelDisplay: "auto",
            disabled: store ? priceFilterRange?.min_price === priceFilterRange?.max_price : priceFilterRange[0] === priceFilterRange[1],
            min: 0,
            max: 20000,
            marks: [
                {
                    value: 0
                },
                {
                    value: 100
                }
            ],
            disableSwap: true
        })
    });
};
/* harmony default export */ const search_CustomSlider = (CustomSlider);


/***/ }),

/***/ 43877:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* unused harmony export buttonsData */
const buttonsData = [
    {
        name: "Veg",
        value: "veg"
    },
    {
        name: "Non-Veg",
        value: "non_veg"
    }
];


/***/ }),

/***/ 24275:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45269);
/* harmony import */ var _CustomCheckbox__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(82940);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(64845);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(99881);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_7__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CustomCheckbox__WEBPACK_IMPORTED_MODULE_5__]);
_CustomCheckbox__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const CheckboxWithChild = (props)=>{
    const { item , checkHandler , selectedItems  } = props;
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);
    const clickHandler = ()=>{
        setOpen((prev)=>!prev);
    };
    const isCheckedHandler = (id)=>{
        const isExist = selectedItems?.find((item)=>item === id);
        return !!isExist;
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomBoxFullWidth */ .uu, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Stack, {
                direction: "row",
                alignItems: "center",
                justifyContent: "space-between",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomCheckbox__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                        item: item,
                        checkHandler: checkHandler,
                        isChecked: ()=>isCheckedHandler(item?.id)
                    }),
                    item?.childes?.length > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                        children: open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_7___default()), {
                            onClick: clickHandler,
                            color: "primary",
                            sx: {
                                cursor: "pointer"
                            }
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_6___default()), {
                            color: "primary",
                            onClick: clickHandler,
                            sx: {
                                cursor: "pointer"
                            }
                        })
                    })
                ]
            }),
            open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: item?.childes?.map((childItem, childIndex)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomStackFullWidth */ .Xw, {
                        sx: {
                            padding: "0px 16px"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomCheckbox__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            item: childItem,
                            checkHandler: checkHandler,
                            isChecked: ()=>isCheckedHandler(childItem?.id)
                        })
                    }, childIndex))
            })
        ]
    });
};
CheckboxWithChild.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CheckboxWithChild);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 87296:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _assets_sort_png__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6189);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(64845);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(99881);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58861);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const Wrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Button)(({ theme , border  })=>({
        border: border === "true" && `1px solid ${theme.palette.neutral[400]}`,
        borderRadius: "5px",
        padding: "7px 16px",
        textTransform: "capitalize"
    }));
const HighToLow = ({ handleSortBy , sortBy  })=>{
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    const handleClose = ()=>{
        setAnchorEl(null);
    };
    const handleSelect = (value)=>{
        handleSortBy?.(value);
        setAnchorEl(null);
    };
    const open = Boolean(anchorEl);
    const id = open ? "simple-popover" : undefined;
    const sortOptions = [
        {
            name: "High to Low",
            value: "high"
        },
        {
            name: "Low to High",
            value: "low"
        }
    ];
    const getContent = (label, showArrow)=>{
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
            direction: "row",
            alignItems: "center",
            justifyContent: "center",
            spacing: 2,
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {
                    src: _assets_sort_png__WEBPACK_IMPORTED_MODULE_3__/* ["default"].src */ .Z.src,
                    height: "12px",
                    width: "12px",
                    objectFit: "contain"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                    fontSize: "13px",
                    sx: {
                        color: (theme)=>theme.palette.neutral[600]
                    },
                    children: t(`Sort by: ${label}`)
                }),
                showArrow === "true" && (open ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_6___default()), {
                    sx: {
                        color: (theme)=>theme.palette.text.secondary
                    }
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_5___default()), {
                    sx: {
                        color: (theme)=>theme.palette.text.secondary
                    }
                }))
            ]
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
                border: "true",
                onClick: handleClick,
                children: getContent(sortOptions.find((option)=>option.value === sortBy)?.name || "Default", "true")
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Popover, {
                id: id,
                open: open,
                anchorEl: anchorEl,
                onClose: handleClose,
                anchorOrigin: {
                    vertical: "bottom",
                    horizontal: "left"
                },
                PaperProps: {
                    style: {
                        width: anchorEl?.clientWidth || "auto"
                    }
                },
                children: sortOptions.map((option)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
                        onClick: ()=>handleSelect(option.value),
                        children: getContent(option.name, "false")
                    }, option.value))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (HighToLow);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
"use strict";
exports.id = 3423;
exports.ids = [3423];
exports.modules = {

/***/ 59599:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
// utils/useScrollToTop.js


const useScrollToTop = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        const handleRouteChange = ()=>{
            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });
        };
        router.events.on("routeChangeComplete", handleRouteChange);
        // Cleanup the event listener on unmount
        return ()=>{
            router.events.off("routeChangeComplete", handleRouteChange);
        };
    }, [
        router
    ]);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScrollToTop);


/***/ }),

/***/ 7188:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ ReadMore)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(53139);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22021);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react__WEBPACK_IMPORTED_MODULE_3__, i18next__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_react__WEBPACK_IMPORTED_MODULE_3__, i18next__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const ReadMore = ({ children , limits , color , font  })=>{
    const fontLimits = limits ? limits : 70;
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const text = children;
    const [isReadMore, setIsReadMore] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(true);
    const toggleReadMore = ()=>{
        setIsReadMore(!isReadMore);
    };
    const fontColor = theme.palette.primary.main;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        fontSize: {
            xs: "10px",
            sm: font ?? "14px",
            md: font ?? "14px"
        },
        fontWeight: "400",
        color: color ? color : theme.palette.neutral[600],
        children: [
            isReadMore ? text?.slice(0, fontLimits) : text,
            text?.length > fontLimits && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                onClick: toggleReadMore,
                style: {
                    cursor: "pointer",
                    color: fontColor
                },
                children: isReadMore ? (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)("...Read more") : (0,i18next__WEBPACK_IMPORTED_MODULE_4__.t)(" Show less")
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
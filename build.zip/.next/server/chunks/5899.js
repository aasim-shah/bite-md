"use strict";
exports.id = 5899;
exports.ids = [5899];
exports.modules = {

/***/ 21244:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useStoreFcm)
/* harmony export */ });
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_1__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const postHandler = async (token)=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].post */ .Z.post(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .cm_firebase_token_api */ .Hm}`, {
        cm_firebase_token: token,
        _method: "put"
    });
    return data;
};
const useStoreFcm = ()=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useMutation)("fcm_token", postHandler, {
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10550:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ useWishListGet)
/* harmony export */ });
/* unused harmony export WishList */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(60274);
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_1__]);
_MainApi__WEBPACK_IMPORTED_MODULE_1__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const WishList = async ()=>{
    const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_2__/* .get_wish_list_api */ .RY}`);
    return data;
};
const useWishListGet = (onSuccessHandler)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)("wishlist", ()=>WishList(), {
        enabled: false,
        retry: false,
        onSuccess: onSuccessHandler
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 72722:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const CongratulationsIcon = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "44",
        height: "44",
        viewBox: "0 0 44 44",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                "clip-path": "url(#clip0_3039_10043)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M6.94799 38.6257L28.2012 29.8842C28.7847 29.6444 28.9841 28.9337 28.6309 28.3424C27.6426 26.6753 25.562 23.4294 22.9229 20.7903C20.3714 18.2388 17.2674 16.2837 15.6517 15.3487C15.0622 15.0049 14.3627 15.2112 14.1229 15.7887L5.37877 37.0565C4.99893 37.9795 6.02502 39.0047 6.94799 38.6257Z",
                        fill: "#ED3F03"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M15.7858 34.991L10.822 37.0312L6.9729 33.182L9.01306 28.2183L15.7858 34.991Z",
                        fill: "#FCB424"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M24.7794 31.2907L19.8165 33.3326L10.6719 24.188L12.7138 19.2251L24.7794 31.2907Z",
                        fill: "#FCB424"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M7.6656 37.0522L7.25825 38.5708C7.23162 38.6701 7.23166 38.7746 7.25837 38.8739C7.28508 38.9732 7.33751 39.0637 7.41036 39.1362L8.52153 40.2474C8.5941 40.3198 8.64639 40.41 8.67319 40.509C8.69999 40.608 8.70037 40.7122 8.67427 40.8114C8.64818 40.9105 8.59654 41.0011 8.5245 41.074C8.45245 41.147 8.36254 41.1998 8.26372 41.2271L6.74521 41.6336C6.6459 41.6602 6.55534 41.7125 6.48264 41.7852C6.40993 41.8579 6.35763 41.9485 6.33099 42.0478L5.92021 43.5706C5.89287 43.6694 5.8401 43.7593 5.76715 43.8314C5.6942 43.9034 5.60363 43.9551 5.50448 43.9812C5.40533 44.0072 5.30107 44.0069 5.20211 43.9801C5.10315 43.9533 5.01295 43.901 4.94052 43.8284L3.82849 42.7172C3.75614 42.6449 3.6661 42.5928 3.56733 42.5661C3.46857 42.5394 3.36453 42.5391 3.2656 42.5651L1.74536 42.969C1.6466 42.9946 1.54289 42.9939 1.44448 42.9671C1.34606 42.9402 1.25636 42.8882 1.18423 42.816C1.1121 42.7439 1.06004 42.6542 1.03321 42.5558C1.00637 42.4574 1.00569 42.3537 1.03122 42.2549L1.43513 40.7347C1.46167 40.6354 1.46158 40.5308 1.43488 40.4315C1.40818 40.3323 1.3558 40.2418 1.28302 40.1692L0.171847 39.0597C0.0993147 38.987 0.0471681 38.8965 0.0206313 38.7973C-0.00590544 38.6981 -0.00590046 38.5936 0.0206457 38.4944C0.047192 38.3952 0.0993472 38.3047 0.171886 38.2319C0.244425 38.1592 0.3348 38.1068 0.433956 38.0801L1.95247 37.6736C2.05178 37.6469 2.14234 37.5946 2.21504 37.5219C2.28775 37.4492 2.34005 37.3587 2.36669 37.2594L2.77317 35.7408C2.79996 35.6417 2.85234 35.5513 2.92506 35.4788C2.99778 35.4062 3.08828 35.3541 3.1875 35.3275C3.28672 35.301 3.39118 35.301 3.4904 35.3275C3.58963 35.3541 3.68014 35.4062 3.75286 35.4787L4.86403 36.5899C4.93658 36.6628 5.02706 36.7152 5.12634 36.7419C5.22563 36.7686 5.3302 36.7686 5.4295 36.742L6.94802 36.3347C7.04735 36.3081 7.15193 36.3082 7.25124 36.3348C7.35055 36.3614 7.44111 36.4137 7.51382 36.4864C7.58653 36.5592 7.63883 36.6497 7.66547 36.749C7.69211 36.8483 7.69215 36.9529 7.6656 37.0522Z",
                        fill: "#07B7EE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M23.7522 20.0932C23.7079 20.0477 23.6819 19.9875 23.6792 19.9241C23.6765 19.8607 23.6973 19.7985 23.7376 19.7494L31.9876 9.75488L34.0931 11.8595L24.0986 20.1095C24.0491 20.1503 23.9863 20.1713 23.9222 20.1682C23.8582 20.1652 23.7976 20.1385 23.7522 20.0932Z",
                        fill: "#07B7EE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M25.3353 21.4593C26.5565 20.3903 32.1931 15.772 37.6244 16.4973L37.6759 19.8248C37.6759 19.8248 33.2673 17.7623 25.6868 21.956C25.629 21.9881 25.5623 22.0005 25.4968 21.9912C25.4313 21.9819 25.3707 21.9514 25.3241 21.9045C25.2944 21.8752 25.271 21.8401 25.2554 21.8014C25.2397 21.7627 25.2322 21.7212 25.2333 21.6795C25.2343 21.6378 25.2439 21.5967 25.2615 21.5588C25.279 21.5209 25.3041 21.4871 25.3353 21.4593Z",
                        fill: "#ED3F03"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M22.3859 18.5101C23.455 17.2889 28.0733 11.6522 27.348 6.221L24.0205 6.16943C24.0205 6.16943 26.083 10.578 21.8892 18.1586C21.8571 18.2164 21.8448 18.2831 21.8541 18.3486C21.8634 18.414 21.8938 18.4747 21.9408 18.5212C21.9701 18.551 22.0052 18.5744 22.0439 18.59C22.0826 18.6056 22.1241 18.6132 22.1658 18.6121C22.2075 18.6111 22.2486 18.6015 22.2865 18.5839C22.3243 18.5664 22.3582 18.5412 22.3859 18.5101Z",
                        fill: "#FCB424"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M37.4182 6.47464C36.6448 7.72331 36.6534 8.95136 37.4182 10.2043C37.4222 10.2106 37.4239 10.2181 37.423 10.2255C37.4221 10.2329 37.4187 10.2398 37.4134 10.245C37.4081 10.2502 37.4012 10.2535 37.3937 10.2542C37.3863 10.2549 37.3789 10.2531 37.3727 10.249C36.1197 9.46355 34.8865 9.47558 33.6344 10.249C33.6281 10.2527 33.6209 10.2542 33.6137 10.2532C33.6065 10.2523 33.5999 10.249 33.5948 10.2439C33.5897 10.2388 33.5864 10.2322 33.5855 10.225C33.5846 10.2178 33.586 10.2106 33.5897 10.2043C34.376 8.95136 34.3674 7.72331 33.5966 6.46519C33.5929 6.45895 33.5914 6.45168 33.5923 6.44452C33.5933 6.43735 33.5965 6.43069 33.6016 6.42558C33.6068 6.42047 33.6134 6.4172 33.6206 6.41628C33.6277 6.41536 33.635 6.41685 33.6413 6.4205C34.8882 7.20081 36.1154 7.19909 37.3701 6.42995C37.376 6.42357 37.3842 6.4198 37.3929 6.41948C37.4016 6.41916 37.4101 6.42231 37.4165 6.42823C37.4229 6.43416 37.4266 6.44238 37.427 6.45108C37.4273 6.45978 37.4241 6.46826 37.4182 6.47464Z",
                        fill: "#07B7EE"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M43.9707 19.0877C42.5098 19.2355 41.5404 19.9892 41.0136 21.3607C41.0109 21.3675 41.006 21.3731 40.9997 21.3768C40.9934 21.3804 40.9861 21.3819 40.9789 21.3809C40.9717 21.3799 40.965 21.3765 40.9599 21.3713C40.9549 21.3661 40.9517 21.3594 40.9509 21.3521C40.8116 19.88 40.0468 18.9107 38.6718 18.3907C38.6651 18.388 38.6594 18.3831 38.6558 18.3768C38.6521 18.3706 38.6507 18.3632 38.6517 18.356C38.6527 18.3488 38.656 18.3422 38.6612 18.3371C38.6664 18.332 38.6732 18.3288 38.6804 18.328C40.1534 18.1896 41.1227 17.4343 41.6512 16.0575C41.654 16.0508 41.6589 16.0452 41.6651 16.0415C41.6714 16.0379 41.6788 16.0364 41.686 16.0374C41.6932 16.0384 41.6998 16.0418 41.7049 16.047C41.71 16.0522 41.7132 16.0589 41.714 16.0661C41.8541 17.5271 42.6026 18.5025 43.9767 19.0293C43.9819 19.0325 43.9861 19.0371 43.9888 19.0426C43.9915 19.0481 43.9926 19.0543 43.992 19.0604C43.9914 19.0665 43.989 19.0723 43.9853 19.0771C43.9815 19.0819 43.9765 19.0856 43.9707 19.0877Z",
                        fill: "#ED3F03"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M24.9124 0.0290841C24.7646 1.49002 24.0109 2.4594 22.6393 2.98619C22.6326 2.98891 22.6269 2.99381 22.6233 3.00009C22.6197 3.00638 22.6182 3.01371 22.6192 3.02091C22.6202 3.02811 22.6235 3.03477 22.6287 3.03985C22.6339 3.04492 22.6407 3.04812 22.6479 3.04893C24.12 3.18815 25.0937 3.95299 25.6136 5.32799C25.6163 5.33473 25.6212 5.34037 25.6275 5.34401C25.6338 5.34766 25.6411 5.3491 25.6483 5.34812C25.6555 5.34713 25.6622 5.34377 25.6673 5.33857C25.6724 5.33337 25.6755 5.32662 25.6764 5.3194C25.8147 3.84643 26.5701 2.87705 27.9468 2.34854C27.9536 2.34582 27.9592 2.34092 27.9629 2.33464C27.9665 2.32835 27.9679 2.32103 27.967 2.31382C27.966 2.30662 27.9626 2.29996 27.9574 2.29488C27.9522 2.28981 27.9455 2.28661 27.9382 2.2858C26.4773 2.14572 25.5019 1.39721 24.9751 0.0230685C24.9726 0.0163636 24.9679 0.0106782 24.9618 0.00688923C24.9557 0.00310025 24.9486 0.00141812 24.9414 0.00210227C24.9343 0.00278642 24.9276 0.00579885 24.9223 0.010675C24.9171 0.0155511 24.9136 0.02202 24.9124 0.0290841Z",
                        fill: "#FCB424"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M35.5851 25.6205L35.3866 26.3595C35.3764 26.3985 35.3765 26.4394 35.3869 26.4783C35.3973 26.5171 35.4176 26.5526 35.4459 26.5813L35.9873 27.1218C36.0156 27.1503 36.0359 27.1858 36.0463 27.2246C36.0566 27.2635 36.0565 27.3043 36.0461 27.3431C36.0356 27.382 36.0152 27.4173 35.9868 27.4458C35.9583 27.4742 35.923 27.4946 35.8841 27.5051L35.1451 27.7027C35.1063 27.7134 35.071 27.734 35.0427 27.7624C35.0143 27.7909 34.9939 27.8264 34.9835 27.8652L34.7859 28.6034C34.7755 28.6424 34.755 28.6779 34.7266 28.7065C34.6981 28.735 34.6626 28.7556 34.6236 28.766C34.5847 28.7765 34.5436 28.7765 34.5047 28.766C34.4657 28.7556 34.4302 28.735 34.4017 28.7065L33.8595 28.166C33.8312 28.1373 33.7959 28.1167 33.7571 28.1063C33.7183 28.0959 33.6774 28.096 33.6386 28.1067L32.8995 28.3043C32.8606 28.3147 32.8197 28.3147 32.7808 28.3043C32.7419 28.2939 32.7064 28.2734 32.6779 28.2449C32.6494 28.2164 32.6289 28.181 32.6185 28.1421C32.6081 28.1032 32.6081 28.0622 32.6185 28.0233L32.817 27.2851C32.8272 27.2462 32.8271 27.2053 32.8167 27.1664C32.8063 27.1275 32.786 27.092 32.7577 27.0634L32.2163 26.5228C32.188 26.4943 32.1677 26.4589 32.1573 26.42C32.147 26.3812 32.1471 26.3403 32.1575 26.3015C32.168 26.2627 32.1884 26.2273 32.2168 26.1989C32.2453 26.1705 32.2806 26.15 32.3195 26.1395L33.0585 25.9419C33.0973 25.9313 33.1326 25.9107 33.1609 25.8822C33.1893 25.8537 33.2097 25.8183 33.2201 25.7795L33.4177 25.0404C33.4282 25.0015 33.4488 24.966 33.4773 24.9376C33.5058 24.9091 33.5413 24.8887 33.5803 24.8783C33.6192 24.868 33.6602 24.868 33.6991 24.8785C33.738 24.889 33.7734 24.9096 33.8019 24.9381L34.3424 25.4787C34.3706 25.5073 34.406 25.5279 34.4448 25.5383C34.4836 25.5488 34.5245 25.5486 34.5633 25.538L35.3024 25.3403C35.3413 25.3296 35.3823 25.3293 35.4214 25.3395C35.4605 25.3498 35.4962 25.3701 35.5248 25.3985C35.5535 25.427 35.5742 25.4624 35.5848 25.5014C35.5954 25.5404 35.5955 25.5815 35.5851 25.6205Z",
                        fill: "#FCB424"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M19.3702 9.40613L19.1717 10.1452C19.1615 10.1841 19.1616 10.225 19.172 10.2639C19.1824 10.3028 19.2028 10.3383 19.231 10.3669L19.7724 10.9075C19.8007 10.936 19.8211 10.9714 19.8314 11.0103C19.8417 11.0491 19.8417 11.09 19.8312 11.1288C19.8208 11.1676 19.8003 11.203 19.7719 11.2314C19.7435 11.2598 19.7081 11.2803 19.6693 11.2907L18.9302 11.4884C18.8915 11.499 18.8562 11.5196 18.8278 11.5481C18.7995 11.5766 18.7791 11.612 18.7687 11.6508L18.571 12.389C18.5606 12.428 18.5402 12.4636 18.5117 12.4921C18.4832 12.5207 18.4477 12.5412 18.4088 12.5517C18.3698 12.5621 18.3288 12.5621 18.2898 12.5517C18.2509 12.5412 18.2154 12.5207 18.1869 12.4921L17.6463 11.9516C17.6181 11.923 17.5828 11.9024 17.5439 11.892C17.5051 11.8815 17.4642 11.8817 17.4255 11.8923L16.6864 12.09C16.6475 12.1004 16.6065 12.1004 16.5676 12.09C16.5287 12.0795 16.4933 12.059 16.4648 12.0306C16.4363 12.0021 16.4158 11.9666 16.4054 11.9277C16.395 11.8888 16.395 11.8478 16.4054 11.8089L16.6039 11.0707C16.6141 11.0318 16.614 10.9909 16.6036 10.952C16.5932 10.9132 16.5729 10.8777 16.5446 10.849L16.0032 10.3085C15.9749 10.28 15.9545 10.2445 15.9442 10.2057C15.9339 10.1668 15.934 10.1259 15.9444 10.0871C15.9548 10.0483 15.9753 10.0129 16.0037 9.98452C16.0321 9.9561 16.0675 9.93564 16.1063 9.92519L16.8454 9.72754C16.8841 9.71691 16.9195 9.69633 16.9478 9.66784C16.9761 9.63934 16.9965 9.60393 17.0069 9.56511L17.2046 8.82605C17.2151 8.78714 17.2356 8.75168 17.2641 8.72323C17.2927 8.69478 17.3282 8.67434 17.3671 8.66397C17.4061 8.65361 17.4471 8.65368 17.486 8.66418C17.5249 8.67468 17.5603 8.69524 17.5887 8.72379L18.1327 9.26433C18.1609 9.29296 18.1963 9.31355 18.2351 9.32397C18.2739 9.3344 18.3148 9.33428 18.3536 9.32363L19.0927 9.12597C19.1312 9.11636 19.1717 9.11695 19.21 9.12767C19.2483 9.13839 19.2831 9.15888 19.3111 9.18713C19.3391 9.21538 19.3593 9.25042 19.3696 9.28881C19.38 9.3272 19.3802 9.36763 19.3702 9.40613Z",
                        fill: "#ED3F03"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                    id: "clip0_3039_10043",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        width: "44",
                        height: "44",
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CongratulationsIcon);


/***/ }),

/***/ 74724:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var firebase_messaging__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(33512);
/* harmony import */ var _firebase__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(29901);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(86201);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var api_manage_hooks_react_query_push_notifications_usePushNotification__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(21244);
/* harmony import */ var _assets_img_CongratulationsIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72722);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(22021);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([firebase_messaging__WEBPACK_IMPORTED_MODULE_2__, _firebase__WEBPACK_IMPORTED_MODULE_3__, react_hot_toast__WEBPACK_IMPORTED_MODULE_4__, api_manage_hooks_react_query_push_notifications_usePushNotification__WEBPACK_IMPORTED_MODULE_7__, i18next__WEBPACK_IMPORTED_MODULE_10__]);
([firebase_messaging__WEBPACK_IMPORTED_MODULE_2__, _firebase__WEBPACK_IMPORTED_MODULE_3__, react_hot_toast__WEBPACK_IMPORTED_MODULE_4__, api_manage_hooks_react_query_push_notifications_usePushNotification__WEBPACK_IMPORTED_MODULE_7__, i18next__WEBPACK_IMPORTED_MODULE_10__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const CustomPaperRefer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Paper)(({ theme  })=>({
        display: "flex",
        alignItems: "center",
        padding: "17px 28px 22px 28px",
        borderRadius: "12px",
        gap: "18px",
        maxWidth: "375px",
        [theme.breakpoints.down("md")]: {
            width: "350px"
        },
        [theme.breakpoints.down("sm")]: {
            width: "301px"
        }
    }));
const PushNotificationLayout = ({ children , refetch , pathName , refetchTrackOrder  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_5__.useTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();
    const [notification, setNotification] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [userToken, setUserToken] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const [isTokenFound, setTokenFound] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [fcmToken, setFcmToken] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const darkToast = ()=>(0,react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast)("You have a new message", {
            icon: "",
            style: {
                borderRadius: "12px",
                background: theme.palette.primary.main,
                color: theme.palette.neutral[1000],
                height: "60px"
            },
            position: "top-center"
        });
    const CustomToast = ({ title , description , icon  })=>/*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CustomPaperRefer, {
            children: [
                icon && icon,
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                    gap: "7px",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                            fontSize: "14px",
                            fontWeight: 700,
                            sx: {
                                color: "primary.main"
                            },
                            children: (0,i18next__WEBPACK_IMPORTED_MODULE_10__.t)(title)
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                            fontSize: "12px",
                            sx: {
                                width: "100%",
                                maxWidth: "283px"
                            },
                            children: (0,i18next__WEBPACK_IMPORTED_MODULE_10__.t)(description)
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.IconButton, {
                    sx: {
                        position: "absolute",
                        top: 10,
                        right: 15
                    },
                    onClick: ()=>react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.dismiss(),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_9___default()), {
                        sx: {
                            fontSize: "16px"
                        }
                    })
                })
            ]
        });
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleFetchToken();
    }, []);
    const handleFetchToken = async ()=>{
        await (0,_firebase__WEBPACK_IMPORTED_MODULE_3__/* .fetchToken */ .EC)(setTokenFound, setFcmToken);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (true) {
            setUserToken(localStorage.getItem("token"));
        //userToken = window.localStorage.getItem('token')
        }
    }, [
        userToken
    ]);
    //const userToken=localStorage.getItem("token")
    const { mutate  } = (0,api_manage_hooks_react_query_push_notifications_usePushNotification__WEBPACK_IMPORTED_MODULE_7__/* .useStoreFcm */ .F)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (userToken) {
            mutate(fcmToken);
        }
    }, [
        fcmToken
    ]);
    const clickHandler = ()=>{
        if (notification.type === "message") {
            router.push({
                pathname: "/chatting",
                query: {
                    conversationId: notification?.conversation_id,
                    type: notification.sender_type,
                    chatFrom: "true"
                }
            }, undefined, {
                shallow: true
            });
        }
        if (notification.type === "order_status") {
            // router.push(`/order-history/${notification.order_id}`, undefined, {
            //   shallow: true,
            // });
            router.push(`/profile?orderId=${notification.order_id}&page=my-orders&from=checkout`, undefined, {
                shallow: true
            });
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        (0,_firebase__WEBPACK_IMPORTED_MODULE_3__/* .onMessageListener */ .Lu)().then((payload)=>{
            setNotification(payload.data);
        // toast.success(payload.data.title)
        }).catch((err)=>(0,react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast)(err));
        if (notification) {
            if (pathName === "chat" && notification.type === "message") {
                refetch();
            } else if (notification.type === "message") {
                darkToast();
            } else if (notification.type === "referral_code") {
                react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast.custom(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomToast, {
                    title: notification?.title,
                    description: notification?.body,
                    icon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_img_CongratulationsIcon__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {})
                }), {
                    position: "top-right",
                    duration: 5000
                });
            } else {
                if (pathName === "profile") {
                    refetchTrackOrder();
                }
                (0,react_hot_toast__WEBPACK_IMPORTED_MODULE_4__.toast)(/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Stack, {
                        sx: {
                            cursor: "pointer"
                        },
                        onClick: clickHandler,
                        color: theme.palette.primary.main,
                        width: "300px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                children: notification.title
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_5__.Typography, {
                                children: notification.body
                            })
                        ]
                    })
                }));
            }
        }
    }, [
        notification
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PushNotificationLayout); // title="Someone just used  your code !"
 //   description="Be prepare to receive when they complete there first purchase"
 //   icon={<CongratulationsIcon />}
 //   position="top-right"

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
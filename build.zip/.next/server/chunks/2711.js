"use strict";
exports.id = 2711;
exports.ids = [2711];
exports.modules = {

/***/ 82711:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "hE": () => (/* binding */ ChatUserTop),
/* harmony export */   "zr": () => (/* binding */ ChatSidebarDesktop)
/* harmony export */ });
/* unused harmony exports CustomBoxFullWidth, CustomInnerBoxFullWidth, ChatSidebarMobile, ChatContentWrapper, ContactListWrapper */
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const CustomBoxFullWidth = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme  })=>({
        position: "relative",
        height: `calc(100vh - 100px)`,
        width: "100%",
        overflow: "hidden"
    }));
const CustomInnerBoxFullWidth = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme  })=>({
        display: "flex",
        position: "absolute",
        top: 0,
        right: 0,
        bottom: 0,
        left: 0
    }));
const ChatSidebarDesktop = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Drawer)({
    flexShrink: 0,
    width: "349px",
    // minHeight: "70vh",
    height: "100%",
    "& .MuiDrawer-paper": {
        position: "relative",
        width: "349px",
        height: "100%",
        borderRight: "none !important"
    }
});
const ChatSidebarMobile = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Drawer)({
    maxWidth: "100%",
    width: "100%",
    minHeight: "70vh",
    "& .MuiDrawer-paper": {
        height: "calc(100% - 59px)",
        maxWidth: "100%",
        top: 55,
        width: "100%"
    }
});
const ChatContentWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme  })=>({
        alignItems: "flex-start",
        justifyContent: "flex-start",
        display: "flex",
        padding: "1rem"
    }));
const ContactListWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme  })=>({
    }));
const ChatUserTop = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack)(({ theme , mdup  })=>({
        alignItems: "center",
        justifyContent: "flex-start",
        paddingBottom: "5px",
        marginBottom: "10px",
        width: "100%",
        borderBottom: "1px solid",
        borderColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.alpha)(theme.palette.neutral[400], 0.3)
    }));


/***/ })

};
;
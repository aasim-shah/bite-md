"use strict";
exports.id = 7251;
exports.ids = [7251];
exports.modules = {

/***/ 37251:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(27372);
/* harmony import */ var _mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(80697);
/* harmony import */ var api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(93706);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(90603);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22021);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(86201);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(57987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var styled_components_TextWithEllipsis__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(53556);
/* harmony import */ var utils_toasterMessages__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(70557);
/* harmony import */ var redux_slices_wishList__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(64134);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(58861);
/* harmony import */ var _CustomRatingBox__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(18150);
/* harmony import */ var _typographies_Body2__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(15220);
/* harmony import */ var _Card_style__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(21937);
/* harmony import */ var _QuickView__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(82681);
/* harmony import */ var _mui_icons_material_GradeRounded__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(74209);
/* harmony import */ var _mui_icons_material_GradeRounded__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_GradeRounded__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(77943);
/* harmony import */ var _mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var components_closed_now__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(9076);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_4__, api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_5__, i18next__WEBPACK_IMPORTED_MODULE_6__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, react_i18next__WEBPACK_IMPORTED_MODULE_10__, _CustomRatingBox__WEBPACK_IMPORTED_MODULE_16__, _typographies_Body2__WEBPACK_IMPORTED_MODULE_17__, _QuickView__WEBPACK_IMPORTED_MODULE_19__, components_closed_now__WEBPACK_IMPORTED_MODULE_22__]);
([api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_4__, api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_5__, i18next__WEBPACK_IMPORTED_MODULE_6__, react_hot_toast__WEBPACK_IMPORTED_MODULE_9__, react_i18next__WEBPACK_IMPORTED_MODULE_10__, _CustomRatingBox__WEBPACK_IMPORTED_MODULE_16__, _typographies_Body2__WEBPACK_IMPORTED_MODULE_17__, _QuickView__WEBPACK_IMPORTED_MODULE_19__, components_closed_now__WEBPACK_IMPORTED_MODULE_22__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);

























const ContentSection = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box)(({ theme  })=>({
        background: "",
        marginTop: "10px"
    }));
const FavoriteWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box)(({ theme  })=>({
        color: theme.palette.primary.main,
        width: "24px",
        height: "24px",
        backgroundColor: theme.palette.neutral[100],
        borderRadius: "4px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
    }));
const Wrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_14__/* .CustomStackFullWidth */ .Xw)(({ theme  })=>({
        backgroundColor: theme.palette.background.custom6,
        padding: "10px",
        border: `1px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.alpha)(theme.palette.neutral[400], 0.2)}`,
        borderRadius: "10px",
        cursor: "pointer",
        transition: "all ease 0.5s",
        ".MuiTypography-subtitle2": {
            transition: "all ease 0.5s"
        },
        "&:hover": {
            transform: "scale(1.03)",
            img: {
                transform: "scale(1.05)"
            },
            ".MuiTypography-subtitle2": {
                color: theme.palette.primary.main
            }
        }
    }));
const ImageWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.styled)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_14__/* .CustomBoxFullWidth */ .uu)(({ theme  })=>({
        position: "relative",
        borderRadius: "10px",
        height: "130px",
        overflow: "hidden",
        [theme.breakpoints.down("sm")]: {
            height: "140px"
        }
    }));
const timeAndDeliveryTypeHandler = (item)=>{
    const time = item?.delivery_time !== null ? item?.delivery_time : "";
    const free_delivery = item?.free_delivery === true ? `. ${(0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Free Delivery")}` : "";
    return time + free_delivery;
};
const StoreCard = (props)=>{
    const classes = (0,styled_components_TextWithEllipsis__WEBPACK_IMPORTED_MODULE_12__/* .textWithEllipsis */ .C)();
    const { item , imageUrl , topoffer  } = props;
    const [isHover, setIsHover] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { wishLists  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_11__.useSelector)((state)=>state.wishList);
    const [isWishlisted, setIsWishlisted] = (0,react__WEBPACK_IMPORTED_MODULE_8__.useState)(false);
    const { mutate: addFavoriteMutation  } = (0,api_manage_hooks_react_query_wish_list_useAddStoreToWishLists__WEBPACK_IMPORTED_MODULE_4__/* .useAddStoreToWishlist */ .v)();
    const { mutate  } = (0,api_manage_hooks_react_query_wish_list_useWishListStoreDelete__WEBPACK_IMPORTED_MODULE_5__/* .useWishListStoreDelete */ .K)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_10__.useTranslation)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_11__.useDispatch)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
    (0,react__WEBPACK_IMPORTED_MODULE_8__.useEffect)(()=>{
        wishlistItemExistHandler();
    }, [
        wishLists
    ]);
    const wishlistItemExistHandler = ()=>{
        if (wishLists?.store?.find((wishItem)=>wishItem.id === item?.id)) {
            setIsWishlisted(true);
        } else {
            setIsWishlisted(false);
        }
    };
    const quickViewHandleClick = (e)=>{
    // e.stopPropagation();
    // dispatch({ type: ACTION.setOpenModal, payload: true });
    };
    const addToWishlistHandler = (e)=>{
        e.stopPropagation();
        let token = undefined;
        if (false) {}
        if (token) {
            addFavoriteMutation(item?.id, {
                onSuccess: (response)=>{
                    if (response) {
                        dispatch((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_13__/* .addWishListStore */ .KO)(item));
                        setIsWishlisted(true);
                        react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].success(response?.message);
                    }
                },
                onError: (error)=>{
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error(error.response.data.message);
                }
            });
        } else react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error(t(utils_toasterMessages__WEBPACK_IMPORTED_MODULE_23__/* .not_logged_in_message */ .XO));
    };
    const removeFromWishlistHandler = (e)=>{
        e.stopPropagation();
        const onSuccessHandlerForDelete = (res)=>{
            dispatch((0,redux_slices_wishList__WEBPACK_IMPORTED_MODULE_13__/* .removeWishListStore */ .$X)(item?.id));
            setIsWishlisted(false);
            react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].success(res.message, {
                id: "wishlist"
            });
        };
        mutate(item?.id, {
            onSuccess: onSuccessHandlerForDelete,
            onError: (error)=>{
                react_hot_toast__WEBPACK_IMPORTED_MODULE_9__["default"].error(error.response.data.message);
            }
        });
    };
    const handleClick = ()=>{
        router.push({
            pathname: `/store/[id]`,
            query: {
                id: `${item?.slug ? item?.slug : item?.id}`,
                module_id: `${item?.module_id}`,
                module_type: (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_24__/* .getCurrentModuleType */ .X)(),
                store_zone_id: `${item?.zone_id}`,
                distance: item?.distance
            }
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
        spacing: 2,
        onMouseEnter: ()=>setIsHover(true),
        onMouseLeave: ()=>setIsHover(false),
        onClick: ()=>handleClick(),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ImageWrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                        src: imageUrl,
                        // alt={t("Background")}
                        height: "100%",
                        width: "100%",
                        borderRadius: "10px",
                        objectFit: "cover"
                    }),
                    isWishlisted && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        sx: {
                            position: "absolute",
                            top: 10,
                            right: 10
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(FavoriteWrapper, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Favorite__WEBPACK_IMPORTED_MODULE_1___default()), {
                                fontSize: "small"
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_closed_now__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {
                        active: item?.active,
                        open: item?.open,
                        borderRadius: "10px"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Card_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomOverLay */ .j, {
                        hover: isHover,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuickView__WEBPACK_IMPORTED_MODULE_19__/* ["default"] */ .Z, {
                            quickViewHandleClick: quickViewHandleClick,
                            isTransformed: isHover,
                            isWishlisted: isWishlisted,
                            addToWishlistHandler: addToWishlistHandler,
                            removeFromWishlistHandler: removeFromWishlistHandler,
                            noQuickview: true
                        })
                    })
                ]
            }),
            topoffer ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ContentSection, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        sx: {
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: "8px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuickView__WEBPACK_IMPORTED_MODULE_19__/* .PrimaryToolTip */ .c, {
                                text: item?.name,
                                placement: "bottom",
                                arrow: "false",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    sx: {
                                        fontWeight: "600",
                                        color: (theme)=>theme.palette.text.custom,
                                        fontSize: {
                                            xs: "13px",
                                            sm: "16px"
                                        }
                                    },
                                    component: "h3",
                                    children: item?.name
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                sx: {
                                    fontSize: "13px",
                                    fontWeight: "400",
                                    display: "flex",
                                    justifyContent: "start",
                                    alignItems: "center",
                                    gap: "3px",
                                    color: (theme)=>theme.palette.primary.main
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_GradeRounded__WEBPACK_IMPORTED_MODULE_20___default()), {
                                        sx: {
                                            fontSize: "15px",
                                            color: (theme)=>theme.palette.primary.main
                                        }
                                    }),
                                    item?.avg_rating
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box, {
                        sx: {
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                sx: {
                                    display: "flex",
                                    alignItems: "center",
                                    gap: "5px"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                        color: "text.secondary",
                                        sx: {
                                            fontSize: "12px",
                                            fontWeight: "400"
                                        },
                                        children: item?.delivery_time
                                    }),
                                    item?.free_delivery && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_FiberManualRecord__WEBPACK_IMPORTED_MODULE_21___default()), {
                                                color: "text.secondary",
                                                sx: {
                                                    fontSize: "5px",
                                                    mt: 0.2,
                                                    color: "text.secondary"
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                                color: "text.secondary",
                                                sx: {
                                                    fontSize: "12px",
                                                    fontWeight: "400"
                                                },
                                                children: t("Free Delivery")
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box, {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    sx: {
                                        fontSize: "12px",
                                        fontWeight: "500",
                                        color: (theme)=>theme.palette.background.default,
                                        background: (theme)=>theme.palette.primary.main,
                                        px: "5px",
                                        py: "3px",
                                        borderRadius: "10px"
                                    },
                                    children: [
                                        item?.discount?.discount,
                                        item?.discount?.discount_type && "%",
                                        " ",
                                        t("off")
                                    ]
                                })
                            })
                        ]
                    })
                ]
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_14__/* .CustomBoxFullWidth */ .uu, {
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                    container: true,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            xs: 9.5,
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_QuickView__WEBPACK_IMPORTED_MODULE_19__/* .PrimaryToolTip */ .c, {
                                text: item?.name,
                                placement: "bottom",
                                arrow: "false",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Typography, {
                                    className: classes.singleLineEllipsis,
                                    fontSize: {
                                        xs: "12px",
                                        md: "14px"
                                    },
                                    fontWeight: "500",
                                    component: "h3",
                                    children: item?.name
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            xs: 2.5,
                            children: item?.avg_rating > 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomRatingBox__WEBPACK_IMPORTED_MODULE_16__/* ["default"] */ .Z, {
                                rating: item?.avg_rating
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            xs: 12,
                            sx: {
                                mt: "10px"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_Body2__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                text: item?.address
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Grid, {
                            item: true,
                            xs: 12,
                            sx: {
                                mt: "7px"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_typographies_Body2__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z, {
                                text: timeAndDeliveryTypeHandler(item)
                            })
                        })
                    ]
                })
            })
        ]
    });
};
StoreCard.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (StoreCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
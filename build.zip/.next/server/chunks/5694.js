"use strict";
exports.id = 5694;
exports.ids = [5694];
exports.modules = {

/***/ 50079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/promotional_banner.d767e086.png","height":363,"width":1440,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAACCAYAAABllJ3tAAAAR0lEQVR4nBXA3QpAMBiA4Xc/5jsyJ+7/qtwApZQUKdbsoz3mnMZPJZJjR0oPVWhabHlRYzHztqjcO64fOIoSnMfnTLhWigg/e7UZe4zfXkYAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":2});

/***/ }),

/***/ 70842:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony exports BannerWrapper, ContentWrapper, CustomTypography, CustomButton */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(58861);
/* harmony import */ var _assets_promotional_banner_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(50079);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const BannerWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Box)(({ theme  })=>({
        width: "100%",
        height: "360px",
        position: "relative",
        marginTop: "20px",
        "&:hover": {
            img: {
                transform: "scale(1.02)"
            }
        },
        [theme.breakpoints.down("sm")]: {
            height: "120px"
        }
    }));
const ContentWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomStackFullWidth */ .Xw)(({ theme  })=>({
        position: "absolute",
        top: 0
    }));
const CustomTypography = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography)(({ theme  })=>({
        fontFamily: "Quicksand",
        fontWeight: "700",
        fontSize: "16px",
        // lineHeight: "48px",
        [theme.breakpoints.up("sm")]: {
            fontSize: "2.5rem"
        }
    }));
const CustomButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button)(({ theme  })=>({
        backgroundColor: theme.palette.primary.customType2,
        marginTop: "10px"
    }));
const PromotionalBanner = ({ bannerData  })=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const data = {
        img: _assets_promotional_banner_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
        offerType: "Summer offer",
        header: "Up To 50% Off All Product.",
        subHeader: "We provide best quality & fresh grocery items"
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: bannerData?.bottom_section_banner && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(BannerWrapper, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                src: bannerData?.bottom_section_banner_full_url,
                height: "100%",
                width: "100%",
                objectFit: "cover"
            })
        })
    });
};
PromotionalBanner.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PromotionalBanner);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 74283:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ PrevFood),
/* harmony export */   "I": () => (/* binding */ NextFood)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(66959);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(52818);
/* harmony import */ var _mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(46573);
/* harmony import */ var _rtl__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(66673);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_rtl__WEBPACK_IMPORTED_MODULE_6__]);
_rtl__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];








const ButtonContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box)(({ theme , right , isdisabled , noBackground , isRtl , rightSpace  })=>({
        top: 0,
        height: "100%",
        width: "42px",
        transition: "background-image 0.3s ease-in-out, transform 0.3s ease-in-out",
        transform: "translateX(0)",
        background: noBackground === "true" ? null : right === "true" ? `linear-gradient(270deg, ${isRtl === "rtl" ? "rgba(255, 255, 255, 0)" : theme.palette.neutral[100]} 0%, ${isRtl === "rtl" ? theme.palette.neutral[100] : "rgba(75, 86, 107, 0.05) -28.57%, rgba(255, 255, 255, 0) 122.62%"} 100%)` : `linear-gradient(${isRtl === "rtl" ? "to left" : "to right"},  ${isRtl === "rtl" ? "rgba(255, 255, 255, 0)" : "rgba(75, 86, 107, 0.05) -28.57%, rgba(255, 255, 255, 0) 122.62%"} 0%, ${isRtl === "rtl" ? theme.palette.neutral[100] : "rgba(255, 255, 255, 0)"}  100%)`,
        zIndex: 1,
        right: right === "true" && "-8px",
        left: right !== "true" && 0,
        position: "absolute",
        alignItems: "center",
        justifyContent: "center",
        display: isdisabled ? "none" : "flex",
        borderTopRightRadius: "12px",
        borderBottomRightRadius: "12px",
        [theme.breakpoints.down("sm")]: {
            display: "none"
        }
    }));
const PrevWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box)(({ theme , isdisabled  })=>({
        zIndex: 1,
        top: "50%",
        left: 0,
        display: isdisabled ? "none" : "flex",
        alignItems: "center",
        justifyContent: "center",
        // backgroundColor: "rgba(255, 255, 255, 0.8)",
        backgroundColor: theme.palette.primary.main,
        boxShadow: "rgba(149, 157, 165, 0.2) 0px 8px 24px",
        height: "35px",
        width: "35px",
        borderRadius: "50%",
        "&:hover": {
            backgroundColor: theme.palette.primary.dark
        }
    }));
const NextWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Box)(({ theme , isdisabled  })=>({
        top: "50%",
        zIndex: 1,
        right: 8,
        display: isdisabled ? "none" : "flex",
        // backgroundColor: "rgba(255, 255, 255, 0.8)",
        backgroundColor: theme.palette.primary.main,
        borderRadius: "50%",
        boxShadow: "rgba(149, 157, 165, 0.2) 0px 8px 24px",
        alignItems: "center",
        justifyContent: "center",
        height: "35px",
        width: "35px",
        "&:hover": {
            backgroundColor: theme.palette.primary.deep
        }
    }));
const NextFood = ({ onClick , className , displayNoneOnMobile , noBackground , rightSpace  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)(theme.breakpoints.down("sm"));
    const displayNone = isSmall ? displayNoneOnMobile ? true : false : false;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonContainer, {
        isdisabled: displayNone || className?.includes("slick-disabled"),
        right: "true",
        noBackground: noBackground ? "true" : "false",
        isRtl: (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_7__/* .getLanguage */ .G)(),
        rightSpace: rightSpace,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(NextWrapper, {
            className: `client-nav client-next ${className}`,
            onClick: onClick,
            isdisabled: className?.includes("slick-disabled"),
            children: (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_7__/* .getLanguage */ .G)() === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_1___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600],
                    "&:hover": {
                        color: theme.palette.neutral[100]
                    }
                }
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600],
                    "&:hover": {
                        color: theme.palette.neutral[100]
                    }
                }
            })
        })
    });
};
const PrevFood = ({ onClick , className , displayNoneOnMobile , noBackground , lanDirection  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)(theme.breakpoints.down("sm"));
    const displayNone = isSmall ? displayNoneOnMobile ? true : false : false;
    const rtl = (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_7__/* .getLanguage */ .G)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ButtonContainer, {
        isdisabled: displayNone || className?.includes("slick-disabled"),
        noBackground: noBackground ? "true" : "false",
        isRtl: rtl,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(PrevWrapper, {
            className: `client-nav client-prev ${className}`,
            onClick: onClick,
            isdisabled: className?.includes("slick-disabled"),
            children: (0,_helper_functions_getLanguage__WEBPACK_IMPORTED_MODULE_7__/* .getLanguage */ .G)() === "rtl" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronRight__WEBPACK_IMPORTED_MODULE_2___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600],
                    "&:hover": {
                        color: theme.palette.neutral[100]
                    }
                }
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_1___default()), {
                sx: {
                    fontSize: "30px",
                    color: (theme)=>theme.palette.neutral[600],
                    "&:hover": {
                        color: theme.palette.neutral[100]
                    }
                }
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 66673:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* binding */ RTL)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _emotion_cache__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8440);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(53139);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(93195);
/* harmony import */ var stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_cache__WEBPACK_IMPORTED_MODULE_3__, _emotion_react__WEBPACK_IMPORTED_MODULE_4__]);
([_emotion_cache__WEBPACK_IMPORTED_MODULE_3__, _emotion_react__WEBPACK_IMPORTED_MODULE_4__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






const styleCache = ()=>(0,_emotion_cache__WEBPACK_IMPORTED_MODULE_3__["default"])({
        key: "rtl",
        prepend: true,
        stylisPlugins: [
            (stylis_plugin_rtl__WEBPACK_IMPORTED_MODULE_5___default())
        ]
    });
const RTL = (props)=>{
    const { children , direction  } = props;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.dir = direction;
    }, [
        direction
    ]);
    if (direction === "rtl") {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_emotion_react__WEBPACK_IMPORTED_MODULE_4__.CacheProvider, {
            value: styleCache(),
            children: children
        });
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: children
    });
};
RTL.propTypes = {
    children: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node.isRequired),
    direction: prop_types__WEBPACK_IMPORTED_MODULE_2___default().oneOf([
        "ltr",
        "rtl"
    ])
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
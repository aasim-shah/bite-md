"use strict";
exports.id = 4369;
exports.ids = [4369];
exports.modules = {

/***/ 55851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/delivery-man.c145d2d3.svg","height":175,"width":175});

/***/ }),

/***/ 51229:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/seller.2044003e.svg","height":175,"width":175});

/***/ }),

/***/ 44369:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "getServerSideProps": () => (/* binding */ getServerSideProps)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var components_layout_LandingLayout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(20580);
/* harmony import */ var _src_components_landing_page__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42994);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(94960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var redux_slices_configData__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(53236);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _src_components_seo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(95376);
/* harmony import */ var _src_api_manage_hooks_react_query_useGetLandingPage__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(24810);
/* harmony import */ var utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(81261);
/* harmony import */ var _src_api_manage_hooks_useGetConfigData__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(97372);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_layout_LandingLayout__WEBPACK_IMPORTED_MODULE_1__, _src_components_landing_page__WEBPACK_IMPORTED_MODULE_2__, _src_components_seo__WEBPACK_IMPORTED_MODULE_8__, _src_api_manage_hooks_react_query_useGetLandingPage__WEBPACK_IMPORTED_MODULE_9__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_10__, _src_api_manage_hooks_useGetConfigData__WEBPACK_IMPORTED_MODULE_11__]);
([components_layout_LandingLayout__WEBPACK_IMPORTED_MODULE_1__, _src_components_landing_page__WEBPACK_IMPORTED_MODULE_2__, _src_components_seo__WEBPACK_IMPORTED_MODULE_8__, _src_api_manage_hooks_react_query_useGetLandingPage__WEBPACK_IMPORTED_MODULE_9__, utils_CustomFunctions__WEBPACK_IMPORTED_MODULE_10__, _src_api_manage_hooks_useGetConfigData__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);












const Root = (props)=>{
    const { configData  } = props;
    const { data , refetch  } = (0,_src_api_manage_hooks_react_query_useGetLandingPage__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    const { data: dataConfig , refetch: configRefetch  } = (0,_src_api_manage_hooks_useGetConfigData__WEBPACK_IMPORTED_MODULE_11__/* .useGetConfigData */ .v)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        configRefetch();
        refetch();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        dispatch((0,redux_slices_configData__WEBPACK_IMPORTED_MODULE_6__/* .setLandingPageData */ .D1)(data));
        if (dataConfig) {
            if (dataConfig.length === 0) {
                next_router__WEBPACK_IMPORTED_MODULE_7___default().push("/404");
            } else if (dataConfig?.maintenance_mode) {
                next_router__WEBPACK_IMPORTED_MODULE_7___default().push("/maintainance");
            } else {
                dispatch((0,redux_slices_configData__WEBPACK_IMPORTED_MODULE_6__/* .setConfigData */ .Zr)(dataConfig));
            }
        } else {}
    }, [
        dataConfig,
        data
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3___default()), {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_seo__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                image: configData?.fav_icon_full_url,
                businessName: configData?.business_name,
                configData: configData
            }),
            data && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(components_layout_LandingLayout__WEBPACK_IMPORTED_MODULE_1__/* .LandingLayout */ .a, {
                configData: dataConfig,
                landingPageData: data,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_src_components_landing_page__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    configData: dataConfig,
                    landingPageData: data
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Root);
const getServerSideProps = async (context)=>{
    const { req , res  } = context;
    const language = req.cookies.languageSetting;
    const configRes = await fetch(`${"https://bite.md"}/api/v1/config`, {
        method: "GET",
        headers: {
            "X-software-id": 33571750,
            "X-server": "server",
            "X-localization": language,
            origin: process.env.NEXT_CLIENT_HOST_URL
        }
    });
    const config = await configRes.json();
    // Set cache control headers for 1 hour (3600 seconds)
    res.setHeader("Cache-Control", "public, s-maxage=3600, stale-while-revalidate");
    return {
        props: {
            configData: config
        }
    };
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 26873:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(28332);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_6__]);
react_i18next__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Wrapper = (0,_mui_system__WEBPACK_IMPORTED_MODULE_3__.styled)("div")(({ theme  })=>({
        position: "fixed",
        bottom: 0,
        left: 0,
        width: "100%",
        padding: theme.spacing(2),
        backgroundColor: theme.palette.background.default,
        boxShadow: theme.palette.mode === "dark" ? "0px -2px 4px rgb(223 223 223 / 10%)" : "0px -2px 4px rgba(0, 0, 0, 0.1)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        zIndex: 9999
    }));
const CookiesConsent = ({ text  })=>{
    const [showConsent, setShowConsent] = useState(true);
    const { t  } = useTranslation();
    const handleAccept = ()=>{
        localStorage.setItem("cookiesConsent", "true");
        setShowConsent(false);
    };
    const handleDeny = ()=>{
        localStorage.setItem("cookiesConsent", "false");
        setShowConsent(false);
    };
    let cookiesConsent;
    if (false) {}
    if (!showConsent || cookiesConsent === "true") {
        return null;
    }
    return /*#__PURE__*/ _jsx(Wrapper, {
        children: /*#__PURE__*/ _jsx(CustomContainer, {
            children: /*#__PURE__*/ _jsxs(CustomStackFullWidth, {
                direction: {
                    xs: "column",
                    sm: "row"
                },
                alignItems: "center",
                justifyContent: "space-between",
                spacing: 2,
                children: [
                    /*#__PURE__*/ _jsx(Typography, {
                        children: text
                    }),
                    /*#__PURE__*/ _jsxs(Stack, {
                        direction: "row",
                        alignItems: "center",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ _jsx(Button, {
                                variant: "outline",
                                color: "primary",
                                onClick: handleDeny,
                                children: t("Deny")
                            }),
                            /*#__PURE__*/ _jsx(Button, {
                                variant: "contained",
                                color: "primary",
                                onClick: handleAccept,
                                children: t("Accept")
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (CookiesConsent)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 12703:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var components_container__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(28332);
/* harmony import */ var components_CustomImageContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58861);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(22021);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_5__]);
i18next__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const ComponentTwoContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box)(({ theme , paddingTop , paddingBottom  })=>({
        marginTop: ".6rem",
        paddingTop: paddingTop ? paddingTop : "1.5rem",
        paddingBottom: paddingBottom ? paddingBottom : "1rem",
        background: theme.palette.background.default
    }));
const AvailableZoneSection = ({ landingPageData  })=>{
    const theme = useTheme();
    const isSmall = useMediaQuery(theme.breakpoints.down("sm"));
    const toolTipsContent = (zone)=>{
        return /*#__PURE__*/ _jsx(_Fragment, {
            children: /*#__PURE__*/ _jsxs(Stack, {
                children: [
                    /*#__PURE__*/ _jsx(Typography, {
                        paddingX: "7px",
                        children: zone?.display_name
                    }),
                    /*#__PURE__*/ _jsxs(Stack, {
                        direction: "row",
                        p: "7px",
                        flexWrap: "wrap",
                        gap: "4px",
                        children: [
                            zone?.modules?.length > 0 ? /*#__PURE__*/ _jsxs(Typography, {
                                fontSize: "12px",
                                children: [
                                    t("Modules are"),
                                    " "
                                ]
                            }) : /*#__PURE__*/ _jsx(Typography, {
                                fontSize: "12px",
                                children: t("No module available")
                            }),
                            zone?.modules?.map((item, index)=>/*#__PURE__*/ _jsxs(Typography, {
                                    fontSize: "12px",
                                    children: [
                                        item,
                                        index !== zone.modules.length - 1 ? "," : "."
                                    ]
                                }, index))
                        ]
                    })
                ]
            })
        });
    };
    return /*#__PURE__*/ _jsx(ComponentTwoContainer, {
        background: true,
        paddingTop: isSmall ? "2rem" : "3rem",
        paddingBottom: "2rem",
        children: /*#__PURE__*/ _jsx(CustomContainer, {
            children: /*#__PURE__*/ _jsxs(Grid, {
                container: true,
                alignItems: "center",
                justifyContent: "center",
                spacing: {
                    xs: 2,
                    md: 4
                },
                children: [
                    /*#__PURE__*/ _jsxs(Grid, {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 6,
                        align: isSmall ? "center" : "left",
                        children: [
                            /*#__PURE__*/ _jsx(Typography, {
                                fontSize: {
                                    xs: "1.2rem",
                                    md: "30px"
                                },
                                fontWeight: {
                                    xs: "600",
                                    md: "700"
                                },
                                component: "h2",
                                children: landingPageData?.available_zone_title
                            }),
                            /*#__PURE__*/ _jsx(Typography, {
                                fontSize: {
                                    xs: "14px",
                                    md: "16px"
                                },
                                fontWeight: {
                                    xs: "400",
                                    md: "500"
                                },
                                color: theme.palette.neutral[400],
                                paddingTop: isSmall ? "10px" : "0rem",
                                children: landingPageData?.available_zone_short_description
                            }),
                            /*#__PURE__*/ _jsxs(Box, {
                                sx: {
                                    position: "relative",
                                    marginTop: "35px"
                                },
                                children: [
                                    /*#__PURE__*/ _jsx(Box, {
                                        sx: {
                                            height: 200,
                                            overflowY: "auto",
                                            paddingRight: "10px",
                                            "&::-webkit-scrollbar": {
                                                width: "3px"
                                            },
                                            "&::-webkit-scrollbar-track": {
                                                backgroundColor: "#f0f0f0"
                                            },
                                            "&::-webkit-scrollbar-thumb": {
                                                backgroundColor: "#c1c1c1",
                                                borderRadius: "3px"
                                            },
                                            "&::-webkit-scrollbar-thumb:hover": {
                                                backgroundColor: "#003638"
                                            }
                                        },
                                        children: /*#__PURE__*/ _jsx(Box, {
                                            sx: {
                                                display: "flex",
                                                flexWrap: "wrap",
                                                gap: "12px",
                                                maxWidth: "543px",
                                                paddingBottom: "35px"
                                            },
                                            children: landingPageData?.available_zone_list?.filter((item)=>item?.modules?.length > 0).map((zone, index)=>/*#__PURE__*/ _jsx(Tooltip, {
                                                    arrow: true,
                                                    placement: "top",
                                                    title: toolTipsContent(zone),
                                                    children: /*#__PURE__*/ _jsx(Box, {
                                                        sx: {
                                                            borderRadius: "10px",
                                                            border: "1px solid",
                                                            borderColor: alpha(theme.palette.neutral[400], 0.5),
                                                            backgroundColor: (theme)=>theme.palette.neutral[100],
                                                            padding: "15px 30px",
                                                            cursor: "pointer",
                                                            fontSize: "20px",
                                                            fontWeight: 700,
                                                            textAlign: "center",
                                                            textDecoration: "none",
                                                            "&:hover": {
                                                                boxShadow: `0px 4px 12px 0px ${theme.palette.neutral[100]}`,
                                                                color: "#039d55"
                                                            }
                                                        },
                                                        "data-bs-toggle": "popover",
                                                        "data-bs-trigger": "hover",
                                                        "data-bs-placement": "top",
                                                        title: "Popover title",
                                                        "data-bs-content": "And here's some amazing content. It's very engaging. Right?",
                                                        children: zone?.display_name
                                                    })
                                                }, index))
                                        })
                                    }),
                                    /*#__PURE__*/ _jsx(Box, {
                                        sx: {
                                            position: "absolute",
                                            height: "62px",
                                            bottom: 0,
                                            left: 0,
                                            width: "100%",
                                            background: `linear-gradient(180deg, ${alpha(theme.palette.background.default, 0.0)} 43.03%,  ${alpha(theme.palette.background.default, 0.72)} 55.48%,  ${alpha(theme.palette.background.default, 0.9)} 100%)`,
                                            pointerEvents: "none"
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx(Grid, {
                        item: true,
                        xs: 12,
                        sm: 12,
                        md: 6,
                        align: isSmall ? "center" : "right",
                        children: /*#__PURE__*/ _jsx(Box, {
                            sx: {
                                position: "relative",
                                width: {
                                    xs: "223px",
                                    md: "440px"
                                },
                                height: {
                                    xs: "150px",
                                    md: "380px"
                                }
                            },
                            children: /*#__PURE__*/ _jsx(CustomImageContainer, {
                                src: landingPageData?.available_zone_image_full_url
                            })
                        })
                    })
                ]
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (AvailableZoneSection)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 53073:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(38096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(58861);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(28332);








const Banners = ({ landingPageData , isSmall  })=>{
    const infiniteManage = ()=>{
        if (isSmall) {
            if (landingPageData?.promotion_banners?.length === 1) {
                return false;
            } else {
                return true;
            }
        } else {
            if (landingPageData?.promotion_banners?.length > 3) {
                return true;
            } else {
                return false;
            }
        }
    };
    const slidesToShowManage = ()=>{
        if (isSmall) {
            return 1;
        } else {
            if (landingPageData?.promotion_banners?.length > 2) {
                return 3;
            } else if (landingPageData?.promotion_banners?.length === 2) {
                return 2;
            } else {
                return 1;
            }
        }
    };
    const twoItemManage = ()=>{
        return /*#__PURE__*/ _jsx(CustomStackFullWidth, {
            justifyContent: "center",
            flexDirection: "row",
            gap: "20px",
            children: landingPageData?.promotion_banners_full_url?.map((item, index)=>{
                return /*#__PURE__*/ _jsx(Box, {
                    sx: {
                        border: (theme)=>`0.828571px solid ${alpha(theme.palette.primary.main, 0.15)}`,
                        position: "relative",
                        height: "175px",
                        width: {
                            sm: "100%",
                            md: "395px"
                        },
                        borderRadius: "5px",
                        overflow: "hidden",
                        "&:hover": {
                            img: {
                                transform: "scale(1.1)",
                                transition: "transform .8s ease-in-out"
                            }
                        }
                    },
                    children: /*#__PURE__*/ _jsx(CustomImageContainer, {
                        src: item,
                        alt: "banners",
                        height: "100%",
                        width: "100%",
                        objectfit: "cover",
                        borderRadius: "5px"
                    })
                }, index);
            })
        });
    };
    const sliderManage = ()=>{
        return /*#__PURE__*/ _jsx(SliderCustom, {
            sx: {
                "& .slick-slider": {
                    "& .slick-slide": {
                        padding: {
                            xs: "5px",
                            md: "11px"
                        }
                    }
                }
            },
            children: /*#__PURE__*/ _jsx(Slider, {
                ...settings,
                children: landingPageData?.promotion_banners_full_url?.map((item, index)=>{
                    return /*#__PURE__*/ _jsx(Box, {
                        sx: {
                            border: (theme)=>`0.828571px solid ${alpha(theme.palette.primary.main, 0.15)}`,
                            position: "relative",
                            height: "175px",
                            width: "100%",
                            borderRadius: "5px",
                            overflow: "hidden",
                            "&:hover": {
                                img: {
                                    transform: "scale(1.1)",
                                    transition: "transform 0.8s ease-in-out"
                                }
                            }
                        },
                        children: /*#__PURE__*/ _jsx(CustomImageContainer, {
                            src: item,
                            alt: "banners",
                            height: "100%",
                            width: "100%",
                            objectfit: "cover",
                            borderRadius: "5px"
                        })
                    }, index);
                })
            })
        });
    };
    const settings = {
        dots: false,
        infinite: infiniteManage(),
        slidesToShow: slidesToShowManage(),
        slidesToScroll: 1,
        autoplay: true,
        speed: 2000,
        autoplaySpeed: 3000,
        pauseOnHover: true,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    initialSlide: 1
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };
    const singleImageManage = ()=>{
        return /*#__PURE__*/ _jsx(Stack, {
            sx: {
                display: "flex",
                alignItems: "center"
            },
            children: /*#__PURE__*/ _jsx(Box, {
                sx: {
                    border: (theme)=>`0.828571px solid ${alpha(theme.palette.primary.main, 0.15)}`,
                    position: "relative",
                    height: "175px",
                    borderRadius: "5px"
                },
                children: /*#__PURE__*/ _jsx(CustomImageContainer, {
                    src: landingPageData?.promotion_banners_full_url[0],
                    alt: "banners",
                    height: "100%",
                    width: "100%",
                    objectfit: "cover",
                    borderRadius: "5px"
                })
            })
        });
    };
    const handleContent = ()=>{
        if (isSmall) {
            if (landingPageData?.promotion_banners?.length === 1) {
                return /*#__PURE__*/ _jsx(_Fragment, {
                    children: singleImageManage()
                });
            } else {
                return /*#__PURE__*/ _jsx(_Fragment, {
                    children: sliderManage()
                });
            }
        } else {
            if (landingPageData?.promotion_banners?.length === 1) {
                return /*#__PURE__*/ _jsx(_Fragment, {
                    children: singleImageManage()
                });
            } else if (landingPageData?.promotion_banners?.length === 2) {
                return /*#__PURE__*/ _jsx(_Fragment, {
                    children: twoItemManage()
                });
            } else {
                return /*#__PURE__*/ _jsx(_Fragment, {
                    children: sliderManage()
                });
            }
        }
    };
    return /*#__PURE__*/ _jsx(CustomContainer, {
        children: /*#__PURE__*/ _jsx(Stack, {
            sx: {
                marginY: isSmall ? "22px" : "40px"
            },
            children: handleContent()
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Banners)));


/***/ }),

/***/ 70412:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



const cardData = [
    {
        title: "We make grocery delivery more interesting.",
        descriptions: [
            "Find the best deals from restaurants near you.",
            "Natural products. Bring nature into your home.",
            "Stay home and receive your daily essentials from our store.",
            "Start your daily shopping with BITE."
        ],
        buttonText: "See Restaurants",
        imageSrc: "/landingpage/food.png"
    },
    {
        title: "BITE makes shopping easier!",
        descriptions: [
            "From local markets to big supermarkets – all in one place.",
            "Fresh produce, staple foods, and everything you need – delivered to you.",
            "Shop online, receive without stress!",
            "At home, at the office, or wherever you need – BITE comes to you"
        ],
        buttonText: "Shop Now",
        imageSrc: "/landingpage/food-1.png"
    },
    {
        title: "Pharmacy services for your health.",
        descriptions: [
            "Pharmacy is the science and technique of preparing and distributing medicines.",
            "Also offering additional clinical services such as vaccinations.",
            "Health screenings and advice for quitting smoking.",
            "Managing conditions like diabetes and asthma."
        ],
        buttonText: "Order Now",
        imageSrc: "/landingpage/food-2.png"
    }
];
const ComponentThree = ()=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    const isTablet = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.between("sm", "md"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            padding: "0px"
        },
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
                backgroundColor: "#FDEADB",
                borderRadius: "3rem",
                padding: {
                    xs: "2rem",
                    md: "4rem"
                },
                display: "flex",
                flexDirection: "column",
                color: theme.palette.blue,
                alignItems: "center",
                textAlign: "center",
                width: "100%",
                margin: "0px"
            },
            children: cardData.map((card, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                    sx: {
                        width: "100%",
                        maxWidth: "1000px",
                        marginTop: {
                            xs: "2rem",
                            sm: "3rem",
                            md: "4rem"
                        }
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        container: true,
                        spacing: 4,
                        alignItems: "center",
                        direction: isSmall ? "column-reverse" : index % 2 === 0 ? "row" : "row-reverse",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                xs: 12,
                                md: 6,
                                textAlign: isSmall ? "center" : "left",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: isSmall ? "h6" : "h5",
                                        fontWeight: 600,
                                        mb: 2,
                                        children: card.title
                                    }),
                                    card.descriptions.map((desc, idx)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                            variant: "body1",
                                            mb: 1,
                                            children: desc
                                        }, idx)),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        variant: "contained",
                                        color: "primary",
                                        sx: {
                                            borderRadius: "20px",
                                            padding: {
                                                xs: "0.6rem 1.5rem",
                                                sm: "0.8rem 2rem"
                                            },
                                            fontSize: {
                                                xs: "0.875rem",
                                                sm: "1rem"
                                            },
                                            mt: 2
                                        },
                                        children: card.buttonText
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                                item: true,
                                xs: 12,
                                md: 6,
                                display: "flex",
                                justifyContent: "center",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                    sx: {
                                        width: isSmall ? "100%" : isTablet ? "80%" : "100%",
                                        display: "flex",
                                        justifyContent: "center"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        src: card.imageSrc,
                                        alt: card.title,
                                        width: 400,
                                        height: 300,
                                        style: {
                                            borderRadius: "2rem",
                                            objectFit: "cover",
                                            maxWidth: "100%",
                                            height: "auto"
                                        }
                                    })
                                })
                            })
                        ]
                    })
                }, index))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ComponentThree);


/***/ }),

/***/ 21281:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* unused harmony export ComponentTwoContainer */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(28332);
/* harmony import */ var _DownloadApps__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(38236);
/* harmony import */ var _SolutionSvg__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(72778);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(45269);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_DownloadApps__WEBPACK_IMPORTED_MODULE_3__]);
_DownloadApps__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const ComponentTwoContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box)(({ theme , paddingTop , paddingBottom  })=>({
        marginTop: ".6rem",
        paddingTop: paddingTop || "1.5rem",
        paddingBottom: paddingBottom || "1rem",
        background: `linear-gradient(180deg, ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.primary.main, 0)} 0%, ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.primary.main, 0.15)} 100%)`
    }));
const ComponentTwo = ({ landingPageData  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomBoxFullWidth */ .uu, {
            sx: {
                position: "relative",
                justifyContent: "center",
                alignItems: "center",
                margin: "auto",
                width: "82%",
                height: "20rem",
                minHeight: "20rem",
                display: "flex"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                style: {
                    backgroundImage: "url(/landingpage/white-bg.png)",
                    backgroundSize: "cover",
                    position: "absolute",
                    width: "100%",
                    height: "30rem",
                    left: 0,
                    right: 0,
                    alignItems: "center",
                    top: "-17rem",
                    borderRadius: "20px",
                    display: "flex",
                    flexDirection: isSmall ? "column" : "row",
                    justifyContent: "center",
                    textAlign: "center"
                },
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        container: true,
                        sx: {
                            justifyContent: "center",
                            alignItems: "center",
                            width: isSmall ? "100%" : "60%",
                            padding: {
                                xs: "1rem",
                                sm: "2rem",
                                md: "3rem"
                            }
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                variant: "contained",
                                color: "primary",
                                sx: {
                                    backgroundColor: theme.palette.blue,
                                    color: theme.palette.primary.contrastText,
                                    borderRadius: "20px",
                                    padding: "1rem 2rem",
                                    fontSize: "1.2rem",
                                    fontWeight: 500,
                                    textTransform: "none",
                                    marginBottom: "1rem"
                                },
                                children: "Download the app"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                variant: "body1",
                                sx: {
                                    color: theme.palette.blue,
                                    fontWeight: 500,
                                    fontSize: "1.2rem",
                                    textAlign: "center",
                                    marginBottom: "1rem"
                                },
                                children: "Order anything and track in real-time with the app"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                style: {
                                    display: "flex",
                                    flexDirection: isSmall ? "column" : "row",
                                    gap: "1rem",
                                    alignItems: "center"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            width: "10rem",
                                            height: "3rem"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            src: "/landingpage/playstore.png",
                                            alt: "Playstore",
                                            width: 500,
                                            style: {
                                                width: "100%",
                                                height: "100%"
                                            },
                                            height: 500
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        style: {
                                            width: "10rem",
                                            height: "3rem"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                            src: "/landingpage/appstore.png",
                                            alt: "Appstore",
                                            width: 500,
                                            style: {
                                                width: "100%",
                                                height: "100%"
                                            },
                                            height: 500
                                        })
                                    })
                                ]
                            })
                        ]
                    }),
                    !isSmall && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: {
                            display: "flex",
                            flexDirection: "row",
                            gap: "1rem",
                            position: "relative",
                            width: "100%",
                            height: "100%",
                            justifyContent: "center",
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    position: "absolute",
                                    height: "23rem",
                                    top: "1rem",
                                    left: "1rem",
                                    zIndex: 10
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    src: "/landingpage/PHONE-1.png",
                                    alt: "Phone",
                                    width: 500,
                                    style: {
                                        width: "100%",
                                        height: "100%"
                                    },
                                    height: 500
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                style: {
                                    position: "absolute",
                                    height: "14rem",
                                    top: "30%",
                                    right: "2rem"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_6___default()), {
                                    src: "/landingpage/image-1.png",
                                    alt: "Image",
                                    width: 500,
                                    style: {
                                        width: "100%",
                                        height: "100%"
                                    },
                                    height: 500
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ComponentTwo);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 95440:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);



const reviewsData = [
    {
        name: "John Doe",
        review: "Amazing service! The process was smooth and hassle-free.",
        rating: 5,
        bgImage: "/landingpage/review-bg-1.jpg"
    },
    {
        name: "Emily Smith",
        review: "Very professional and reliable. Highly recommended!",
        rating: 4.5,
        bgImage: "/landingpage/review-bg-2.jpg"
    },
    {
        name: "Michael Johnson",
        review: "A fantastic experience from start to finish!",
        rating: 5,
        bgImage: "/landingpage/review-bg-3.jpg"
    }
];
// Styled Card with Background Image
const ReviewCard = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper)(({ bgImage  })=>({
        padding: "2rem",
        alignItems: "center",
        borderRadius: "2rem"
    }));
const CustomReviews = ()=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            textAlign: "center",
            backgroundImage: `url(/landingpage/orange.png)`,
            py: "8rem",
            px: "2rem"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                variant: "h4",
                color: "white",
                fontWeight: 700,
                mb: 10,
                children: "Reviews"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                container: true,
                spacing: 4,
                justifyContent: "center",
                children: reviewsData.map((review, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                        item: true,
                        xs: 12,
                        sm: 6,
                        md: 4,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ReviewCard, {
                            elevation: 3,
                            bgImage: review.bgImage,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                    variant: "h6",
                                    color: theme.palette.blue,
                                    fontWeight: 600,
                                    mb: 1,
                                    children: review.name
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                    variant: "body1",
                                    color: theme.palette.blue,
                                    mb: 2,
                                    children: review.review
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Rating, {
                                    value: review.rating,
                                    precision: 0.5,
                                    readOnly: true
                                })
                            ]
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomReviews);


/***/ }),

/***/ 98463:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58861);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(28332);





const DiscountBanner = ({ bannerImage , isSmall  })=>{
    return /*#__PURE__*/ _jsx(_Fragment, {
        children: isSmall ? /*#__PURE__*/ _jsx(CustomContainer, {
            children: /*#__PURE__*/ _jsx(Box, {
                sx: {
                    position: "relative",
                    width: "100%",
                    // height: "250px",
                    borderRadius: "5px",
                    marginBottom: "20px",
                    marginTop: "20px"
                },
                children: /*#__PURE__*/ _jsx(CustomImageContainer, {
                    src: bannerImage,
                    alt: "banner",
                    height: "100%",
                    width: "100%",
                    obejctfit: "contained",
                    borderRadius: "5px"
                })
            })
        }) : /*#__PURE__*/ _jsx(CustomContainer, {
            children: /*#__PURE__*/ _jsx(Box, {
                sx: {
                    width: "100%",
                    // height: "250px",
                    borderRadius: "5px",
                    marginBottom: "40px "
                },
                children: /*#__PURE__*/ _jsx(CustomImageContainer, {
                    src: bannerImage,
                    alt: "banner",
                    height: "100%",
                    width: "100%",
                    obejctfit: "contained"
                })
            })
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DiscountBanner)));


/***/ }),

/***/ 38236:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(40116);
/* harmony import */ var _footer_footer_middle_AppLinks__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(91245);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_footer_footer_middle_AppLinks__WEBPACK_IMPORTED_MODULE_4__]);
_footer_footer_middle_AppLinks__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const DownloadApps = ({ theme , isSmall , landingPageData  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
        alignItems: isSmall ? "center" : "flex-start",
        justifyContent: "center",
        gap: {
            xs: "10px",
            sm: "15px"
        },
        paddingBottom: {
            xs: "20px",
            md: "0px"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                textAlign: "flex-start",
                fontSize: isSmall ? "14px" : "26px",
                fontWeight: 600,
                component: "h2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    theme: theme,
                    text: landingPageData?.download_user_app_title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                textAlign: "flex-start",
                fontSize: isSmall ? "12px" : "18px",
                sx: {
                    color: (theme)=>(0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.neutral[500], 0.8)
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    theme: theme,
                    text: landingPageData?.download_user_app_sub_title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_footer_footer_middle_AppLinks__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                landingPageData: landingPageData,
                graybackground: true
            })
        ]
    });
};
DownloadApps.propTypes = {};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DownloadApps)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 67763:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(25675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



const earnMoneyData = [
    {
        imageSrc: "/landingpage/vendor-1.png",
        title: "Become a Courier",
        buttonText: "Register here"
    },
    {
        imageSrc: "/landingpage/vendor-2.png",
        title: "Become a Partner",
        buttonText: "Register here"
    }
];
const EarnMoney = ()=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const isMobile = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
        sx: {
            width: "100%",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            paddingY: {
                xs: "3rem",
                md: "5rem"
            }
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
            sx: {
                //   backgroundColor: "#263471",
                width: {
                    xs: "90%",
                    sm: "75%",
                    md: "100%"
                },
                padding: {
                    xs: "2rem",
                    sm: "3rem",
                    md: "4rem"
                },
                borderRadius: "20px",
                textAlign: "center"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                    variant: "h4",
                    color: "white",
                    fontWeight: 700,
                    mb: 4,
                    children: "Earn Money"
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    container: true,
                    spacing: 4,
                    justifyContent: "center",
                    children: earnMoneyData.map((item, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                            item: true,
                            xs: 12,
                            sm: 8,
                            md: 5,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                sx: {
                                    display: "flex",
                                    flexDirection: "column",
                                    alignItems: "center",
                                    gap: "1rem"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box, {
                                        sx: {
                                            width: "140px",
                                            height: "140px",
                                            position: "relative"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            src: item.imageSrc,
                                            alt: item.title,
                                            fill: true,
                                            style: {
                                                objectFit: "contain",
                                                borderRadius: "10px"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        color: "white",
                                        variant: "h6",
                                        fontWeight: 600,
                                        mb: 2,
                                        children: item.title
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button, {
                                        variant: "contained",
                                        color: "primary",
                                        sx: {
                                            borderRadius: "20px",
                                            padding: "0.8rem 2rem"
                                        },
                                        children: item.buttonText
                                    })
                                ]
                            })
                        }, index))
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (EarnMoney);


/***/ }),

/***/ 51610:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const HeroBgSvg = ()=>{
    const theme = useTheme();
    return /*#__PURE__*/ _jsxs("svg", {
        width: "1240",
        height: "504",
        viewBox: "0 0 1240 504",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ _jsx("mask", {
                id: "mask0_472_1558",
                maskUnits: "userSpaceOnUse",
                x: "0",
                y: "0",
                width: "1240",
                height: "504",
                children: /*#__PURE__*/ _jsx("rect", {
                    width: "1240",
                    height: "504",
                    rx: "20",
                    fill: "#E9F5EE"
                })
            }),
            /*#__PURE__*/ _jsxs("g", {
                mask: "url(#mask0_472_1558)",
                children: [
                    /*#__PURE__*/ _jsx("rect", {
                        width: "1240",
                        height: "504",
                        rx: "20",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M940.824 17.9871C938.255 17.3066 935.94 15.3559 934.629 12.743L928.605 0.749507C928.359 0.266899 927.929 -0.103066 927.448 -0.23189L917.103 -2.96755C916.623 -3.09637 916.138 -2.96679 915.797 -2.63981L907.581 5.59424C905.797 7.38063 903.197 8.0404 900.628 7.35994C896.101 6.16329 892.828 1.26494 893.355 -3.56931L896.406 -31.7049C897.078 -37.8888 902.347 -41.6665 908.153 -40.1318L943.741 -30.7316C949.547 -29.1969 953.719 -22.9195 953.047 -16.7356L949.996 11.4C949.472 16.2222 945.363 19.188 940.824 17.9871ZM917.228 -4.1561L927.573 -1.42042C928.405 -1.19822 929.152 -0.566092 929.572 0.26812L935.596 12.2616C936.724 14.5065 938.723 16.1951 940.951 16.7865C944.869 17.8188 948.421 15.2676 948.869 11.106L951.921 -17.0296C952.517 -22.5529 948.788 -28.1692 943.603 -29.5353L908.015 -38.9356C902.83 -40.3017 898.115 -36.9265 897.519 -31.4032L894.468 -3.26758C894.017 0.906086 896.834 5.139 900.741 6.16706C902.958 6.75414 905.206 6.18274 906.752 4.64505L914.968 -3.589C915.546 -4.16467 916.384 -4.38263 917.216 -4.16042L917.228 -4.1561Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M899.659 7.71812C895.275 6.06822 892.229 1.15017 892.758 -3.6971L895.81 -31.8383C896.148 -35.0015 897.63 -37.6561 899.976 -39.3484C902.32 -41.0286 905.246 -41.5271 908.204 -40.7522L943.797 -31.35C946.752 -30.5631 949.412 -28.5996 951.279 -25.8029C953.135 -23.0106 953.972 -19.7299 953.636 -16.5788L950.585 11.5624C950.311 14.0606 949.14 16.1692 947.288 17.514C945.426 18.8423 943.116 19.2345 940.768 18.624C938.01 17.8984 935.528 15.7938 934.128 13.0165L928.103 1.02069C927.956 0.718149 927.682 0.485242 927.388 0.413442L917.042 -2.32276C916.747 -2.39456 916.436 -2.32942 916.232 -2.12027L908.014 6.11542C906.106 8.02438 903.321 8.73237 900.564 8.00679C900.258 7.93067 899.969 7.83474 899.67 7.72244L899.659 7.71812ZM944.438 -28.6115C944.14 -28.7238 943.85 -28.8197 943.545 -28.8958L907.952 -38.2979C905.594 -38.9249 903.271 -38.5249 901.42 -37.1922C899.556 -35.8518 898.386 -33.7432 898.109 -31.2329L895.058 -3.09171C894.643 0.732178 897.221 4.62885 900.825 5.56894C902.867 6.1034 904.93 5.59198 906.34 4.17188L914.558 -4.06382C915.263 -4.77387 916.282 -5.02785 917.303 -4.76061L927.649 -2.02439C928.659 -1.76147 929.574 -0.987768 930.09 0.0388254L936.115 12.0347C937.156 14.1042 938.987 15.6517 941.029 16.1861C942.765 16.6445 944.485 16.355 945.855 15.3621C947.226 14.3693 948.096 12.8108 948.296 10.9614L951.348 -17.1799C951.625 -19.6901 950.953 -22.2839 949.485 -24.5012C948.203 -26.4272 946.438 -27.872 944.441 -28.6235L944.438 -28.6115Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M632.749 153.812C630.18 153.132 627.865 151.181 626.554 148.568L620.53 136.575C620.284 136.092 619.854 135.722 619.373 135.593L609.028 132.858C608.548 132.729 608.063 132.858 607.722 133.185L599.506 141.419C597.722 143.206 595.121 143.866 592.553 143.185C588.025 141.988 584.753 137.09 585.28 132.256L588.331 104.12C589.003 97.9364 594.272 94.1586 600.078 95.6934L635.666 105.094C641.472 106.628 645.644 112.906 644.972 119.09L641.921 147.225C641.397 152.047 637.288 155.013 632.749 153.812ZM609.153 131.669L619.498 134.405C620.33 134.627 621.077 135.259 621.497 136.093L627.521 148.087C628.648 150.332 630.648 152.02 632.876 152.612C636.794 153.644 640.346 151.093 640.794 146.931L643.845 118.796C644.441 113.272 640.713 107.656 635.528 106.29L599.94 96.8897C594.754 95.5235 590.04 98.8987 589.444 104.422L586.393 132.558C585.942 136.731 588.759 140.964 592.666 141.992C594.882 142.579 597.13 142.008 598.677 140.47L606.893 132.236C607.471 131.661 608.309 131.443 609.141 131.665L609.153 131.669Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M591.584 143.544C587.199 141.894 584.154 136.976 584.683 132.128L587.734 103.987C588.073 100.824 589.555 98.1691 591.901 96.4768C594.245 94.7966 597.171 94.2981 600.129 95.073L635.722 104.475C641.844 106.103 646.256 112.719 645.55 119.242L642.498 147.384C642.225 149.882 641.054 151.991 639.201 153.335C637.349 154.68 635.03 155.056 632.682 154.445C629.924 153.72 627.442 151.615 626.041 148.838L620.017 136.842C619.869 136.539 619.596 136.306 619.302 136.235L608.955 133.498C608.661 133.427 608.35 133.492 608.145 133.701L599.928 141.937C598.019 143.846 595.235 144.554 592.477 143.828C592.171 143.752 591.882 143.656 591.595 143.548L591.584 143.544ZM636.363 107.214C636.065 107.102 635.776 107.006 635.47 106.93L599.877 97.5272C595.008 96.2413 590.594 99.4185 590.034 104.592L586.982 132.734C586.782 134.583 587.271 136.51 588.366 138.145C589.458 139.791 591.014 140.936 592.75 141.394C594.792 141.929 596.855 141.418 598.265 139.997L606.483 131.762C607.186 131.064 608.207 130.798 609.228 131.065L619.574 133.801C620.584 134.064 621.499 134.838 622.015 135.864L628.04 147.86C629.081 149.93 630.912 151.477 632.954 152.012C636.544 152.96 639.805 150.623 640.222 146.787L643.273 118.646C643.55 116.135 642.881 113.529 641.41 111.324C640.117 109.394 638.363 107.953 636.366 107.202L636.363 107.214Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M602.699 122.063L600.662 121.544C600.337 121.465 600.097 121.104 600.131 120.763L601.581 107.784C601.614 107.442 601.923 107.229 602.249 107.309L604.286 107.828C604.611 107.907 604.851 108.267 604.818 108.609L603.367 121.587C603.334 121.929 603.025 122.142 602.699 122.063ZM601.398 120.44L602.248 120.658L603.55 108.931L602.7 108.713L601.398 120.44Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M600.488 122.114C599.883 121.889 599.476 121.223 599.548 120.572L600.985 107.638C601.018 107.297 601.184 107.006 601.444 106.831C601.703 106.656 602.016 106.595 602.336 106.687L604.354 107.204C605.021 107.383 605.498 108.089 605.414 108.79L603.977 121.725C603.944 122.065 603.778 122.356 603.519 122.531C603.272 122.711 602.947 122.767 602.624 122.688L600.606 122.171C600.606 122.171 600.521 122.14 600.485 122.126L600.488 122.114Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M607.986 117.671L596.615 114.778C596.316 114.707 596.097 114.379 596.128 114.068L596.343 112.122C596.374 111.811 596.658 111.616 596.957 111.687L608.33 114.568C608.629 114.639 608.848 114.967 608.817 115.279L608.602 117.224C608.571 117.536 608.287 117.731 607.989 117.659L607.986 117.671ZM597.289 113.782L607.563 116.387L607.654 115.576L597.38 112.971L597.289 113.782Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M596.416 115.339C595.855 115.133 595.478 114.519 595.547 113.918L595.762 111.955C595.793 111.64 595.948 111.371 596.189 111.209C596.418 111.042 596.72 110.99 597.02 111.062L608.422 113.981C609.043 114.133 609.483 114.795 609.404 115.442L609.189 117.406C609.11 118.053 608.552 118.451 607.933 118.287L596.531 115.368C596.531 115.368 596.453 115.34 596.419 115.327L596.416 115.339Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M621.451 121.172C619.985 120.789 618.932 119.198 619.106 117.638C619.27 116.074 620.602 115.122 622.066 115.518C623.533 115.901 624.586 117.492 624.411 119.052C624.248 120.616 622.915 121.568 621.451 121.172ZM621.93 116.712C621.092 116.487 620.329 117.038 620.23 117.931C620.131 118.825 620.74 119.736 621.579 119.961C622.417 120.186 623.18 119.635 623.279 118.742C623.377 117.848 622.769 116.937 621.93 116.712Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M621.057 121.693C619.438 121.082 618.319 119.269 618.516 117.482C618.62 116.564 619.045 115.781 619.732 115.293C620.42 114.806 621.274 114.656 622.135 114.89C623.917 115.379 625.213 117.298 625.003 119.211C624.899 120.129 624.474 120.912 623.787 121.4C623.099 121.887 622.245 122.037 621.383 121.803C621.279 121.764 621.161 121.732 621.057 121.693ZM621.862 117.343C621.343 117.2 620.872 117.546 620.821 118.091C620.791 118.355 620.859 118.629 621.02 118.874C621.184 119.106 621.397 119.278 621.645 119.346C622.164 119.489 622.635 119.143 622.686 118.598C622.751 118.046 622.358 117.478 621.86 117.355L621.862 117.343Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M634.084 123.751C632.618 123.368 631.564 121.777 631.739 120.217C631.902 118.653 633.235 117.701 634.699 118.097C636.166 118.48 637.219 120.071 637.044 121.631C636.881 123.195 635.548 124.147 634.084 123.751ZM634.563 119.291C633.724 119.066 632.961 119.617 632.863 120.51C632.764 121.404 633.373 122.316 634.211 122.54C635.05 122.765 635.813 122.215 635.912 121.321C636.01 120.427 635.402 119.516 634.563 119.291Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M633.689 124.272C632.071 123.661 630.951 121.849 631.149 120.062C631.357 118.161 632.973 116.988 634.768 117.469C636.572 117.967 637.846 119.877 637.635 121.79C637.531 122.708 637.106 123.492 636.419 123.979C635.731 124.467 634.877 124.616 634.016 124.382C633.912 124.343 633.794 124.312 633.689 124.272ZM634.495 119.922C633.976 119.779 633.505 120.125 633.454 120.67C633.424 120.934 633.491 121.209 633.652 121.453C633.814 121.697 634.03 121.858 634.278 121.925C634.525 121.992 634.77 121.954 634.975 121.808C635.168 121.658 635.3 121.446 635.33 121.182C635.395 120.63 635.013 120.066 634.504 119.939L634.495 119.922Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M628.871 115.067C627.404 114.682 626.349 113.091 626.522 111.533C626.685 109.97 628.017 109.02 629.482 109.418C630.95 109.803 632.004 111.394 631.831 112.952C631.657 114.51 630.336 115.464 628.871 115.067ZM629.347 110.611C628.508 110.385 627.745 110.934 627.647 111.827C627.549 112.72 628.158 113.632 628.997 113.858C629.836 114.083 630.599 113.534 630.697 112.641C630.795 111.748 630.186 110.837 629.347 110.611Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M628.476 115.584C626.857 114.971 625.735 113.159 625.931 111.373C626.034 110.456 626.459 109.674 627.146 109.187C627.834 108.701 628.688 108.553 629.55 108.787C631.335 109.266 632.631 111.198 632.422 113.109C632.319 114.026 631.894 114.809 631.207 115.295C630.519 115.781 629.665 115.929 628.803 115.695C628.699 115.655 628.58 115.624 628.476 115.584ZM629.278 111.239C628.759 111.094 628.288 111.44 628.238 111.984C628.208 112.248 628.276 112.522 628.437 112.767C628.601 112.999 628.815 113.172 629.063 113.239C629.582 113.383 630.053 113.038 630.103 112.494C630.168 111.942 629.786 111.378 629.276 111.251L629.278 111.239Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M626.666 129.856C625.198 129.471 624.144 127.88 624.317 126.322C624.479 124.759 625.812 123.809 627.277 124.207C628.744 124.592 629.799 126.183 629.626 127.741C629.463 129.304 628.131 130.253 626.666 129.856ZM627.142 125.4C626.303 125.174 625.54 125.723 625.442 126.616C625.344 127.509 625.953 128.421 626.792 128.646C627.631 128.872 628.394 128.323 628.492 127.43C628.59 126.537 627.981 125.626 627.142 125.4Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M626.281 130.38C624.662 129.767 623.541 127.955 623.736 126.169C623.84 125.252 624.264 124.47 624.951 123.983C625.639 123.497 626.493 123.349 627.355 123.583C629.143 124.05 630.436 125.994 630.227 127.905C630.124 128.822 629.699 129.605 629.012 130.091C628.325 130.577 627.47 130.726 626.608 130.491C626.504 130.451 626.386 130.42 626.281 130.38ZM627.084 126.035C626.565 125.89 626.094 126.236 626.043 126.78C626.013 127.044 626.081 127.318 626.242 127.563C626.406 127.795 626.62 127.968 626.868 128.035C627.387 128.179 627.858 127.834 627.909 127.29C627.973 126.738 627.591 126.174 627.081 126.047L627.084 126.035Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M617.574 130.613L611.448 129.034C611.147 128.96 610.927 128.626 610.958 128.308L611.162 126.486C611.193 126.169 611.479 125.971 611.78 126.044L617.905 127.623C618.206 127.697 618.427 128.031 618.396 128.349L618.191 130.171C618.16 130.488 617.875 130.686 617.574 130.613ZM612.14 128.011L617.158 129.308L617.236 128.654L612.219 127.357L612.14 128.011Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M611.266 129.614C610.7 129.404 610.32 128.779 610.388 128.166L610.594 126.33C610.673 125.671 611.234 125.267 611.858 125.435L618.004 127.027C618.627 127.195 619.073 127.857 618.995 128.517L618.789 130.353C618.758 130.673 618.602 130.947 618.36 131.112C618.117 131.277 617.824 131.334 617.525 131.248L611.379 129.656C611.379 129.656 611.3 129.627 611.266 129.614Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M619.03 100.143C618.7 100.067 618.459 99.7058 618.495 99.3615L619.542 90.3987C619.578 90.0544 619.892 89.8373 620.222 89.9141C620.552 89.9909 620.792 90.3517 620.757 90.696L619.709 99.6589C619.674 100.003 619.36 100.22 619.03 100.143Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M618.841 100.743C618.234 100.522 617.829 99.8563 617.893 99.1965L618.921 90.2795C618.956 89.937 619.124 89.6429 619.385 89.4643C619.647 89.2858 619.961 89.2224 620.285 89.2988C620.954 89.4731 621.429 90.1784 621.342 90.8844L620.314 99.8014C620.279 100.144 620.11 100.438 619.849 100.617C619.588 100.795 619.273 100.859 618.95 100.782C618.95 100.782 618.865 100.751 618.828 100.738L618.841 100.743Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M866.594 229.644C866.523 229.618 866.455 229.579 866.402 229.532C857.642 222.104 853.273 209.889 855.511 199.152C857.748 188.416 866.212 181.038 876.555 180.811C876.694 180.81 876.835 180.863 876.954 180.962C885.714 188.39 890.109 200.601 887.869 211.35C885.629 222.099 877.167 229.464 866.801 229.683C866.737 229.685 866.664 229.671 866.594 229.644ZM876.507 182.071C866.728 182.391 858.759 189.396 856.638 199.577C854.516 209.758 858.617 221.314 866.848 228.423C876.637 228.12 884.62 221.106 886.742 210.925C888.863 200.744 884.753 189.172 876.507 182.071Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M866.468 230.253C866.327 230.2 866.192 230.123 866.073 230.025C857.115 222.416 852.642 209.927 854.932 198.935C857.223 187.944 865.881 180.405 876.463 180.163C876.744 180.149 877.037 180.259 877.284 180.472C886.245 188.068 890.741 200.567 888.448 211.571C886.155 222.574 877.496 230.114 866.894 230.334C866.755 230.335 866.609 230.307 866.468 230.253ZM876.367 182.748C866.952 183.163 859.278 189.983 857.232 199.802C855.186 209.622 859.107 220.813 866.99 227.749C876.414 227.35 884.102 220.523 886.148 210.703C888.194 200.884 884.276 189.681 876.367 182.748Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M877.546 180.812C877.479 180.788 877.414 180.752 877.363 180.709C876.166 179.735 874.911 178.863 873.615 178.124C873.368 177.986 873.228 177.688 873.285 177.425C873.343 177.162 873.583 177.001 873.85 177.047C876.766 177.541 879.558 178.546 882.237 180.067C882.484 180.205 882.624 180.503 882.567 180.766C882.509 181.03 882.269 181.19 882.003 181.144C880.574 180.901 879.137 180.804 877.743 180.846C877.671 180.844 877.613 180.836 877.546 180.812ZM876.783 178.894C877.127 179.141 877.454 179.408 877.796 179.666C878.183 179.657 878.579 179.664 878.973 179.682C878.254 179.387 877.528 179.125 876.795 178.898L876.783 178.894Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M877.419 181.411C877.285 181.362 877.155 181.29 877.042 181.198C875.872 180.234 874.643 179.374 873.373 178.65C872.866 178.365 872.588 177.75 872.706 177.205C872.824 176.659 873.308 176.322 873.855 176.42C876.829 176.925 879.732 177.981 882.475 179.554C882.98 179.85 883.26 180.453 883.142 180.999C883.024 181.545 882.54 181.882 881.994 181.784C880.596 181.538 879.19 181.441 877.827 181.484C877.693 181.485 877.554 181.459 877.419 181.411ZM874.22 177.693C874.081 177.667 873.941 177.641 873.813 177.62C874.334 177.897 874.858 178.213 875.368 178.536L874.232 177.697L874.22 177.693ZM881.747 180.404L880.524 180.36C881.033 180.408 881.538 180.478 882.051 180.565C881.955 180.505 881.846 180.453 881.747 180.404Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M865.242 232.348C863.857 231.85 862.477 231.217 861.127 230.447C860.88 230.308 860.74 230.011 860.798 229.748C860.855 229.484 861.095 229.323 861.362 229.37C862.769 229.605 864.191 229.709 865.611 229.664C865.743 229.662 865.878 229.711 865.99 229.801C867.165 230.767 868.431 231.643 869.75 232.39C869.997 232.528 870.137 232.825 870.079 233.089C870.022 233.352 869.782 233.513 869.515 233.466C868.05 233.223 866.616 232.843 865.231 232.344L865.242 232.348ZM864.392 230.831C865.111 231.127 865.837 231.389 866.57 231.616C866.227 231.368 865.888 231.098 865.561 230.832C865.173 230.841 864.777 230.834 864.381 230.827L864.392 230.831Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M865.115 232.95C863.691 232.433 862.275 231.767 860.887 230.974C860.38 230.69 860.102 230.075 860.22 229.53C860.337 228.984 860.821 228.646 861.368 228.745C862.744 228.982 864.138 229.076 865.524 229.041C865.791 229.038 866.071 229.14 866.298 229.322C867.445 230.278 868.685 231.142 869.989 231.879C870.496 232.164 870.774 232.779 870.656 233.324C870.539 233.87 870.054 234.208 869.508 234.109C868.015 233.854 866.527 233.464 865.104 232.946L865.115 232.95ZM862.863 230.165C862.353 230.118 861.838 230.043 861.324 229.956C861.434 230.009 861.53 230.069 861.639 230.121L862.863 230.165ZM868.008 231.986L869.144 232.825C869.284 232.85 869.412 232.872 869.552 232.898C869.031 232.621 868.507 232.305 868.008 231.986Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M869.69 231.943C869.69 231.943 869.619 231.917 869.595 231.908C868.12 231.046 866.7 230.044 865.392 228.936C865.184 228.764 865.088 228.486 865.141 228.237C865.193 227.987 865.383 227.816 865.627 227.814C875.651 227.584 883.858 220.475 886.033 210.113C888.208 199.751 883.979 187.974 875.49 180.83C875.282 180.658 875.187 180.38 875.239 180.131C875.291 179.882 875.481 179.711 875.726 179.708C877.286 179.673 878.89 179.803 880.474 180.086C880.548 180.1 880.607 180.122 880.676 180.162C892.177 186.9 898.591 201.054 895.91 213.822C893.23 226.591 882.253 234.237 869.792 232.008C869.757 231.995 869.721 231.982 869.697 231.973L869.69 231.943ZM867.32 228.985C868.162 229.623 869.041 230.207 869.944 230.734C881.785 232.798 892.212 225.51 894.764 213.353C897.316 201.195 891.244 187.734 880.323 181.294C879.346 181.116 878.365 181.018 877.4 180.967C885.428 188.53 889.337 200.186 887.169 210.511C885.002 220.835 877.126 228.082 867.323 228.973L867.32 228.985Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M869.576 232.553L869.356 232.444C867.87 231.578 866.419 230.551 865.07 229.401C864.655 229.057 864.454 228.485 864.561 227.974C864.668 227.463 865.06 227.126 865.551 227.108C875.317 226.893 883.313 219.955 885.433 209.849C887.554 199.743 883.431 188.28 875.174 181.305C874.759 180.961 874.558 180.389 874.665 179.878C874.773 179.367 875.164 179.03 875.655 179.012C877.252 178.978 878.88 179.104 880.512 179.392C880.648 179.417 880.791 179.47 880.929 179.548C892.692 186.439 899.246 200.921 896.505 213.981C893.765 227.04 882.532 234.863 869.801 232.583L869.594 232.533L869.576 232.553ZM869.05 229.44C869.4 229.665 869.751 229.89 870.092 230.098C881.571 232.044 891.682 224.93 894.155 213.141C896.629 201.353 890.759 188.255 880.194 181.948C879.81 181.885 879.426 181.821 879.048 181.788C886.455 189.574 889.858 200.74 887.758 210.746C885.659 220.753 878.408 227.93 869.05 229.44ZM875.87 180.369C875.87 180.369 875.832 180.368 875.818 180.376C876.046 180.57 876.263 180.758 876.48 180.947L875.87 180.369Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M862.89 230.712C862.89 230.712 862.818 230.685 862.782 230.672C851.242 223.963 844.844 209.761 847.584 196.896C850.323 184.032 861.387 176.27 873.908 178.436C874.232 178.487 874.482 178.824 874.473 179.172C874.463 179.521 874.181 179.756 873.857 179.704C861.907 177.641 851.345 185.046 848.731 197.319C846.117 209.593 852.216 223.144 863.24 229.553C863.537 229.731 863.673 230.12 863.556 230.429C863.447 230.7 863.162 230.826 862.887 230.724L862.89 230.712Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M862.75 231.32L862.528 231.211C850.743 224.355 844.208 209.825 847.005 196.681C849.802 183.537 861.121 175.584 873.907 177.799C874.231 177.851 874.528 178.028 874.736 178.322C874.958 178.607 875.066 178.945 875.057 179.293C875.047 179.642 874.906 179.942 874.671 180.139C874.435 180.337 874.133 180.428 873.812 180.364C862.181 178.345 851.892 185.568 849.346 197.532C846.8 209.495 852.741 222.71 863.474 228.946C863.77 229.124 863.996 229.396 864.119 229.726C864.241 230.056 864.241 230.421 864.114 230.713C863.893 231.268 863.313 231.514 862.752 231.307L862.75 231.32Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M865.258 232.485C864.913 232.37 864.71 232.011 864.792 231.663L877.361 178.442C877.443 178.094 877.774 177.912 878.119 178.027C878.463 178.141 878.666 178.501 878.584 178.849L866.015 232.07C865.933 232.418 865.602 232.599 865.258 232.485Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M865.177 233.1C864.496 232.872 864.074 232.119 864.236 231.424L876.669 178.26C876.831 177.565 877.518 177.184 878.199 177.413C878.88 177.642 879.302 178.394 879.139 179.09L866.707 232.254C866.544 232.949 865.857 233.329 865.177 233.1Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M894.303 213.339L848.814 198.236C848.517 198.137 848.341 197.826 848.412 197.524C848.484 197.223 848.77 197.065 849.068 197.164L894.556 212.267C894.854 212.366 895.03 212.677 894.958 212.978C894.887 213.28 894.6 213.437 894.303 213.339Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M894.201 213.98L848.672 198.735C848.076 198.535 847.708 197.877 847.85 197.268C847.993 196.66 848.595 196.327 849.19 196.526L894.719 211.771C895.315 211.971 895.683 212.629 895.541 213.238C895.398 213.846 894.796 214.18 894.201 213.98Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M726.015 151.786C724.539 150.491 726.179 148.058 727.644 149.348C729.121 150.643 727.48 153.076 726.015 151.786ZM726.015 151.786C727.48 153.076 729.118 150.655 727.644 149.348C726.179 148.058 724.542 150.479 726.015 151.786ZM727.869 156.906L734.191 147.479C734.374 147.206 734.316 146.807 734.057 146.593L695.067 112.138C694.811 111.911 694.46 111.949 694.288 112.226L687.965 121.653C687.783 121.926 687.841 122.325 688.1 122.539L702.177 134.984C702.433 135.21 702.785 135.173 702.956 134.896C703.139 134.622 703.081 134.223 702.822 134.01L689.194 121.967L694.861 113.511L732.941 147.157L727.274 155.613L712.692 142.731C712.436 142.505 712.085 142.543 711.914 142.82C711.742 143.097 711.789 143.493 712.048 143.706L727.079 156.99C727.335 157.217 727.686 157.179 727.857 156.902L727.869 156.906ZM701.171 187.472L723.474 154.197C723.656 153.924 723.598 153.524 723.339 153.311C723.083 153.085 722.732 153.122 722.561 153.4L700.584 186.196L670.307 159.443L692.283 126.646C692.466 126.373 692.408 125.974 692.149 125.76C691.893 125.534 691.542 125.572 691.37 125.849L669.068 159.125C668.885 159.398 668.943 159.797 669.202 160.011L700.39 187.574C700.646 187.8 700.997 187.762 701.168 187.485L701.171 187.472ZM690.156 177.452L719.023 134.376C719.206 134.103 719.147 133.704 718.888 133.49L709.18 124.92C708.924 124.694 708.573 124.732 708.401 125.009L679.534 168.085C679.351 168.358 679.41 168.757 679.669 168.971L689.377 177.541C689.633 177.767 689.984 177.729 690.156 177.452ZM708.988 126.286L717.783 134.058L689.572 176.163L680.777 168.39L708.988 126.286ZM713.742 129.311C714.003 129.512 714.348 129.445 714.511 129.151C717.47 123.805 716.802 120.133 715.712 117.975C714.283 115.142 711.563 113.772 709.633 113.695C705.655 113.528 705.451 121.028 705.452 121.353C705.448 121.703 705.688 122.005 705.997 122.047C706.309 122.076 706.56 121.827 706.575 121.481C706.577 121.414 706.805 114.856 709.681 114.97C711.345 115.033 713.614 116.284 714.752 118.554C715.678 120.397 716.228 123.608 713.553 128.446C713.407 128.719 713.474 129.081 713.707 129.299C713.719 129.303 713.73 129.307 713.75 129.328L713.742 129.311ZM715.51 130.168C718.891 125.959 721.74 125.753 723.527 126.306C725.726 126.991 727.368 129.197 727.847 131.016C728.677 134.178 723.218 136.108 723.164 136.13C722.873 136.229 722.722 136.581 722.831 136.917C722.94 137.253 723.264 137.449 723.555 137.35C723.821 137.255 730.086 135.11 728.922 130.749C728.363 128.63 726.506 125.957 723.757 125.103C721.674 124.445 718.398 124.648 714.662 129.3C714.459 129.552 714.495 129.943 714.723 130.187C714.734 130.191 714.743 130.207 714.763 130.228C714.999 130.433 715.319 130.425 715.519 130.185L715.51 130.168ZM691.182 152.8L695.917 145.731C696.1 145.458 696.042 145.059 695.783 144.845L685.483 135.741C685.227 135.515 684.876 135.553 684.704 135.83L679.969 142.898C679.786 143.171 679.844 143.571 680.103 143.784L690.403 152.889C690.659 153.115 691.01 153.077 691.182 152.8ZM685.291 137.106L694.681 145.4L690.589 151.494L681.2 143.2L685.291 137.106ZM712.041 171.221L716.776 164.153C716.959 163.88 716.901 163.48 716.642 163.267L705.736 153.637C705.48 153.411 705.129 153.448 704.957 153.726L700.222 160.794C700.039 161.067 700.097 161.467 700.356 161.68L711.262 171.31C711.518 171.536 711.869 171.499 712.041 171.221ZM705.555 155.006L715.548 163.839L711.457 169.933L701.464 161.1L705.555 155.006ZM728.31 157.292L734.632 147.866C734.995 147.332 734.878 146.533 734.378 146.085L695.387 111.629C694.887 111.181 694.185 111.257 693.822 111.79L687.499 121.217C687.136 121.75 687.253 122.549 687.753 122.997L701.831 135.443C702.332 135.891 703.034 135.816 703.397 135.282C703.76 134.748 703.643 133.949 703.142 133.501L689.975 121.865L694.986 114.381L732.156 147.217L727.145 154.702L713.024 142.227C712.524 141.779 711.821 141.854 711.458 142.388C711.095 142.922 711.212 143.721 711.713 144.169L726.744 157.453C727.244 157.901 727.947 157.826 728.31 157.292ZM726.938 156.075C727.194 156.301 727.546 156.264 727.717 155.986L733.384 147.531C733.567 147.258 733.509 146.859 733.25 146.645L695.17 112.999C694.914 112.773 694.563 112.811 694.391 113.088L688.724 121.543C688.541 121.816 688.6 122.216 688.859 122.429L688.398 122.022L694.72 112.596L733.711 147.052L727.388 156.478L712.357 143.194L726.938 156.075ZM701.612 187.859L723.914 154.583C724.277 154.049 724.161 153.251 723.66 152.803C723.159 152.354 722.457 152.43 722.094 152.964L700.447 185.268L671.08 159.325L692.727 127.02C693.09 126.486 692.973 125.688 692.472 125.239C691.972 124.791 691.269 124.867 690.906 125.401L668.604 158.676C668.241 159.21 668.358 160.009 668.858 160.457L700.046 188.02C700.547 188.468 701.249 188.392 701.612 187.859ZM669.964 159.889L700.241 186.642C700.497 186.868 700.848 186.83 701.02 186.553L722.996 153.757L700.693 187.032L669.506 159.469L669.835 158.978C669.652 159.251 669.71 159.65 669.969 159.864L669.964 159.889ZM690.599 177.826L719.467 134.75C719.83 134.216 719.713 133.417 719.212 132.969L709.503 124.4C709.003 123.952 708.301 124.027 707.938 124.561L679.07 167.636C678.707 168.17 678.824 168.969 679.325 169.417L689.033 177.987C689.534 178.435 690.236 178.359 690.599 177.826ZM680.442 168.853L689.237 176.625C689.493 176.852 689.844 176.814 690.016 176.537L718.227 134.432C718.41 134.159 718.351 133.759 718.093 133.546L718.553 133.953L689.686 177.028L679.981 168.446L680.31 167.954C680.127 168.228 680.186 168.627 680.444 168.841L680.442 168.853ZM709.114 127.155L716.988 134.114L689.42 175.244L681.547 168.285L709.114 127.155ZM709.309 125.777C709.053 125.551 708.702 125.589 708.53 125.866L708.859 125.374L709.32 125.781L709.309 125.777ZM713.449 129.802C713.699 129.999 714.003 130.066 714.297 130.008C714.592 129.951 714.829 129.764 714.989 129.483C718.088 123.889 717.353 119.964 716.196 117.674C714.646 114.609 711.693 113.128 709.619 113.041C705.13 112.855 704.898 120.927 704.897 121.264C704.877 121.96 705.379 122.571 705.988 122.638C706.286 122.676 706.577 122.577 706.786 122.354C707.006 122.134 707.121 121.837 707.133 121.503C707.174 119.936 707.746 115.473 709.698 115.558C711.191 115.614 713.242 116.747 714.271 118.789C715.121 120.483 715.613 123.457 713.07 128.031C712.769 128.56 712.909 129.313 713.381 129.724C713.392 129.728 713.443 129.773 713.463 129.794L713.449 129.802ZM714.022 128.762C716.284 124.683 716.333 121.644 715.748 119.584C716.333 121.644 716.284 124.683 714.034 128.766L713.696 129.241L714.025 128.749L714.022 128.762ZM715.155 118.116C713.929 115.801 711.625 114.483 709.862 114.318C710.979 114.416 712.327 114.962 713.494 115.998C714.128 116.561 714.706 117.267 715.155 118.116ZM715.932 130.588C719.14 126.602 721.76 126.382 723.408 126.899C725.388 127.521 726.871 129.507 727.303 131.148C727.868 133.296 724.27 135.061 722.957 135.515C722.375 135.714 722.086 136.41 722.293 137.078C722.512 137.751 723.148 138.139 723.731 137.94C726.347 137.07 730.483 134.535 729.448 130.584C728.843 128.287 726.838 125.398 723.862 124.464C721.629 123.766 718.137 123.947 714.229 128.821C714.041 129.066 713.946 129.383 713.97 129.717C713.994 130.05 714.132 130.369 714.351 130.595C714.362 130.599 714.422 130.661 714.431 130.678C714.903 131.089 715.56 131.051 715.932 130.588ZM723.802 125.727C726.084 126.537 727.677 128.684 728.275 130.519C727.881 129.311 727.059 127.992 725.93 127.01C725.304 126.463 724.585 126.005 723.802 125.727ZM691.625 153.173L696.361 146.105C696.724 145.571 696.607 144.772 696.107 144.324L685.806 135.22C685.306 134.772 684.603 134.847 684.24 135.381L679.505 142.45C679.142 142.984 679.259 143.782 679.759 144.23L690.06 153.335C690.56 153.783 691.262 153.707 691.625 153.173ZM680.865 143.662L690.254 151.957C690.51 152.183 690.862 152.145 691.033 151.868L695.124 145.774C695.307 145.501 695.249 145.102 694.99 144.888L695.451 145.295L690.715 152.364L680.415 143.26L680.744 142.768C680.561 143.041 680.62 143.44 680.879 143.654L680.865 143.662ZM685.405 137.972L693.882 145.469L690.446 150.592L681.97 143.094L685.405 137.972ZM685.6 136.594C685.344 136.368 684.993 136.405 684.822 136.683L685.151 136.191L685.612 136.598L685.6 136.594ZM712.482 171.608L717.217 164.539C717.58 164.005 717.463 163.207 716.963 162.759L706.057 153.128C705.556 152.68 704.854 152.756 704.491 153.29L699.755 160.358C699.392 160.892 699.509 161.691 700.01 162.139L710.916 171.769C711.416 172.217 712.119 172.142 712.482 171.608ZM701.126 161.575L711.119 170.408C711.375 170.634 711.726 170.596 711.898 170.319L715.989 164.225C716.172 163.952 716.114 163.553 715.855 163.339L716.316 163.746L711.58 170.815L700.674 161.184L701.003 160.693C700.82 160.966 700.879 161.365 701.138 161.579L701.126 161.575ZM705.667 155.884L714.738 163.903L711.303 169.026L702.231 161.007L705.667 155.884ZM705.862 154.506C705.606 154.28 705.255 154.318 705.083 154.595L705.412 154.103L705.873 154.51L705.862 154.506Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M530.342 -0.191978C530.271 -0.218533 530.203 -0.257427 530.15 -0.304237C521.39 -7.73249 517.021 -19.9475 519.259 -30.684C521.496 -41.4204 529.96 -48.798 540.303 -49.0254C540.442 -49.0261 540.583 -48.9729 540.702 -48.8749C549.462 -41.4466 553.857 -29.2351 551.617 -18.4863C549.377 -7.73758 540.915 -0.372319 530.549 -0.15376C530.485 -0.151208 530.412 -0.165424 530.342 -0.191978ZM540.256 -47.7654C530.476 -47.4455 522.507 -40.4402 520.386 -30.2591C518.264 -20.078 522.365 -8.52289 530.596 -1.41372C540.385 -1.71688 548.368 -8.73013 550.49 -18.9112C552.611 -29.0923 548.501 -40.6642 540.256 -47.7654Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M530.216 0.416215C530.075 0.363125 529.939 0.285354 529.823 0.175005C520.862 -7.42088 516.392 -19.9232 518.682 -30.9147C520.973 -41.9061 529.632 -49.4455 540.213 -49.6875C540.506 -49.6967 540.787 -49.5906 541.034 -49.3778C550.007 -41.7775 554.491 -29.283 552.198 -18.2792C549.906 -7.27543 541.247 0.263934 530.645 0.484703C530.505 0.485382 530.359 0.456959 530.218 0.403868L530.216 0.416215ZM540.115 -47.0901C530.7 -46.6745 523.026 -39.8547 520.98 -30.0352C518.934 -20.2157 522.855 -9.02478 530.738 -2.08801C540.162 -2.48678 547.85 -9.3145 549.896 -19.134C551.942 -28.9536 548.023 -40.1568 540.115 -47.0901Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M528.993 2.50332C527.608 2.00471 526.228 1.37207 524.878 0.601961C524.631 0.463659 524.491 0.166211 524.549 -0.0972439C524.606 -0.360699 524.846 -0.521436 525.113 -0.47477C526.52 -0.240224 527.942 -0.135698 529.362 -0.180691C529.494 -0.182278 529.629 -0.134027 529.741 -0.0439774C530.916 0.922444 532.182 1.79844 533.501 2.54503C533.748 2.68334 533.888 2.98079 533.83 3.24424C533.773 3.5077 533.533 3.66843 533.266 3.62176C531.801 3.37857 530.367 2.99791 528.982 2.4993L528.993 2.50332ZM528.143 0.98672C528.862 1.28245 529.588 1.54382 530.321 1.77082C529.978 1.52358 529.639 1.25344 529.312 0.987311C528.924 0.996093 528.528 0.989396 528.132 0.982701L528.143 0.98672Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M528.866 3.10014C527.454 2.58648 526.026 1.91716 524.638 1.12417C524.131 0.839656 523.853 0.224904 523.971 -0.320913C524.088 -0.86673 524.573 -1.20425 525.119 -1.10555C526.495 -0.868374 527.89 -0.774638 529.275 -0.809258C529.545 -0.824088 529.825 -0.722166 530.06 -0.523883C531.219 0.436149 532.459 1.30043 533.741 2.02944C534.248 2.31395 534.526 2.92868 534.408 3.4745C534.29 4.02032 533.806 4.35785 533.259 4.25915C531.755 4.00036 530.279 3.61381 528.855 3.09607L528.866 3.10014ZM526.603 0.310715C526.093 0.263161 525.578 0.188302 525.075 0.105908C525.185 0.158288 525.281 0.218201 525.391 0.270581L526.603 0.310715ZM531.739 2.1157L532.896 2.97468C533.035 3.00037 533.175 3.02605 533.314 3.05175C532.783 2.7707 532.258 2.45481 531.739 2.1157Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M533.437 2.11226C533.437 2.11226 533.366 2.08554 533.342 2.07663C531.867 1.21523 530.447 0.213101 529.139 -0.895004C528.931 -1.06692 528.835 -1.34481 528.888 -1.5942C528.94 -1.84358 529.13 -2.01457 529.374 -2.01722C539.398 -2.24703 547.605 -9.35653 549.78 -19.7184C551.955 -30.0802 547.726 -41.857 539.237 -49.0009C539.029 -49.1729 538.934 -49.4507 538.986 -49.7001C539.038 -49.9495 539.228 -50.1205 539.473 -50.1232C541.033 -50.1578 542.637 -50.0285 544.221 -49.7451C544.295 -49.7308 544.354 -49.7086 544.423 -49.6694C555.924 -42.9313 562.338 -28.7772 559.658 -16.0088C556.977 -3.24037 546 4.40595 533.539 2.1773C533.504 2.16394 533.468 2.15057 533.444 2.14166L533.437 2.11226ZM531.067 -0.845844C531.909 -0.208053 532.788 0.376306 533.691 0.902772C545.532 2.9666 555.959 -4.32082 558.511 -16.4782C561.063 -28.6356 554.991 -42.0969 544.07 -48.5374C543.093 -48.7147 542.112 -48.8128 541.147 -48.8645C549.176 -41.3011 553.084 -29.6446 550.916 -19.3201C548.749 -8.9957 540.873 -1.74901 531.07 -0.858308L531.067 -0.845844Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M533.324 2.71881L533.122 2.64313C531.618 1.74399 530.166 0.716684 528.815 -0.421C528.402 -0.77708 528.199 -1.33699 528.306 -1.84791C528.413 -2.35882 528.805 -2.69615 529.296 -2.7139C539.062 -2.92845 547.046 -9.87152 549.166 -19.9777C551.287 -30.0838 547.164 -41.5462 538.907 -48.5219C538.492 -48.8655 538.291 -49.4378 538.399 -49.9488C538.506 -50.4597 538.897 -50.797 539.388 -50.8148C540.986 -50.8484 542.625 -50.7183 544.246 -50.4343C544.382 -50.4102 544.524 -50.3568 544.662 -50.2784C556.425 -43.3879 562.979 -28.9052 560.239 -15.8457C557.499 -2.7862 546.265 5.03692 533.534 2.75711L533.327 2.70635L533.324 2.71881ZM532.798 -0.394851C533.148 -0.169619 533.498 0.0556223 533.839 0.263938C545.319 2.20984 555.43 -4.90484 557.903 -16.6933C560.377 -28.4817 554.507 -41.5794 543.942 -47.8868C543.558 -47.95 543.174 -48.0132 542.796 -48.0471C550.203 -40.2606 553.606 -29.0947 551.506 -19.0883C549.407 -9.08179 542.155 -1.90455 532.798 -0.394851ZM539.618 -49.4653C539.618 -49.4653 539.58 -49.4662 539.565 -49.4582C539.794 -49.265 540.011 -49.0763 540.228 -48.8876L539.618 -49.4653Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M526.64 0.875664C526.64 0.875664 526.568 0.849215 526.532 0.83599C514.992 -5.87279 508.594 -20.0753 511.334 -32.9397C514.073 -45.804 525.137 -53.5658 537.658 -51.4004C537.982 -51.3486 538.232 -51.0122 538.223 -50.6636C538.213 -50.3149 537.931 -50.0802 537.607 -50.132C525.657 -52.1951 515.095 -44.7904 512.481 -32.5165C509.867 -20.2425 515.966 -6.69243 526.99 -0.282538C527.287 -0.105104 527.423 0.283909 527.306 0.592909C527.197 0.864223 526.912 0.989632 526.637 0.888238L526.64 0.875664Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M526.498 1.47918L526.295 1.40429C514.491 -5.48504 507.965 -19.9987 510.764 -33.155C513.564 -46.3113 524.881 -54.2517 537.667 -52.0367C537.979 -51.9894 538.287 -51.8077 538.495 -51.5143C538.718 -51.2291 538.826 -50.8912 538.816 -50.5428C538.794 -49.8334 538.228 -49.3518 537.569 -49.4597C525.938 -51.4784 515.649 -44.2552 513.103 -32.2916C510.558 -20.3279 516.498 -7.11364 527.231 -0.876925C527.528 -0.69962 527.753 -0.426966 527.876 -0.0972612C527.999 0.232446 527.998 0.597823 527.872 0.889639C527.651 1.44442 527.07 1.69063 526.51 1.48359L526.498 1.47918Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M529.009 2.63629C528.664 2.52184 528.461 2.16215 528.543 1.81413L541.112 -51.4067C541.194 -51.7547 541.525 -51.9364 541.87 -51.8219C542.214 -51.7075 542.417 -51.3478 542.335 -50.9998L529.766 2.22107C529.684 2.56909 529.353 2.75074 529.009 2.63629Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M528.928 3.25179C528.247 3.02313 527.825 2.27029 527.987 1.575L540.42 -51.5888C540.582 -52.2841 541.269 -52.6643 541.95 -52.4356C542.631 -52.207 543.053 -51.4541 542.89 -50.7588L530.458 2.40495C530.295 3.10023 529.608 3.48044 528.928 3.25179Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1177.34 46.1624C1177.9 48.2127 1178.03 50.3625 1177.74 52.3869L1177.1 56.7897L1175.85 57.0925C1173.74 57.6068 1172.55 59.9927 1173.21 62.4014L1181.91 94.2224C1182.35 95.8226 1183.5 97.0487 1184.84 97.5333C1185.52 97.7799 1186.24 97.839 1186.95 97.6647L1187.89 97.4408L1191.21 101.635C1192.5 103.278 1193.49 105.225 1194.04 107.258L1196.14 114.934C1196.35 115.697 1196.81 116.347 1197.42 116.773C1197.62 116.911 1197.83 117.015 1198.05 117.094C1198.5 117.257 1198.97 117.295 1199.42 117.175L1206.06 115.553C1206.06 115.553 1206.18 115.516 1206.23 115.491C1206.28 115.483 1206.34 115.478 1206.41 115.462L1213.05 113.84C1214.42 113.504 1215.19 111.951 1214.76 110.38L1212.66 102.704C1212.1 100.654 1211.97 98.5162 1212.26 96.4794L1213.01 91.2935L1214.85 90.8413C1216.96 90.327 1218.15 87.9411 1217.49 85.5325L1214.71 75.3727L1215.6 75.157C1216.16 75.0243 1216.63 74.6415 1216.9 74.0794C1217.17 73.5298 1217.22 72.8633 1217.05 72.2215L1214.86 64.2163C1214.5 62.8869 1213.25 62.0274 1212.09 62.3219L1211.2 62.5376L1208.77 53.7072C1208.11 51.2985 1205.85 49.7505 1203.74 50.2649L1201.6 50.7834L1198.78 47.2142C1197.49 45.5714 1196.5 43.6249 1195.95 41.5912L1193.85 33.9152C1193.42 32.3441 1191.94 31.3386 1190.57 31.6745L1183.93 33.2964C1183.93 33.2964 1183.81 33.3338 1183.75 33.3545C1183.7 33.3628 1183.64 33.3669 1183.57 33.371L1176.93 34.9929C1176.27 35.1546 1175.72 35.604 1175.39 36.2535C1175.07 36.9031 1175.01 37.6904 1175.22 38.453L1177.32 46.1291L1177.34 46.1624ZM1206.59 54.2756L1209.14 63.6102C1209.05 63.8601 1209.03 64.1517 1209.11 64.4226L1211.92 74.7282C1212 75.0115 1212.16 75.2575 1212.37 75.4411L1215.28 86.0925C1215.56 87.1093 1215.06 88.1295 1214.16 88.341L1186.25 95.1352C1185.36 95.3509 1184.39 94.7041 1184.12 93.6748L1175.42 61.8538C1175.14 60.837 1175.64 59.821 1176.54 59.6053L1178.47 59.1325L1201.57 53.4954C1201.57 53.4954 1201.58 53.4996 1201.6 53.5038C1201.6 53.5038 1201.61 53.5079 1201.62 53.4996L1204.43 52.8194C1205.32 52.6037 1206.29 53.2505 1206.56 54.2798L1206.59 54.2756ZM1214.84 72.6858L1214.04 72.8807L1211.91 65.1005L1212.71 64.9055L1214.84 72.6858ZM1209.99 95.8729C1209.64 98.2805 1209.81 100.834 1210.48 103.272L1212.58 110.948C1212.63 111.128 1212.54 111.311 1212.38 111.348L1205.74 112.97C1205.74 112.97 1205.62 113.007 1205.58 113.032C1205.53 113.04 1205.46 113.045 1205.4 113.061L1198.76 114.683C1198.6 114.72 1198.43 114.604 1198.38 114.424L1196.28 106.748C1195.61 104.323 1194.45 102.001 1192.9 100.054L1190.38 96.8602L1210.56 91.9408L1209.99 95.8854L1209.99 95.8729ZM1184.3 35.9505C1184.3 35.9505 1184.42 35.9132 1184.46 35.8882C1184.51 35.8799 1184.57 35.8759 1184.64 35.8593L1191.28 34.2374C1191.38 34.2084 1191.46 34.2501 1191.51 34.2793C1191.55 34.296 1191.62 34.3753 1191.65 34.4919L1193.75 42.168C1194.42 44.5933 1195.58 46.915 1197.12 48.8622L1199.15 51.4182L1179.58 56.1799L1180.04 53.0184C1180.39 50.6108 1180.22 48.0568 1179.55 45.619L1177.45 37.943C1177.4 37.7638 1177.49 37.5805 1177.65 37.5432L1184.29 35.9214L1184.3 35.9505Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1073.3 46.1429C1073.29 49.0504 1074.75 51.8363 1077.07 53.4239L1122.71 84.3548C1123.22 84.7003 1123.76 84.9761 1124.32 85.1779C1126.29 85.8945 1128.43 85.6586 1130.09 84.4695L1133.05 82.3536C1133.71 81.8861 1134.05 81.0692 1133.99 80.1698C1133.93 79.2704 1133.46 78.4362 1132.74 77.9509L1129.06 75.4583L1145.29 42.5645C1145.42 42.2813 1145.46 41.9364 1145.36 41.6077C1145.27 41.2709 1145.06 40.9955 1144.8 40.8063L1097.22 8.55925C1096.96 8.38237 1096.64 8.3081 1096.35 8.38993C1096.07 8.47175 1095.83 8.66454 1095.68 8.94364L1079.48 41.8621L1076.72 39.9823C1075.99 39.4929 1075.13 39.4345 1074.43 39.8321C1073.73 40.2297 1073.31 41.0177 1073.32 41.9253L1073.32 46.1634L1073.3 46.1429ZM1142.73 42.2333L1127.05 74.0804L1081.48 43.1989L1097.19 11.3764L1142.73 42.2497L1142.73 42.2333ZM1098.54 57.6192L1107.67 63.8259C1107.02 64.2277 1106.18 64.2144 1105.45 63.725L1099.71 59.8381C1098.99 59.3486 1098.55 58.4857 1098.53 57.6151L1098.54 57.6192ZM1098.66 61.9806L1104.4 65.8676C1104.73 66.0938 1105.08 66.2748 1105.43 66.4025C1107.03 66.9792 1108.71 66.5539 1109.82 65.2943L1131.7 80.1756L1128.74 82.2915C1127.3 83.3248 1125.35 83.294 1123.76 82.2123L1078.13 51.2814C1076.56 50.2202 1075.58 48.3383 1075.59 46.3876L1075.58 42.1495C1075.58 42.1495 1075.59 42.1249 1075.61 42.1043L1075.3 41.5168L1075.65 42.1085L1096.41 56.1837C1095.93 58.3351 1096.83 60.7467 1098.67 61.997L1098.66 61.9806Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M984.854 13.4863C987.894 14.5891 990.598 16.8488 992.438 19.8613C994.69 23.529 995.491 27.9365 994.617 31.9756C994.534 32.3585 994.442 32.725 994.328 33.0832C994.233 33.4084 994.263 33.7791 994.412 34.1128C994.575 34.4384 994.838 34.694 995.146 34.8055L1024.27 45.3712C1024.58 45.4827 1024.92 45.446 1025.18 45.2733C1025.44 45.1006 1025.62 44.8084 1025.67 44.4543C1025.72 44.0713 1025.79 43.6843 1025.87 43.3137C1026.74 39.2869 1029.19 36.0443 1032.6 34.4294C1035.57 33.0159 1039.07 32.9949 1042.24 34.3161C1042.52 34.4194 1042.84 34.428 1043.1 34.2841C1043.38 34.1444 1043.57 33.8934 1043.65 33.5763C1043.73 33.2593 1043.7 32.9133 1043.56 32.5961C1043.4 32.287 1043.16 32.0397 1042.87 31.9199C1042.06 31.5731 1041.21 31.3169 1040.3 31.11L1042.16 -6.7849L1043.73 -6.2149C1044.85 -5.81011 1045.96 -6.45962 1046.22 -7.67013L1046.52 -9.05357C1046.78 -10.2641 1046.09 -11.5662 1044.98 -11.971L1038.42 -14.3501C1037.3 -14.7549 1036.19 -14.1054 1035.93 -12.8949L1035.63 -11.5115C1035.37 -10.3009 1036.06 -8.99883 1037.17 -8.59405L1039.9 -7.60686L1038.01 30.7987C1035.76 30.6727 1033.53 31.1028 1031.54 32.0355C1028.58 33.4367 1026.22 35.9011 1024.79 39.0172C1024.67 38.9223 1024.55 38.8522 1024.42 38.8026L997.238 28.9432C997.248 25.3232 996.204 21.6403 994.288 18.5207C992.118 14.989 988.947 12.3334 985.372 11.0364C984.757 10.8134 984.138 11.1751 983.994 11.8422C983.85 12.5092 984.233 13.2344 984.848 13.4574L984.854 13.4863ZM997.073 31.5211L1023.91 41.2566C1023.91 41.2566 1023.94 41.269 1023.97 41.2773C1023.85 41.6725 1023.74 42.0883 1023.65 42.4959L1023.65 42.5206L996.846 32.7976L996.851 32.7729C996.937 32.3776 997.014 31.9658 997.073 31.5211ZM1037.92 -10.9201L1038.12 -11.8465L1044.26 -9.62019L1044.06 -8.69378L1037.92 -10.9201Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M992.209 33.6497C993.699 26.7656 989.753 19.2977 983.409 16.9957C977.065 14.6937 970.697 18.4187 969.206 25.3029C967.716 32.187 971.662 39.6549 978.006 41.9569C984.35 44.2589 990.718 40.5339 992.209 33.6497ZM978.531 39.5301C973.419 37.6753 970.242 31.6613 971.443 26.1144C972.644 20.5674 977.772 17.5676 982.884 19.4225C987.996 21.2773 991.173 27.2913 989.972 32.8382C988.772 38.3852 983.643 41.385 978.531 39.5301Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M982.192 22.6727C978.735 21.4182 975.255 23.4538 974.443 27.2054C973.631 30.957 975.787 35.0379 979.244 36.2924C982.701 37.5469 986.181 35.5113 986.994 31.7597C987.806 28.0081 985.65 23.9272 982.192 22.6727ZM979.772 33.8532C977.547 33.0459 976.159 30.4189 976.682 28.0045C977.204 25.5901 979.445 24.2797 981.67 25.0871C983.895 25.8944 985.283 28.5214 984.76 30.9358C984.237 33.3502 981.997 34.6606 979.772 33.8532Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1026.07 43.9953C1024.58 50.8794 1028.52 58.3473 1034.87 60.6493C1041.21 62.9513 1047.58 59.2262 1049.07 52.3421C1050.56 45.4579 1046.61 37.9901 1040.27 35.688C1033.93 33.386 1027.56 37.1111 1026.07 43.9953ZM1035.39 58.2225C1030.28 56.3677 1027.1 50.3537 1028.3 44.8067C1029.5 39.2598 1034.63 36.26 1039.74 38.1148C1044.86 39.9697 1048.03 45.9836 1046.83 51.5306C1045.63 57.0775 1040.5 60.0774 1035.39 58.2225Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1039.03 41.3563C1035.57 40.1018 1032.09 42.1373 1031.28 45.889C1030.47 49.6406 1032.61 53.7173 1036.08 54.976C1039.55 56.2346 1043.02 54.1949 1043.83 50.4433C1044.64 46.6917 1042.5 42.6149 1039.03 41.3563ZM1036.61 52.5368C1034.39 51.7295 1033 49.1025 1033.52 46.6881C1034.04 44.2737 1036.28 42.9633 1038.51 43.7707C1040.73 44.578 1042.12 47.205 1041.6 49.6194C1041.08 52.0338 1038.84 53.3442 1036.61 52.5368Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M869.22 -48.7175L861.38 -54.7408L863.026 -57.6034C866.14 -63.0305 864.463 -70.6929 859.272 -74.6821C854.092 -78.6672 847.339 -77.4971 844.222 -72.0576L842.577 -69.1949L832.811 -76.7084C832.304 -77.1069 831.629 -77.0164 831.274 -76.5152L802.596 -34.8518C802.415 -34.5826 802.337 -34.222 802.407 -33.8613C802.477 -33.5006 802.669 -33.1895 802.943 -32.9695L845.969 0.131373C846.075 0.21025 846.185 0.276692 846.299 0.318268C846.494 0.388946 846.688 0.405725 846.884 0.356194C847.194 0.294341 847.451 0.0790495 847.592 -0.231701L869.65 -46.9926C869.919 -47.5519 869.724 -48.3066 869.218 -48.7051L869.22 -48.7175ZM805.207 -34.2397L832.547 -73.9479L841.403 -67.1401L838.74 -62.4877L837.036 -63.8036C836.771 -64.007 836.456 -64.0943 836.16 -64.0408C835.864 -63.9872 835.616 -63.8092 835.457 -63.5316C835.298 -63.2541 835.251 -62.9225 835.324 -62.5742C835.399 -62.2384 835.583 -61.9438 835.848 -61.7404L841.43 -57.4482C841.537 -57.3693 841.646 -57.3029 841.761 -57.2613C841.932 -57.1989 842.126 -57.1822 842.306 -57.211C842.601 -57.2646 842.85 -57.4425 843.009 -57.7201C843.33 -58.2877 843.159 -59.1004 842.618 -59.5113L840.712 -60.9808L843.375 -65.6332L858.226 -54.2094L855.563 -49.557L853.795 -50.9227C853.257 -51.3461 852.537 -51.2183 852.216 -50.6508C851.896 -50.0832 852.066 -49.2705 852.607 -48.8596L858.19 -44.5673C858.296 -44.4885 858.405 -44.422 858.52 -44.3804C858.692 -44.3181 858.886 -44.3013 859.065 -44.3301C859.361 -44.3837 859.621 -44.5575 859.78 -44.8351C859.939 -45.1126 859.986 -45.4442 859.913 -45.7925C859.837 -46.1284 859.654 -46.4229 859.389 -46.6263L857.547 -48.046L860.209 -52.6984L867.137 -47.3683L846.108 -2.79509L805.221 -34.248L805.207 -34.2397ZM858.098 -72.6273C860.079 -71.1038 861.473 -68.868 862.033 -66.318C862.593 -63.768 862.241 -61.2273 861.05 -59.1518L859.405 -56.2891L844.554 -67.7129L846.199 -70.5756C848.659 -74.8592 853.989 -75.7946 858.089 -72.6439L858.098 -72.6273Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M551.852 122.583C551.289 120.532 551.156 118.395 551.448 116.358L552.198 111.172L554.036 110.72C555.06 110.471 555.894 109.776 556.397 108.773C556.9 107.77 556.997 106.578 556.678 105.411L553.895 95.2516L554.787 95.0359C555.953 94.758 556.613 93.4339 556.24 92.1129L554.047 84.1076C553.689 82.7783 552.445 81.9229 551.276 82.2133L550.384 82.429L547.96 73.5986C547.641 72.4317 546.94 71.4228 545.985 70.7802C545.033 70.1252 543.95 69.9074 542.926 70.1563L540.788 70.6747L537.967 67.1181C536.67 65.4753 535.687 63.5287 535.133 61.4951L533.031 53.8191C532.823 53.0565 532.367 52.4061 531.751 51.9805C531.135 51.5549 530.419 51.4167 529.75 51.5784L523.11 53.2003C523.11 53.2003 522.99 53.2376 522.948 53.2626C522.896 53.2709 522.833 53.275 522.767 53.2916L516.127 54.9134C515.458 55.0752 514.914 55.5245 514.587 56.1741C514.259 56.8236 514.201 57.6109 514.408 58.3735L516.511 66.0496C517.074 68.0999 517.207 70.2372 516.915 72.2741L516.272 76.6769L515.026 76.9797C512.913 77.494 511.725 79.8799 512.384 82.2885L521.088 114.11C521.407 115.276 522.108 116.285 523.062 116.928C523.366 117.132 523.69 117.304 524.012 117.421C524.704 117.671 525.427 117.718 526.121 117.552L527.067 117.315L530.384 121.51C531.681 123.153 532.664 125.099 533.218 127.133L535.321 134.809C535.603 135.855 536.351 136.652 537.226 136.969C537.664 137.128 538.141 137.166 538.601 137.05L545.241 135.428C545.241 135.428 545.361 135.39 545.415 135.37C545.467 135.361 545.53 135.357 545.595 135.341L552.235 133.719C553.613 133.383 554.385 131.83 553.954 130.259L551.852 122.583ZM519.205 72.8889C519.553 70.4813 519.385 67.9274 518.72 65.4895L516.618 57.8135C516.569 57.6343 516.659 57.4511 516.816 57.4138L523.456 55.7919C523.456 55.7919 523.576 55.7545 523.619 55.7296C523.67 55.7213 523.733 55.7172 523.796 55.7131L530.436 54.0913C530.542 54.0622 530.62 54.104 530.663 54.1332C530.71 54.1499 530.779 54.2291 530.804 54.3458L532.907 62.0218C533.574 64.4472 534.737 66.7689 536.279 68.7161L538.31 71.272L518.735 76.0338L519.197 72.8723L519.205 72.8889ZM524.144 114.746C523.745 114.467 523.45 114.05 523.309 113.554L514.605 81.7327C514.464 81.2368 514.512 80.7286 514.727 80.308C514.943 79.8875 515.294 79.5837 515.726 79.4842L543.633 72.69C543.921 72.6194 544.228 72.6364 544.528 72.7451C544.666 72.7952 544.799 72.8703 544.929 72.958C545.329 73.2375 545.624 73.6544 545.765 74.1503L548.316 83.4849C548.225 83.7348 548.211 84.0264 548.289 84.2973L551.114 94.607C551.189 94.8904 551.347 95.1364 551.559 95.3074L554.483 105.963C554.612 106.455 554.576 106.967 554.36 107.388C554.145 107.808 553.796 108.099 553.362 108.212L525.455 115.006C525.021 115.118 524.558 115.017 524.158 114.738L524.144 114.746ZM554.009 92.5438L553.209 92.7387L551.079 84.9585L551.879 84.7635L554.009 92.5438ZM544.912 132.815C544.912 132.815 544.792 132.853 544.749 132.878C544.698 132.886 544.635 132.89 544.569 132.907L537.929 134.529C537.772 134.566 537.598 134.449 537.55 134.27L535.447 126.594C534.78 124.168 533.617 121.847 532.075 119.9L529.548 116.706L549.729 111.786L549.16 115.731C548.813 118.138 548.98 120.692 549.645 123.13L551.748 130.806C551.784 130.927 551.753 131.01 551.731 131.056C551.72 131.106 551.655 131.177 551.552 131.194L544.912 132.815Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M998.585 229.81L951.009 197.563C950.741 197.386 950.427 197.312 950.139 197.394C949.855 197.463 949.614 197.668 949.468 197.948L933.268 230.866L930.502 228.986C929.775 228.497 928.917 228.438 928.219 228.836C927.52 229.233 927.092 230.021 927.103 230.929L927.104 235.167C927.099 238.075 928.554 240.86 930.881 242.448L976.512 273.379C977.025 273.724 977.566 274 978.123 274.202C980.1 274.919 982.234 274.683 983.9 273.494L986.859 271.378C987.511 270.91 987.86 270.093 987.797 269.194C987.735 268.294 987.266 267.46 986.55 266.975L982.866 264.47L999.097 231.576C999.232 231.293 999.27 230.948 999.17 230.62C999.081 230.295 998.873 230.008 998.608 229.818L998.585 229.81ZM977.55 271.245L931.919 240.314C930.348 239.253 929.371 237.371 929.38 235.408L929.449 231.129L950.208 245.204C949.729 247.355 950.628 249.767 952.465 251.017L958.202 254.904C958.533 255.13 958.875 255.307 959.227 255.435C960.817 256.011 962.525 255.594 963.625 254.306L985.484 269.126L985.491 269.208L982.533 271.324C981.096 272.357 979.142 272.326 977.55 271.245ZM959.255 252.761L953.517 248.875C952.79 248.385 952.352 247.522 952.332 246.652L961.478 252.85C960.824 253.264 959.968 253.259 959.243 252.757L959.255 252.761ZM935.276 232.231L950.981 200.409L996.526 231.282L980.853 263.129L935.287 232.235L935.276 232.231Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M299.024 49.5767C299.324 49.9527 299.697 50.2214 300.107 50.3704C300.256 50.4242 300.407 50.4657 300.563 50.4824C301.772 50.6405 302.779 49.6839 302.798 48.3423C302.816 47.6942 302.597 47.0541 302.19 46.546C301.784 46.0378 301.24 45.7069 300.663 45.6444C300.077 45.5653 299.52 45.7505 299.099 46.1587C298.679 46.567 298.431 47.1446 298.427 47.7845C298.41 48.4326 298.629 49.0726 299.035 49.5808L299.024 49.5767Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M326.374 -9.64033C326.435 -12.4947 324.392 -15.0771 321.813 -15.4081L284.331 -20.2304C283.088 -20.3854 281.904 -20.0086 280.998 -19.1412C280.092 -18.2738 279.579 -17.0486 279.551 -15.6609L278.236 45.7977C278.182 48.2782 279.729 50.5734 281.842 51.3401C282.152 51.4526 282.47 51.5278 282.794 51.578L320.276 56.4002C321.519 56.5553 322.703 56.1784 323.609 55.311C324.515 54.4436 325.028 53.2184 325.056 51.8307L326.371 -9.62787L326.374 -9.64033ZM280.549 46.0994L280.673 40.2036L322.868 45.6334L322.743 51.5291C322.729 52.223 322.457 52.8501 322.017 53.2817C321.562 53.7216 320.965 53.908 320.338 53.8284L282.855 49.0061C281.553 48.8427 280.524 47.5286 280.552 46.0869L280.549 46.0994ZM324.061 -9.94196L323.977 -5.8328L281.782 -11.2625L281.867 -15.3717C281.894 -16.8134 282.984 -17.8427 284.286 -17.6793L321.769 -12.857C322.396 -12.7774 322.986 -12.4153 323.416 -11.883C323.854 -11.3341 324.089 -10.6441 324.064 -9.95441L324.061 -9.94196ZM323.918 -3.27341L322.929 43.0615L280.735 37.6318L281.723 -8.70316L323.918 -3.27341Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1263.57 311.616C1263.6 309.865 1263.01 308.126 1261.92 306.734C1260.81 305.339 1259.34 304.472 1257.74 304.265L1248.64 303.103L1244.87 298.353C1243.92 297.147 1242.63 296.387 1241.25 296.217L1233.68 295.253C1233.61 295.241 1233.54 295.241 1233.46 295.253C1233.39 295.228 1233.33 295.204 1233.25 295.204L1225.69 294.24C1224.33 294.066 1222.99 294.508 1222 295.45L1218.06 299.223L1208.96 298.061C1205.67 297.639 1202.94 300.257 1202.86 303.891L1202.16 338.369C1202.12 340.121 1202.71 341.86 1203.8 343.252C1204.61 344.274 1205.63 345.013 1206.74 345.416C1207.14 345.56 1207.55 345.659 1207.98 345.721L1256.79 351.933C1258.37 352.136 1259.89 351.637 1261.04 350.543C1262.2 349.437 1262.85 347.867 1262.89 346.103L1263.59 311.625L1263.57 311.616ZM1243.22 299.943L1245.41 302.701L1221.28 299.633L1223.56 297.437C1224.12 296.908 1224.87 296.663 1225.63 296.766L1233.2 297.73C1233.27 297.742 1233.34 297.742 1233.42 297.73C1233.48 297.755 1233.55 297.78 1233.63 297.78L1241.19 298.743C1241.96 298.838 1242.68 299.27 1243.22 299.943ZM1204.43 338.663L1205.14 304.184C1205.16 303.106 1205.56 302.122 1206.27 301.45C1206.98 300.766 1207.91 300.467 1208.89 300.583L1257.7 306.795C1257.96 306.824 1258.21 306.89 1258.45 306.977C1260.11 307.577 1261.32 309.371 1261.29 311.323L1260.59 345.802C1260.54 348.041 1258.86 349.659 1256.82 349.398L1208.01 343.199C1205.98 342.938 1204.37 340.91 1204.42 338.659L1204.43 338.663Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1225.71 331.858C1227.04 333.544 1228.72 334.78 1230.56 335.447C1231.22 335.687 1231.91 335.857 1232.6 335.948C1235.23 336.285 1237.72 335.467 1239.62 333.648C1241.53 331.83 1242.6 329.226 1242.66 326.324C1242.78 320.318 1238.48 314.873 1233.05 314.182C1227.62 313.495 1223.12 317.816 1222.98 323.818C1222.92 326.72 1223.89 329.582 1225.71 331.883L1225.71 331.858ZM1240.35 326.008C1240.26 330.606 1236.81 333.922 1232.64 333.385C1228.5 332.869 1225.18 328.687 1225.28 324.076C1225.33 321.851 1226.16 319.854 1227.61 318.461C1229.07 317.067 1230.98 316.437 1232.99 316.687C1233.53 316.762 1234.05 316.882 1234.55 317.064C1237.94 318.294 1240.44 321.979 1240.36 325.983L1240.35 326.008Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M400.642 19.3097C400.053 16.7295 398.357 14.587 396.114 13.5854L384.033 8.18335C381.778 7.17753 379.388 7.48856 377.606 9.02107L370.164 15.4016C368.463 16.8548 367.218 18.8519 366.541 21.1633L353.909 64.7653C353.664 65.6096 353.739 66.5295 354.119 67.3703C354.498 68.211 355.144 68.8639 355.917 69.2118L386.457 82.8532C386.527 82.8783 386.596 82.9035 386.666 82.9287C388.217 83.4906 389.809 82.6602 390.292 81.0093L402.924 37.4072C403.588 35.0917 403.648 32.5707 403.086 30.095L400.622 19.2888L400.642 19.3097ZM388.081 80.0328C388.026 80.2292 387.892 80.3838 387.723 80.4714C387.554 80.559 387.344 80.5504 387.161 80.4708L356.633 66.8336C356.245 66.666 356.025 66.1807 356.153 65.7669L368.785 22.1649C369.325 20.305 370.336 18.6964 371.704 17.5146L379.146 11.1341C380.235 10.2029 381.661 9.96191 383.04 10.4609C383.144 10.4986 383.248 10.5364 383.352 10.5741L395.433 15.9762C396.902 16.63 398.009 18.0318 398.391 19.7255L400.856 30.5316C401.311 32.5222 401.268 34.5624 400.724 36.4349L388.092 80.037L388.081 80.0328Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M387.923 19.4472C386.781 18.9258 385.545 19.5189 385.189 20.7652C385.009 21.3677 385.063 22.0283 385.338 22.6354C385.613 23.2425 386.067 23.7012 386.627 23.9578C386.684 23.9785 386.729 23.995 386.786 24.0157C387.3 24.202 387.833 24.182 388.302 23.9513C388.824 23.7001 389.195 23.234 389.375 22.6315C389.555 22.029 389.501 21.3684 389.226 20.7613C388.951 20.1542 388.497 19.6955 387.937 19.4389L387.923 19.4472Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1179.34 285.036L1119.69 257.067C1118.48 256.495 1117.19 256.477 1116.04 256.985C1114.89 257.505 1114.04 258.502 1113.65 259.797L1103.31 293.138C1102.91 294.429 1103.01 295.875 1103.58 297.199C1104.15 298.528 1105.13 299.568 1106.34 300.135L1129.96 311.219L1129.12 313.947L1123.62 311.363C1123.33 311.22 1123.02 311.228 1122.76 311.342C1122.48 311.468 1122.29 311.7 1122.18 312.005C1122.09 312.314 1122.1 312.661 1122.24 312.974C1122.38 313.288 1122.61 313.529 1122.91 313.676L1146.31 324.654C1146.31 324.654 1146.37 324.678 1146.41 324.69C1146.97 324.895 1147.56 324.606 1147.75 324.003C1147.95 323.364 1147.63 322.614 1147.03 322.345L1141.46 319.74L1142.37 317.036L1165.99 328.12C1167.2 328.688 1168.49 328.71 1169.64 328.202C1170.79 327.681 1171.64 326.684 1172.03 325.39L1182.37 292.049C1183.2 289.37 1181.84 286.232 1179.34 285.064L1179.34 285.036ZM1139.96 316.785L1139.55 318.125L1131.46 314.332L1131.88 312.993L1139.96 316.785ZM1166.71 325.783L1107.06 297.814C1105.75 297.194 1105.03 295.551 1105.47 294.142L1115.81 260.802C1116.22 259.474 1117.52 258.824 1118.76 259.273C1118.84 259.302 1118.91 259.326 1118.99 259.355L1178.63 287.324C1179.95 287.945 1180.66 289.587 1180.22 290.996L1169.88 324.336C1169.68 325.012 1169.23 325.537 1168.63 325.806C1168.03 326.078 1167.34 326.053 1166.71 325.759L1166.71 325.783Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1078.49 246.753C1078.1 246.612 1077.7 246.562 1077.3 246.549L1076.03 244.154C1075.71 243.543 1074.97 243.273 1074.45 243.578L1073.18 244.32C1072.65 244.633 1072.48 245.401 1072.81 246.041L1074.08 248.453C1073.9 248.8 1073.74 249.171 1073.66 249.567C1073.15 251.907 1074.49 254.452 1076.65 255.234C1077.02 255.367 1077.4 255.425 1077.78 255.429L1079.24 258.205C1079.4 258.502 1079.66 258.742 1079.95 258.85C1080.25 258.957 1080.56 258.937 1080.82 258.776L1082.09 258.035C1082.34 257.874 1082.53 257.622 1082.6 257.3C1082.67 256.978 1082.63 256.628 1082.46 256.326L1081.01 253.583C1081.21 253.216 1081.38 252.837 1081.47 252.416C1081.98 250.076 1080.63 247.531 1078.48 246.749L1078.49 246.753ZM1077.96 249.18C1078.89 249.515 1079.46 250.605 1079.24 251.608C1079.03 252.611 1078.1 253.155 1077.17 252.82C1076.25 252.484 1075.67 251.394 1075.89 250.391C1076.11 249.388 1077.04 248.844 1077.96 249.18Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1043.88 251.653L1043.89 251.748L1043.92 251.719C1043.92 251.719 1043.92 251.732 1043.94 251.752C1044.16 252.074 1044.36 252.4 1044.56 252.727L1045.52 252.088L1045.97 251.796L1046.46 251.479C1046.46 251.479 1046.45 251.462 1046.44 251.446L1046.38 251.33C1046.17 250.987 1046.1 250.575 1046.17 250.228L1046.51 248.669C1046.66 247.976 1047.31 247.597 1047.95 247.829L1049.58 248.421C1049.9 248.537 1050.18 248.813 1050.35 249.168L1050.42 249.288L1051.44 248.749L1052.41 248.234C1052.25 247.896 1052.1 247.561 1051.96 247.202L1051.98 247.186L1051.92 247.136C1051.7 246.616 1051.23 246.298 1050.75 246.322C1050.52 246.174 1050.3 246.054 1050.08 245.975L1048.45 245.383C1046.58 244.705 1044.69 245.808 1044.26 247.838L1043.92 249.397C1043.87 249.632 1043.85 249.892 1043.85 250.184C1043.58 250.597 1043.57 251.154 1043.86 251.616L1043.88 251.653Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1072.34 274.902C1071.15 274.471 1069.92 274.185 1068.72 274.056C1068.08 273.985 1067.58 274.508 1067.57 275.214C1067.57 275.549 1067.69 275.9 1067.92 276.168C1068.13 276.433 1068.42 276.59 1068.72 276.619C1069.75 276.728 1070.8 276.972 1071.82 277.345C1079.16 280.007 1083.72 288.648 1082 296.61C1080.28 304.571 1072.91 308.881 1065.57 306.219C1058.23 303.557 1053.67 294.916 1055.39 286.954C1055.64 285.791 1056.02 284.685 1056.51 283.661C1056.8 283.071 1056.57 282.266 1056.01 281.902C1055.74 281.724 1055.42 281.662 1055.13 281.732C1054.84 281.814 1054.61 282.008 1054.47 282.305C1053.89 283.498 1053.45 284.793 1053.16 286.143C1051.14 295.442 1056.48 305.537 1065.05 308.646C1073.61 311.755 1082.22 306.72 1084.24 297.421C1086.25 288.123 1080.92 278.028 1072.35 274.918L1072.34 274.902Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1081.98 234.564C1073.41 231.454 1064.8 236.49 1062.79 245.788C1062.51 247.076 1062.37 248.413 1062.36 249.759C1062.36 250.106 1062.48 250.444 1062.71 250.713C1062.92 250.977 1063.22 251.139 1063.51 251.164C1063.82 251.197 1064.1 251.098 1064.32 250.872C1064.54 250.657 1064.66 250.339 1064.66 250.005C1064.66 248.857 1064.78 247.714 1065.02 246.6C1066.75 238.638 1074.12 234.328 1081.45 236.99C1088.79 239.653 1093.36 248.294 1091.63 256.255C1089.91 264.216 1082.54 268.526 1075.2 265.864C1074.13 265.475 1073.1 264.954 1072.13 264.309C1071.86 264.131 1071.54 264.069 1071.26 264.139C1070.96 264.217 1070.73 264.415 1070.59 264.699C1070.46 264.984 1070.43 265.335 1070.52 265.661C1070.62 265.991 1070.82 266.276 1071.1 266.458C1072.23 267.215 1073.44 267.827 1074.68 268.279C1083.25 271.388 1091.86 266.353 1093.87 257.054C1095.88 247.755 1090.55 237.661 1081.98 234.551L1081.98 234.564Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1074.66 289.808C1074.73 289.486 1074.68 289.136 1074.51 288.834L1073.72 287.347C1073.56 287.033 1073.31 286.81 1073.01 286.702C1072.72 286.595 1072.41 286.615 1072.15 286.776L1069.81 288.144C1069.46 287.883 1069.1 287.66 1068.72 287.519C1066.56 286.737 1064.39 288.006 1063.88 290.346C1063.79 290.767 1063.78 291.205 1063.81 291.655L1061.77 292.849C1061.51 292.998 1061.32 293.274 1061.25 293.584C1061.18 293.893 1061.23 294.257 1061.4 294.558L1062.18 296.045C1062.35 296.359 1062.59 296.582 1062.89 296.69C1063.19 296.797 1063.5 296.777 1063.76 296.616L1065.8 295.409C1066.14 295.653 1066.49 295.872 1066.85 296.005C1069.01 296.787 1071.18 295.518 1071.69 293.178C1071.77 292.782 1071.79 292.361 1071.76 291.935L1074.13 290.551C1074.38 290.403 1074.57 290.126 1074.64 289.817L1074.66 289.808ZM1067.39 293.57C1066.47 293.234 1065.89 292.144 1066.11 291.141C1066.33 290.138 1067.26 289.594 1068.18 289.929C1069.11 290.265 1069.68 291.355 1069.46 292.358C1069.25 293.361 1068.32 293.905 1067.39 293.57Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1039.68 268.853L1039.68 268.878C1039.23 269.051 1038.99 269.538 1039.04 270.104C1038.93 270.356 1038.84 270.604 1038.78 270.852L1038.4 272.636C1037.96 274.669 1039.13 276.884 1041 277.564L1042.44 278.086C1042.65 278.165 1042.89 278.21 1043.14 278.235C1043.27 278.347 1043.4 278.434 1043.53 278.484C1043.59 278.504 1043.66 278.529 1043.72 278.538C1043.99 278.583 1044.24 278.513 1044.46 278.353L1044.52 278.373L1044.5 278.328C1044.51 278.315 1044.53 278.311 1044.55 278.303C1044.8 278.076 1045.08 277.87 1045.37 277.68L1044.7 276.543L1044.07 275.456L1043.95 275.522C1043.65 275.72 1043.29 275.777 1042.96 275.657L1041.52 275.135C1040.88 274.903 1040.48 274.142 1040.63 273.449L1041.02 271.664C1041.1 271.305 1041.32 271.012 1041.64 270.859L1041.76 270.785L1041.21 269.648L1040.63 268.449C1040.33 268.606 1040.02 268.75 1039.7 268.862L1039.68 268.853Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1065.13 252.185L1065.77 253.341L1066.4 254.434L1066.51 254.369C1066.8 254.179 1067.15 254.134 1067.47 254.25L1069.1 254.842C1069.74 255.073 1070.14 255.833 1069.99 256.526L1069.65 258.085C1069.58 258.443 1069.35 258.736 1069.05 258.892C1069.01 258.917 1068.97 258.93 1068.91 258.962L1069.46 260.11L1070.04 261.307C1070.34 261.15 1070.65 261.006 1070.97 260.883L1070.97 260.87C1071.43 260.689 1071.67 260.191 1071.61 259.621C1071.72 259.37 1071.81 259.135 1071.86 258.9L1072.2 257.341C1072.64 255.312 1071.47 253.099 1069.6 252.421L1067.97 251.829C1067.75 251.75 1067.53 251.709 1067.27 251.68C1066.88 251.353 1066.39 251.308 1066 251.555L1065.87 251.546L1065.91 251.6C1065.65 251.814 1065.37 252.008 1065.09 252.185L1065.13 252.185Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1032.6 284.74C1032.98 284.876 1033.37 284.939 1033.76 284.947L1035.01 287.364C1035.18 287.678 1035.43 287.901 1035.72 288.008C1036.02 288.116 1036.33 288.096 1036.59 287.935L1037.86 287.193C1038.11 287.045 1038.3 286.781 1038.37 286.459C1038.44 286.137 1038.39 285.786 1038.23 285.485L1036.96 283.089C1037.16 282.722 1037.33 282.342 1037.42 281.921C1037.93 279.581 1036.58 277.037 1034.43 276.255C1034.04 276.114 1033.64 276.064 1033.24 276.051L1031.79 273.309C1031.46 272.681 1030.75 272.424 1030.21 272.733L1028.94 273.475C1028.67 273.631 1028.49 273.887 1028.42 274.209C1028.35 274.531 1028.4 274.882 1028.57 275.183L1030.03 277.959C1029.85 278.306 1029.68 278.673 1029.6 279.069C1029.09 281.409 1030.44 283.953 1032.59 284.736L1032.6 284.74ZM1033.13 282.313C1032.2 281.978 1031.63 280.887 1031.85 279.885C1032.06 278.882 1032.99 278.338 1033.92 278.673C1034.84 279.009 1035.42 280.099 1035.2 281.102C1034.98 282.105 1034.05 282.649 1033.13 282.313Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1058.8 282.79C1058.94 283.175 1059.24 283.468 1059.59 283.597C1059.73 283.647 1059.87 283.659 1060.02 283.647C1060.25 283.796 1060.47 283.916 1060.69 283.995L1062.13 284.517C1064 285.197 1065.89 284.091 1066.33 282.059L1066.71 280.274C1066.77 280.039 1066.78 279.778 1066.79 279.485C1067.05 279.084 1067.06 278.527 1066.78 278.051L1066.78 277.944L1066.74 277.973C1066.74 277.973 1066.75 277.96 1066.74 277.944C1066.51 277.621 1066.31 277.307 1066.11 276.968L1065.18 277.566L1064.22 278.205C1064.22 278.205 1064.23 278.222 1064.24 278.239L1064.3 278.354C1064.51 278.697 1064.58 279.098 1064.5 279.458L1064.12 281.242C1063.97 281.936 1063.32 282.316 1062.68 282.084L1061.24 281.562C1060.91 281.441 1060.61 281.16 1060.45 280.78L1060.38 280.635L1059.35 281.159L1058.88 281.402L1058.37 281.658C1058.54 282.013 1058.7 282.377 1058.82 282.757C1058.82 282.757 1058.82 282.757 1058.83 282.786L1058.8 282.79Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1049.16 280.747C1048.94 280.495 1048.64 280.333 1048.34 280.304C1048.04 280.275 1047.75 280.382 1047.53 280.596C1047.31 280.811 1047.19 281.129 1047.19 281.463C1047.2 282.668 1047.08 283.866 1046.83 285.029C1045.1 292.991 1037.73 297.301 1030.4 294.639C1023.06 291.976 1018.5 283.336 1020.22 275.374C1021.94 267.413 1029.31 263.103 1036.65 265.765C1037.66 266.133 1038.66 266.63 1039.59 267.233C1040.16 267.602 1040.85 267.408 1041.14 266.806C1041.41 266.199 1041.18 265.419 1040.62 265.055C1039.53 264.352 1038.37 263.773 1037.18 263.342C1028.62 260.233 1020.01 265.268 1017.99 274.567C1015.98 283.865 1021.31 293.96 1029.88 297.07C1038.45 300.179 1047.06 295.144 1049.07 285.845C1049.37 284.495 1049.51 283.092 1049.5 281.684C1049.5 281.338 1049.37 281.011 1049.15 280.743L1049.16 280.747Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1036.53 242.681L1037.31 244.168C1037.47 244.478 1037.73 244.705 1038.02 244.813C1038.32 244.92 1038.63 244.888 1038.89 244.739L1041.25 243.355C1041.58 243.595 1041.93 243.814 1042.29 243.946C1044.45 244.729 1046.62 243.46 1047.13 241.12C1047.22 240.711 1047.24 240.278 1047.21 239.852L1049.27 238.678C1049.8 238.365 1049.97 237.597 1049.64 236.957L1048.86 235.47C1048.53 234.859 1047.8 234.594 1047.28 234.899L1045.24 236.094C1044.89 235.833 1044.53 235.61 1044.14 235.469C1041.99 234.687 1039.82 235.956 1039.31 238.296C1039.22 238.717 1039.21 239.154 1039.24 239.604L1036.9 240.972C1036.36 241.286 1036.19 242.053 1036.52 242.693L1036.53 242.681ZM1043.62 237.896C1044.54 238.231 1045.12 239.322 1044.9 240.325C1044.68 241.328 1043.75 241.871 1042.83 241.536C1041.9 241.201 1041.33 240.11 1041.55 239.107C1041.76 238.105 1042.69 237.561 1043.62 237.896Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1046.82 223.005C1038.26 219.896 1029.65 224.932 1027.63 234.23C1025.62 243.529 1030.95 253.624 1039.52 256.734C1040.77 257.185 1042.05 257.475 1043.31 257.588C1043.94 257.642 1044.46 257.123 1044.45 256.425C1044.45 256.078 1044.33 255.752 1044.1 255.483C1043.89 255.219 1043.59 255.058 1043.29 255.041C1042.2 254.941 1041.11 254.692 1040.04 254.303C1032.7 251.64 1028.13 242.999 1029.86 235.038C1031.58 227.076 1038.95 222.766 1046.29 225.428C1053.62 228.09 1058.19 236.732 1056.47 244.693C1056.23 245.795 1055.87 246.868 1055.41 247.85C1055.28 248.135 1055.26 248.49 1055.35 248.816C1055.45 249.146 1055.66 249.436 1055.92 249.597C1056.19 249.775 1056.5 249.833 1056.8 249.755C1057.1 249.677 1057.33 249.466 1057.46 249.182C1058 248.026 1058.41 246.788 1058.69 245.5C1060.7 236.202 1055.37 226.107 1046.8 222.997L1046.82 223.005Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M483.659 58.983L475.127 54.3953L476.298 51.2181C477.375 48.3026 477.312 44.987 476.141 41.8738C474.969 38.7606 472.813 36.2446 470.085 34.7709C464.448 31.7444 458.051 34.1681 455.828 40.2027L454.657 43.3799L444.029 37.6557C443.474 37.3601 442.833 37.5713 442.563 38.1319L420.896 85.2826C420.755 85.594 420.748 85.9679 420.861 86.3046C420.971 86.6537 421.218 86.9448 421.517 87.1072L468.357 112.327C468.357 112.327 468.46 112.364 468.517 112.385C468.77 112.477 469.044 112.469 469.289 112.369C469.576 112.245 469.793 111.988 469.891 111.647L484.346 60.6166C484.518 59.9935 484.226 59.2827 483.659 58.983ZM423.528 85.4308L444.185 40.4811L453.826 45.6725L451.929 50.8307L450.076 49.8357C449.788 49.6775 449.47 49.6564 449.189 49.7558C448.904 49.8677 448.681 50.096 448.58 50.395C448.345 51.0222 448.635 51.7994 449.233 52.1241L455.314 55.3921C455.314 55.3921 455.415 55.4421 455.472 55.4629C456.023 55.6629 456.6 55.4018 456.813 54.8204C456.929 54.513 456.919 54.1599 456.803 53.8357C456.676 53.5073 456.45 53.237 456.171 53.0954L454.096 51.9797L455.993 46.8215L472.158 55.5223L470.26 60.6805L468.329 59.6439C467.742 59.3234 467.068 59.5761 466.831 60.2157C466.714 60.523 466.725 60.8762 466.84 61.2004C466.967 61.5287 467.194 61.799 467.473 61.9406L473.554 65.2086C473.554 65.2086 473.666 65.2627 473.712 65.2794C473.953 65.3669 474.201 65.363 474.432 65.2719C474.716 65.16 474.939 64.9317 475.041 64.6327C475.276 64.0055 474.986 63.2283 474.387 62.9036L472.39 61.8295L474.287 56.6712L481.821 60.7219L468.044 109.364L423.533 85.4059L423.528 85.4308ZM462.597 36.5163C464.73 35.7042 467.079 35.8978 469.243 37.0593C471.395 38.2167 473.093 40.2169 474.025 42.6651C474.954 45.1257 474.996 47.735 474.148 50.0483L472.977 53.2255L456.812 44.5247L457.983 41.3476C458.828 39.0467 460.475 37.3325 462.597 36.5163Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M793.607 186.473C789.751 185.073 785.864 187.336 784.956 191.533C784.047 195.73 786.448 200.274 790.316 201.677C794.184 203.081 798.058 200.815 798.967 196.617C799.876 192.42 797.475 187.876 793.607 186.473ZM790.954 198.731C788.592 197.874 787.117 195.081 787.671 192.518C788.226 189.955 790.607 188.563 792.969 189.42C795.331 190.277 796.806 193.069 796.252 195.632C795.697 198.195 793.315 199.588 790.954 198.731Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M809.921 159.546L756.815 190.608C756.494 190.785 756.276 191.106 756.191 191.503C756.105 191.899 756.161 192.32 756.365 192.688C756.557 193.051 756.864 193.336 757.229 193.469C757.595 193.601 757.969 193.577 758.282 193.383L811.387 162.322C812.036 161.943 812.239 161.002 811.838 160.242C811.445 159.498 810.555 159.176 809.921 159.546Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M768.626 157.478C767.72 161.663 770.118 166.219 773.986 167.623C777.854 169.026 781.728 166.76 782.637 162.563C783.546 158.365 781.145 153.822 777.277 152.418C773.409 151.015 769.534 153.281 768.626 157.478ZM771.341 158.464C771.896 155.901 774.277 154.508 776.639 155.365C779.001 156.222 780.476 159.014 779.922 161.577C779.367 164.14 776.985 165.533 774.624 164.676C772.262 163.819 770.786 161.027 771.341 158.464Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1094.68 132.684C1094.05 131.178 1092.95 129.968 1091.59 129.301L1036.32 102.259C1033.49 100.874 1030.4 102.216 1029.41 105.25L1015.59 147.718C1014.61 150.74 1016.1 154.327 1018.93 155.712L1037.5 164.804L1035.41 171.218L1033.49 170.282C1032.91 169.989 1032.25 170.268 1032.03 170.91C1031.82 171.551 1032.14 172.304 1032.74 172.601L1054.67 183.337C1054.67 183.337 1054.75 183.366 1054.79 183.378C1055.34 183.581 1055.93 183.301 1056.13 182.693C1056.34 182.052 1056.01 181.295 1055.42 181.002L1053.5 180.066L1055.59 173.653L1074.17 182.745C1074.36 182.84 1074.54 182.918 1074.72 182.984C1075.93 183.421 1077.18 183.398 1078.31 182.902C1079.61 182.336 1080.6 181.218 1081.07 179.754L1094.9 137.287C1095.37 135.823 1095.29 134.182 1094.66 132.676L1094.68 132.684ZM1051.53 178.539L1037.74 171.796L1039.68 165.859L1053.47 172.602L1051.53 178.539ZM1074.95 180.435L1019.69 153.393C1018.9 153.002 1018.26 152.319 1017.9 151.442C1017.54 150.566 1017.49 149.616 1017.77 148.773L1019.93 142.134L1081.11 172.064L1078.95 178.703C1078.67 179.546 1078.11 180.195 1077.35 180.52C1076.59 180.844 1075.74 180.814 1074.96 180.422L1074.95 180.435ZM1035.57 104.594L1090.83 131.636C1091.62 132.027 1092.26 132.711 1092.62 133.587C1092.98 134.463 1093.03 135.413 1092.75 136.256L1081.85 169.754L1020.67 139.823L1031.57 106.326C1031.85 105.483 1032.41 104.834 1033.17 104.51C1033.93 104.186 1034.78 104.215 1035.56 104.607L1035.57 104.594Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M625.647 27.5409C625.084 25.4906 624.951 23.3533 625.243 21.3164L625.993 16.1305L627.831 15.6784C629.944 15.164 631.132 12.7782 630.473 10.3695L627.69 0.209737L628.582 -0.0059522C629.145 -0.138667 629.613 -0.521439 629.884 -1.08356C630.152 -1.63319 630.21 -2.2997 630.038 -2.94145L627.845 -10.9467C627.475 -12.2803 626.231 -13.1356 625.074 -12.8411L624.182 -12.6254L621.758 -21.4558C621.099 -23.8645 618.837 -25.4125 616.724 -24.8981L614.586 -24.3797L611.767 -27.9488C610.47 -29.5916 609.488 -31.5382 608.934 -33.5718L606.831 -41.2478C606.401 -42.8189 604.929 -43.8245 603.551 -43.4885L596.911 -41.8667C596.911 -41.8667 596.791 -41.8293 596.737 -41.8085C596.685 -41.8002 596.622 -41.7961 596.559 -41.792L589.919 -40.1702C588.541 -39.8342 587.77 -38.2811 588.2 -36.71L590.303 -29.034C590.865 -26.9837 590.999 -24.8463 590.707 -22.8095L590.064 -18.4067L588.817 -18.1039C586.705 -17.5895 585.517 -15.2037 586.176 -12.795L594.88 19.0261C595.316 20.6263 596.467 21.8524 597.804 22.3371C598.484 22.5836 599.204 22.6427 599.913 22.4684L600.859 22.232L604.176 26.4266C605.473 28.0694 606.456 30.0159 607.009 32.0495L609.112 39.7256C609.395 40.7716 610.142 41.5681 611.018 41.8857C611.456 42.0444 611.932 42.0824 612.393 41.9663L619.033 40.3444C619.033 40.3444 619.153 40.307 619.195 40.2821C619.247 40.2738 619.31 40.2697 619.376 40.2531L626.016 38.6313C627.393 38.2953 628.165 36.7422 627.735 35.1711L625.632 27.4951L625.647 27.5409ZM593 -22.153C593.348 -24.5606 593.18 -27.1145 592.515 -29.5524L590.413 -37.2284C590.364 -37.4076 590.454 -37.5908 590.611 -37.6282L597.251 -39.25C597.251 -39.25 597.371 -39.2874 597.414 -39.3123C597.465 -39.3206 597.528 -39.3247 597.594 -39.3413L604.234 -40.9632C604.391 -41.0005 604.565 -40.8837 604.613 -40.7045L606.716 -33.0284C607.384 -30.603 608.546 -28.2813 610.088 -26.3341L612.119 -23.7782L592.545 -19.0164L593.006 -22.178L593 -22.153ZM597.104 18.5119L588.4 -13.3092C588.123 -14.326 588.618 -15.3462 589.521 -15.5577L591.45 -16.0305L617.416 -22.3561C618.308 -22.5718 619.274 -21.925 619.548 -20.8957L622.1 -11.5611C622.008 -11.3112 621.995 -11.0196 622.073 -10.7487L624.898 -0.438984C624.973 -0.155612 625.131 0.0903602 625.342 0.261393L628.255 10.9129C628.532 11.9297 628.037 12.9498 627.134 13.1613L599.227 19.9556C598.335 20.1713 597.369 19.5245 597.095 18.4952L597.104 18.5119ZM627.804 -2.49807L627.004 -2.30311L624.874 -10.0834L625.674 -10.2783L627.804 -2.49807ZM618.707 37.7736C618.707 37.7736 618.587 37.811 618.545 37.8359C618.493 37.8442 618.43 37.8483 618.367 37.8524L611.727 39.4743C611.57 39.5116 611.396 39.3948 611.348 39.2156L609.245 31.5395C608.577 29.1142 607.415 26.7924 605.873 24.8453L603.346 21.6514L623.527 16.732L622.958 20.6766C622.61 23.0842 622.778 25.6381 623.443 28.076L625.546 35.7521C625.594 35.9313 625.504 36.1145 625.347 36.1518L618.707 37.7736Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M805.162 30.4251L791.763 28.9131L791.705 31.2378L805.104 32.7498L805.162 30.4251Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M818.171 98.5759C819.078 97.7085 819.591 96.4833 819.619 95.0956L820.934 33.637C820.994 30.7826 818.952 28.2002 816.373 27.8692L778.89 23.047C777.648 22.8919 776.464 23.2687 775.557 24.1362C774.651 25.0036 774.138 26.2287 774.11 27.6165L772.795 89.075C772.77 90.4503 773.219 91.8094 774.085 92.9031C774.715 93.7098 775.517 94.2966 776.39 94.6133C776.7 94.7258 777.03 94.8051 777.356 94.8428L814.839 99.6651C816.081 99.8201 817.265 99.4433 818.171 98.5759ZM775.108 89.3767L775.233 83.4809L817.427 88.9107L817.303 94.8064C817.289 95.5003 817.017 96.1274 816.576 96.559C816.122 96.999 815.521 97.1978 814.897 97.1057L777.415 92.2834C776.115 92.1075 775.084 90.8059 775.111 89.3642L775.108 89.3767ZM818.621 33.3354L818.536 37.4445L776.342 32.0148L776.426 27.9056C776.453 26.4639 777.543 25.4346 778.846 25.5981L816.328 30.4203C817.631 30.5837 818.659 31.8978 818.632 33.3395L818.621 33.3354ZM818.477 40.0039L817.489 86.3388L775.294 80.9091L776.283 34.5742L818.477 40.0039Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M793.595 92.8574C793.895 93.2334 794.267 93.5021 794.678 93.6512C794.826 93.705 794.977 93.7465 795.134 93.7631C796.342 93.9213 797.349 92.9647 797.369 91.6231C797.4 90.2856 796.445 89.071 795.233 88.9252C794.648 88.8462 794.091 89.0313 793.67 89.4396C793.249 89.8478 793.001 90.4254 792.998 91.0653C792.981 91.7133 793.199 92.3534 793.606 92.8616L793.595 92.8574Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1157.75 160.62C1157.83 160.648 1157.91 160.676 1157.99 160.68L1164.57 161.43C1164.87 161.462 1165.15 161.367 1165.37 161.163C1165.59 160.956 1165.71 160.664 1165.71 160.328C1165.72 159.993 1165.6 159.681 1165.39 159.425C1165.18 159.169 1164.91 159.005 1164.6 158.972L1158.02 158.222C1157.4 158.154 1156.89 158.645 1156.89 159.328C1156.88 159.919 1157.26 160.455 1157.76 160.636L1157.75 160.62Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1133.66 182.247C1134.99 183.892 1136.63 185.074 1138.43 185.728C1139.13 185.981 1139.86 186.151 1140.59 186.242C1143.22 186.542 1145.69 185.691 1147.57 183.847C1149.45 181.992 1150.5 179.384 1150.53 176.469C1150.56 173.567 1149.56 170.71 1147.73 168.441C1145.89 166.173 1143.43 164.746 1140.8 164.446C1138.17 164.146 1135.7 164.998 1133.82 166.841C1131.95 168.685 1130.89 171.305 1130.86 174.219C1130.83 177.134 1131.83 179.979 1133.66 182.247ZM1146.09 170.05C1147.49 171.789 1148.26 173.978 1148.24 176.211C1148.21 178.432 1147.4 180.45 1145.97 181.864C1144.53 183.279 1142.62 183.937 1140.61 183.7C1138.59 183.462 1136.71 182.379 1135.3 180.639C1133.9 178.9 1133.13 176.711 1133.15 174.478C1133.2 169.875 1136.63 166.51 1140.78 166.989C1141.34 167.06 1141.9 167.18 1142.43 167.375C1143.81 167.876 1145.07 168.785 1146.09 170.05Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1164.32 163.129C1164.11 162.872 1163.83 162.719 1163.52 162.675L1158.74 162.128C1158.11 162.059 1157.61 162.552 1157.6 163.239C1157.59 163.833 1157.97 164.372 1158.48 164.553C1158.55 164.581 1158.63 164.609 1158.72 164.613L1163.5 165.16C1164.12 165.229 1164.63 164.736 1164.64 164.049C1164.64 163.712 1164.52 163.399 1164.31 163.141L1164.32 163.129Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1169.13 200.512C1170.27 199.398 1170.9 197.811 1170.93 196.056L1171.29 161.542C1171.3 159.782 1170.7 158.051 1169.59 156.68C1168.48 155.309 1166.98 154.45 1165.4 154.26L1156.3 153.216L1152.48 148.504C1151.52 147.305 1150.22 146.557 1148.84 146.4L1141.26 145.526C1141.19 145.514 1141.12 145.514 1141.04 145.526C1140.98 145.502 1140.91 145.477 1140.83 145.477L1133.26 144.603C1131.9 144.442 1130.55 144.908 1129.59 145.859L1125.69 149.685L1116.58 148.642C1113.3 148.261 1110.59 150.916 1110.55 154.562L1110.19 189.076C1110.16 192.222 1112.14 195.087 1114.79 196.049C1115.21 196.201 1115.64 196.304 1116.08 196.358L1164.9 201.951C1166.49 202.129 1168 201.614 1169.13 200.5L1169.13 200.512ZM1150.83 150.093L1153.04 152.831L1128.9 150.066L1131.16 147.85C1131.71 147.317 1132.46 147.059 1133.21 147.146L1140.79 148.02C1140.86 148.032 1140.93 148.032 1141.01 148.02C1141.07 148.045 1141.14 148.069 1141.22 148.069L1148.79 148.943C1149.56 149.038 1150.28 149.445 1150.82 150.118L1150.83 150.093ZM1112.47 189.345L1112.83 154.831C1112.85 152.584 1114.52 150.945 1116.55 151.177L1165.36 156.782C1165.64 156.815 1165.91 156.873 1166.17 156.967C1167.8 157.56 1169.02 159.329 1169.01 161.273L1168.65 195.787C1168.63 198.034 1166.95 199.669 1164.93 199.441L1116.12 193.836C1115.14 193.72 1114.21 193.198 1113.53 192.34C1112.84 191.495 1112.46 190.428 1112.48 189.333L1112.47 189.345Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M708.626 15.677L709.276 16.8204L709.9 17.9143L710.013 17.8484C710.3 17.659 710.654 17.614 710.973 17.7298L712.604 18.3215C713.242 18.5532 713.644 19.3127 713.494 20.0056L713.159 21.5523C713.081 21.9111 712.858 22.2037 712.542 22.356L712.415 22.4302L712.995 23.6148L713.258 24.1637L713.546 24.7622C713.851 24.6057 714.153 24.4617 714.472 24.3506L714.477 24.3259C714.934 24.1449 715.178 23.646 715.114 23.089C715.23 22.8374 715.318 22.6024 715.371 22.3549L715.706 20.8083C716.145 18.7791 714.976 16.5666 713.106 15.8881L711.476 15.2964C711.259 15.2178 711.023 15.1722 710.77 15.1471C710.385 14.8208 709.891 14.7749 709.506 15.022L709.384 15.0178L709.421 15.0715C709.166 15.2857 708.893 15.4669 708.62 15.6481L708.626 15.677Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M687.403 15.2242L687.395 15.2613L687.421 15.2572C687.649 15.5668 687.849 15.8929 688.046 16.2314L689.006 15.6054L689.937 14.9959L689.859 14.8473C689.65 14.5047 689.579 14.0922 689.654 13.7457L689.989 12.1992C690.139 11.5064 690.787 11.1276 691.425 11.3593L693.056 11.9509C693.375 12.0667 693.659 12.3434 693.829 12.6983L693.898 12.8304L694.871 12.3158L695.885 11.7765C695.722 11.4505 695.576 11.1038 695.429 10.7572L695.458 10.7407L695.401 10.72C695.274 10.394 695.07 10.1463 694.795 9.99337C694.607 9.8983 694.428 9.87335 694.229 9.88139C694.003 9.73265 693.783 9.6128 693.578 9.53833L691.948 8.94673C690.078 8.26824 688.191 9.37171 687.752 11.4007L687.417 12.9472C687.366 13.1823 687.347 13.4422 687.345 13.735C687.069 14.1555 687.074 14.7577 687.389 15.2324L687.403 15.2242Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M721.971 10.258C721.583 10.1173 721.188 10.0673 720.785 10.0545L719.528 7.67534C719.205 7.06403 718.463 6.79491 717.942 7.09984L716.674 7.84157C716.138 8.15474 715.972 8.9224 716.301 9.56262L717.578 11.9624C717.392 12.309 717.227 12.6762 717.138 13.0848C716.632 15.425 717.976 17.9693 720.133 18.7519C720.498 18.8844 720.879 18.9426 721.259 18.9471L722.726 21.7228C722.88 22.0326 723.139 22.2599 723.436 22.3676C723.732 22.4752 724.044 22.4549 724.301 22.2942L725.569 21.5524C725.825 21.3917 726.015 21.1401 726.085 20.8182C726.154 20.4963 726.107 20.1453 725.939 19.8438L724.489 17.1011C724.692 16.7339 724.86 16.3543 724.952 15.9333C725.458 13.5932 724.114 11.0488 721.957 10.2663L721.971 10.258ZM721.446 12.6849C722.37 13.0202 722.946 14.1107 722.729 15.1136C722.512 16.1165 721.582 16.6604 720.658 16.3251C719.734 15.9897 719.158 14.8992 719.375 13.8963C719.592 12.8934 720.522 12.3495 721.446 12.6849Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M725.476 -1.92622C716.907 -5.03565 708.298 -0.000112956 706.285 9.29866C706.006 10.5864 705.864 11.9238 705.856 13.2696C705.855 13.6163 705.978 13.955 706.192 14.2194C706.405 14.4838 706.691 14.641 706.993 14.6702C707.294 14.6995 707.585 14.6048 707.807 14.378C708.025 14.1636 708.143 13.8458 708.142 13.5114C708.144 12.3638 708.271 11.208 708.51 10.106C710.233 2.1445 717.603 -2.16579 724.939 0.49648C732.276 3.15875 736.842 11.7999 735.118 19.7614C733.395 27.723 726.025 32.0332 718.689 29.371C717.616 28.9818 716.584 28.4605 715.616 27.8155C715.347 27.6377 715.029 27.5754 714.743 27.6453C714.443 27.7234 714.215 27.9213 714.066 28.2143C713.778 28.8043 713.998 29.6054 714.571 29.9734C715.699 30.7301 716.908 31.3424 718.152 31.7937C726.721 34.9031 735.33 29.8676 737.343 20.5688C739.356 11.27 734.022 1.17494 725.453 -1.93449L725.476 -1.92622Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M715.836 38.4089C714.649 37.9783 713.431 37.6963 712.216 37.5629C711.915 37.5337 711.624 37.6283 711.403 37.8551C711.184 38.0696 711.066 38.3873 711.067 38.7217C711.066 39.0685 711.19 39.4071 711.403 39.6716C711.617 39.936 711.914 40.0973 712.204 40.1224C713.239 40.2308 714.281 40.4755 715.308 40.8481C722.645 43.5104 727.21 52.1514 725.487 60.1128C723.763 68.0743 716.394 72.3845 709.057 69.7223C701.721 67.06 697.155 58.419 698.879 50.4575C699.131 49.2937 699.505 48.1877 699.998 47.1644C700.133 46.8797 700.16 46.5289 700.059 46.1985C699.958 45.8682 699.762 45.5831 699.492 45.4053C699.223 45.2275 698.904 45.1652 698.619 45.2351C698.33 45.3174 698.091 45.5112 697.942 45.8041C697.363 46.9965 696.923 48.2923 696.631 49.6419C694.618 58.9406 699.952 69.0355 708.521 72.1449C717.089 75.2543 725.699 70.2189 727.712 60.9202C729.725 51.6215 724.391 41.5266 715.822 38.4172L715.836 38.4089Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M718.14 53.3138C718.209 52.9919 718.162 52.641 717.994 52.3395L717.208 50.8526C716.876 50.2248 716.169 49.9681 715.622 50.2771L713.283 51.6451C712.934 51.3846 712.576 51.1614 712.188 51.0206C710.032 50.2381 707.862 51.5072 707.355 53.8472C707.264 54.2682 707.255 54.7057 707.281 55.1557L705.238 56.3506C704.984 56.499 704.789 56.7753 704.722 57.0849C704.655 57.3944 704.7 57.7577 704.868 58.0592L705.654 59.5461C705.811 59.8435 706.067 60.0832 706.363 60.1908C706.66 60.2985 706.972 60.2782 707.228 60.1174L709.285 58.9143C709.615 59.154 709.964 59.3608 710.329 59.4933C712.485 60.2758 714.655 59.0067 715.162 56.6667C715.248 56.2705 715.265 55.8494 715.234 55.4242L717.601 54.0398C717.855 53.8914 718.05 53.6151 718.117 53.3055L718.14 53.3138ZM710.877 57.0749C709.953 56.7396 709.377 55.6492 709.594 54.6463C709.811 53.6434 710.741 53.0995 711.665 53.4349C712.589 53.7702 713.166 54.8606 712.948 55.8635C712.731 56.8663 711.801 57.4103 710.877 57.0749Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M684.397 32.5357L684.108 31.9363C683.803 32.093 683.501 32.2373 683.178 32.3609L683.173 32.3857C682.701 32.5752 682.466 33.0915 682.533 33.6369C682.419 33.8764 682.331 34.1118 682.278 34.3597L681.892 36.1441C681.452 38.1764 682.622 40.3922 684.495 41.0718L685.934 41.594C686.151 41.6727 686.387 41.7184 686.64 41.7434C686.764 41.8551 686.893 41.942 687.03 41.9918C687.087 42.0125 687.156 42.0373 687.215 42.0457C687.489 42.0914 687.738 42.0214 687.957 41.8605L688.015 41.8812L688 41.8358C688.002 41.8234 688.028 41.8193 688.042 41.811C688.301 41.5841 688.579 41.3778 688.867 41.188L688.201 40.0511L687.562 38.9638L687.449 39.0298C687.148 39.2278 686.791 39.2853 686.46 39.1651L685.021 38.643C684.381 38.4109 683.979 37.6503 684.13 36.9563L684.516 35.1719C684.594 34.8125 684.817 34.5194 685.134 34.3668L685.26 34.2926L684.971 33.6932L684.709 33.1434L684.42 32.544L684.397 32.5357Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M706.148 45.594L704.709 45.0719C704.378 44.9518 704.082 44.6705 703.918 44.2903L703.839 44.1415L702.857 44.6403L701.832 45.1639C702.002 45.5193 702.157 45.883 702.284 46.2632C702.42 46.66 702.722 46.9701 703.087 47.1027C703.224 47.1524 703.369 47.165 703.52 47.1527C703.746 47.3017 703.966 47.4217 704.195 47.5046L705.633 48.0266C707.506 48.7061 709.395 47.601 709.835 45.569L710.221 43.7848C710.272 43.5494 710.292 43.2891 710.293 42.9958C710.555 42.583 710.565 42.0253 710.284 41.5623L710.28 41.4673L710.249 41.4962C710.249 41.4962 710.24 41.4797 710.231 41.4631C710.014 41.1572 709.823 40.8472 709.634 40.5247C709.634 40.5247 709.616 40.4917 709.605 40.4875L708.675 41.0856L707.712 41.7248L707.793 41.8612C708.002 42.2044 708.075 42.6051 707.997 42.9645L707.611 44.7487C707.461 45.4425 706.813 45.8219 706.173 45.5899L706.148 45.594Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M676.088 48.2477C676.465 48.3843 676.857 48.4466 677.249 48.4553L678.498 50.8715C678.655 51.1689 678.911 51.4085 679.208 51.5162C679.505 51.6238 679.817 51.6035 680.073 51.4428L681.341 50.7011C681.597 50.5404 681.787 50.2888 681.857 49.9669C681.926 49.645 681.879 49.2941 681.711 48.9926L680.445 46.597C680.648 46.2298 680.816 45.8502 680.907 45.4293C681.414 43.0893 680.069 40.545 677.913 39.7625C677.525 39.6218 677.13 39.5718 676.726 39.559L675.277 36.8165C674.946 36.1887 674.238 35.932 673.691 36.241L672.423 36.9827C672.158 37.1269 671.977 37.395 671.908 37.7169C671.838 38.0388 671.885 38.3898 672.054 38.6913L673.52 41.4668C673.334 41.8134 673.169 42.1806 673.083 42.5768C672.576 44.9168 673.921 47.461 676.077 48.2435L676.088 48.2477ZM676.614 45.821C675.69 45.4856 675.113 44.3952 675.331 43.3924C675.548 42.3895 676.478 41.8456 677.402 42.181C678.326 42.5163 678.902 43.6067 678.685 44.6096C678.468 45.6124 677.538 46.1563 676.614 45.821Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M680.011 6.1882L680.797 7.67518C680.965 7.97671 681.21 8.21228 681.507 8.31993C681.803 8.42758 682.115 8.40725 682.371 8.24653L684.739 6.86201C685.068 7.10179 685.415 7.32095 685.78 7.45344C687.936 8.23595 690.106 6.9668 690.613 4.62669C690.701 4.2181 690.721 3.78466 690.69 3.35943L692.753 2.1851C693.289 1.87194 693.455 1.10428 693.126 0.464067L692.34 -1.02291C692.183 -1.32031 691.925 -1.54762 691.628 -1.65526C691.331 -1.76291 691.019 -1.74261 690.766 -1.59426L688.723 -0.399278C688.373 -0.659723 688.015 -0.883031 687.627 -1.0238C685.471 -1.80632 683.301 -0.537157 682.794 1.80296C682.703 2.22393 682.694 2.6615 682.72 3.11149L680.381 4.47955C679.846 4.79272 679.68 5.56037 680.009 6.20058L680.011 6.1882ZM687.102 1.40299C688.026 1.73836 688.602 2.82879 688.385 3.8317C688.168 4.83461 687.238 5.37853 686.314 5.04317C685.39 4.7078 684.813 3.61736 685.031 2.61445C685.248 1.61155 686.178 1.06763 687.102 1.40299Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M690.32 -13.4858C681.751 -16.5952 673.142 -11.5597 671.129 -2.26091C669.116 7.03786 674.449 17.133 683.018 20.2424C684.262 20.6937 685.541 20.984 686.808 21.0969C687.437 21.1512 687.955 20.6316 687.946 19.9339C687.947 19.5871 687.821 19.2609 687.596 18.9923C687.383 18.7278 687.083 18.5789 686.781 18.5497C685.696 18.4495 684.605 18.2006 683.532 17.8114C676.196 15.1491 671.63 6.50799 673.354 -1.45354C675.077 -9.41507 682.446 -13.7254 689.783 -11.0631C697.12 -8.40082 701.685 0.240324 699.962 8.20186C699.723 9.30384 699.368 10.3768 698.909 11.3588C698.774 11.6435 698.747 11.9944 698.848 12.3248C698.949 12.6551 699.145 12.9402 699.415 13.118C699.684 13.2958 700.002 13.3581 700.291 13.2758C700.591 13.1977 700.821 12.9874 700.957 12.7027C701.49 11.5474 701.905 10.3093 702.184 9.02161C704.197 -0.277161 698.863 -10.3722 690.294 -13.4817L690.32 -13.4858Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M692.641 44.2505C692.425 43.9984 692.139 43.8413 691.826 43.8079C691.525 43.7787 691.231 43.8857 691.024 44.1043C690.805 44.3187 690.687 44.6365 690.689 44.9708C690.698 46.1763 690.575 47.3733 690.323 48.5372C688.599 56.4985 681.23 60.8087 673.893 58.1465C666.557 55.4843 661.991 46.8433 663.715 38.882C665.438 30.9206 672.808 26.6105 680.144 29.2727C681.171 29.6453 682.16 30.1376 683.087 30.7413C683.356 30.9191 683.675 30.9814 683.964 30.8991C684.252 30.8168 684.494 30.6107 684.629 30.326C684.908 29.7195 684.671 28.939 684.113 28.5627C683.022 27.8598 681.867 27.2806 680.681 26.85C672.112 23.7407 663.503 28.7761 661.49 38.0746C659.477 47.3732 664.811 57.4681 673.38 60.5774C681.948 63.6868 690.557 58.6514 692.57 49.3528C692.863 48.0032 693.006 46.5998 692.991 45.1921C692.992 44.8453 692.866 44.5191 692.641 44.2505Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1185.22 225.046C1185.38 225.375 1185.65 225.62 1185.96 225.733L1235.01 243.364C1235.32 243.477 1235.65 243.435 1235.92 243.265C1236.18 243.091 1236.37 242.796 1236.42 242.451L1243.8 188.894C1243.89 188.242 1243.5 187.577 1242.92 187.364L1233.99 184.15L1234.72 180.773C1235.37 177.66 1234.88 174.352 1233.32 171.42C1231.77 168.505 1229.36 166.338 1226.51 165.304L1226.47 165.291C1220.56 163.174 1214.64 166.659 1213.28 173.074L1212.54 176.452L1201.42 172.454C1200.83 172.242 1200.24 172.565 1200.06 173.184L1185.13 224.032C1185.03 224.36 1185.08 224.738 1185.23 225.063L1185.22 225.046ZM1215.52 173.874C1216.05 171.431 1217.42 169.442 1219.38 168.272C1221.36 167.106 1223.68 166.913 1225.94 167.735L1225.97 167.743C1228.21 168.556 1230.12 170.27 1231.35 172.574C1232.58 174.89 1232.97 177.504 1232.44 179.96L1231.71 183.338L1214.8 177.256L1215.53 173.878L1215.52 173.874ZM1210.84 184.383L1208.9 183.679C1208.6 183.571 1208.28 183.604 1208.03 183.753C1207.77 183.915 1207.58 184.168 1207.51 184.492C1207.44 184.816 1207.48 185.169 1207.65 185.473C1207.82 185.789 1208.07 186.014 1208.37 186.122L1214.74 188.406C1215.36 188.631 1215.98 188.266 1216.13 187.593C1216.28 186.92 1215.89 186.188 1215.27 185.963L1213.1 185.175L1214.27 179.699L1231.19 185.785L1230 191.269L1228.01 190.544C1227.39 190.319 1226.76 190.684 1226.62 191.357C1226.47 192.03 1226.86 192.762 1227.48 192.987L1233.85 195.271C1234.15 195.38 1234.46 195.359 1234.72 195.197C1234.98 195.036 1235.17 194.782 1235.24 194.458C1235.38 193.785 1235 193.053 1234.38 192.828L1232.27 192.066L1233.45 186.589L1241.33 189.424L1234.29 240.471L1187.69 223.723L1201.91 175.256L1212 178.891L1210.82 184.375L1210.84 184.383Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M910.401 91.8382L900.711 87.0802C900.425 86.9379 900.111 86.9294 899.843 87.0428C899.575 87.1561 899.365 87.3953 899.262 87.6995C899.16 88.0038 899.181 88.3528 899.309 88.6613C899.436 88.9698 899.672 89.2257 899.957 89.368L909.647 94.126C909.746 94.1748 909.834 94.2723 909.883 94.3819C909.933 94.4915 909.94 94.6254 909.905 94.7309L907.937 100.702C907.864 100.925 907.632 101.038 907.415 100.921L905.899 100.176C904.382 99.4321 902.716 99.8808 901.831 101.268L890.645 118.692C890.238 119.333 889.464 119.539 888.772 119.198L853.974 102.134C853.282 101.792 852.836 100.988 852.902 100.185L854.731 78.2016C854.874 76.4812 853.937 74.7516 852.458 74.0075L852.074 73.8163C851.865 73.7147 851.755 73.4386 851.827 73.2155L853.801 67.2201C853.836 67.1146 853.916 67.0255 854.011 66.9809C854.106 66.9364 854.213 66.9487 854.326 66.9894L863.84 71.6579C864.126 71.8002 864.44 71.8086 864.708 71.6953C864.976 71.582 865.186 71.3428 865.288 71.0385C865.499 70.4057 865.187 69.6628 864.594 69.37L855.079 64.7015C853.695 64.0184 852.155 64.67 851.661 66.1587L849.687 72.1541C849.198 73.6185 849.922 75.3763 851.289 76.0798L851.673 76.2709C852.187 76.5352 852.518 77.1402 852.472 77.7407L850.643 99.7241C850.477 101.66 851.54 103.592 853.223 104.41L888.021 121.473C888.154 121.534 888.287 121.595 888.422 121.644C889.989 122.21 891.637 121.676 892.54 120.269L903.725 102.844C904.036 102.366 904.617 102.208 905.157 102.468L906.673 103.212C908.056 103.896 909.597 103.244 910.091 101.755L912.059 95.7842C912.553 94.2954 911.818 92.5335 910.423 91.8463L910.401 91.8382Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M883.081 98.0161C882.791 97.83 882.472 97.7706 882.177 97.842C881.878 97.9262 881.631 98.1244 881.488 98.4282L876.812 108.089C876.672 108.38 876.645 108.739 876.749 109.077C876.853 109.415 877.057 109.706 877.347 109.893L877.483 109.969C877.483 109.969 877.566 109.998 877.601 110.011C878.133 110.202 878.691 109.978 878.931 109.464L883.606 99.8028C883.747 99.5116 883.774 99.1527 883.67 98.8148C883.566 98.4769 883.362 98.1853 883.084 98.0034L883.081 98.0161Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M871.801 92.6076C871.485 92.4966 871.163 92.5345 870.878 92.696C870.605 92.8618 870.413 93.1384 870.351 93.4747L868.146 104.461C868.018 105.091 868.363 105.777 868.943 106.05L869.052 106.089L869.089 106.102C869.747 106.319 870.398 105.928 870.539 105.235L872.744 94.2478C872.818 93.9157 872.756 93.5495 872.577 93.2385C872.397 92.9275 872.119 92.7058 871.804 92.5948L871.801 92.6076Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M866.461 89.9923C866.143 89.907 865.817 89.9704 865.568 90.157C865.308 90.3394 865.138 90.6366 865.1 90.9806L863.545 103.086C863.463 103.689 863.803 104.318 864.343 104.577L864.523 104.641L864.583 104.663C864.901 104.748 865.227 104.684 865.476 104.498C865.737 104.315 865.906 104.018 865.944 103.674L867.499 91.5694C867.589 90.8728 867.125 90.1587 866.473 89.9966L866.461 89.9923Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M876.397 95.141C876.112 95.2595 875.888 95.5097 875.779 95.8278L872.287 106.243C872.063 106.904 872.395 107.681 873.025 107.988C873.073 108.005 873.109 108.017 873.145 108.03C873.732 108.239 874.352 107.951 874.555 107.323L878.048 96.9081C878.272 96.2463 877.939 95.4694 877.309 95.1632C877.006 95.0143 876.672 95.0055 876.387 95.124L876.397 95.141Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M892.102 84.0178C892.102 84.0178 892.18 84.0449 892.224 84.0604C892.768 84.2504 893.342 83.9881 893.528 83.4279C893.629 83.1381 893.608 82.8058 893.483 82.5119C893.357 82.218 893.125 81.9743 892.844 81.8387L873.6 72.7056C873.319 72.57 873.009 72.562 872.746 72.6699C872.482 72.7779 872.275 73.0057 872.174 73.2954C871.966 73.8981 872.274 74.6057 872.858 74.8846L892.102 84.0178Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M891.789 97.0351C892.332 97.2243 892.906 96.9632 893.092 96.4052C893.193 96.1167 893.172 95.7856 893.046 95.4929C892.921 95.2003 892.689 94.9576 892.408 94.8226L867.501 83.0535C867.22 82.9185 866.911 82.9104 866.648 83.0179C866.384 83.1254 866.177 83.3523 866.076 83.6409C865.975 83.9295 865.996 84.2605 866.122 84.5532C866.247 84.8459 866.479 85.0886 866.76 85.2236L891.664 97.0042C891.664 97.0042 891.742 97.0313 891.775 97.0428L891.789 97.0351Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M865.275 72.1778C864.682 71.8851 864.038 72.1643 863.827 72.7968C863.617 73.4294 863.929 74.172 864.522 74.4646L870.563 77.432C870.563 77.432 870.642 77.4605 870.687 77.4768C870.935 77.5663 871.204 77.5585 871.433 77.4573C871.701 77.344 871.911 77.1049 872.013 76.8008C872.116 76.4967 872.095 76.1479 871.967 75.8395C871.84 75.5311 871.604 75.2753 871.319 75.133L869.549 74.2712L870.561 71.1856C873.085 63.5546 880.94 60.1963 888.093 63.6962C891.554 65.3913 894.334 68.4282 895.923 72.2427C897.512 76.0572 897.717 80.1987 896.499 83.8926L895.487 86.9782L893.268 85.8888C892.983 85.7466 892.669 85.7381 892.401 85.8514C892.133 85.9647 891.923 86.2038 891.821 86.5079C891.718 86.812 891.739 87.1608 891.867 87.4693C891.994 87.7777 892.23 88.0335 892.515 88.1757L898.567 91.1472C898.567 91.1472 898.646 91.1756 898.68 91.1878C899.233 91.3872 899.815 91.112 900.007 90.5119C900.217 89.8794 899.905 89.1367 899.312 88.8441L897.621 88.0108L898.633 84.9251C901.565 76.0371 897.176 65.4784 888.849 61.3972C880.522 57.316 871.355 61.2245 868.424 70.1125L867.412 73.1981L865.269 72.1494L865.275 72.1778Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M888.29 100.359C887.723 99.9376 887.012 100.063 886.672 100.636L880.932 110.575C880.769 110.857 880.718 111.207 880.795 111.548C880.873 111.889 881.061 112.189 881.332 112.395L881.556 112.53C881.556 112.53 881.638 112.56 881.673 112.573C882.166 112.75 882.687 112.569 882.953 112.106L888.693 102.167C888.856 101.885 888.907 101.535 888.829 101.194C888.752 100.853 888.564 100.553 888.293 100.347L888.29 100.359Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M988.509 105.516C986.696 105.279 986.827 102.142 988.628 102.374C990.44 102.611 990.31 105.748 988.509 105.516ZM988.509 105.516C990.31 105.748 990.443 102.598 988.628 102.374C986.827 102.142 986.694 105.292 988.509 105.516ZM992.476 108.874L992.954 96.6881C992.969 96.3414 992.732 96.0269 992.422 95.9848L944.44 89.801C944.13 89.7589 943.867 90.0044 943.852 90.3511L943.374 102.537C943.359 102.884 943.596 103.198 943.905 103.24L961.236 105.473C961.545 105.515 961.808 105.27 961.823 104.923C961.839 104.576 961.602 104.262 961.292 104.22L944.522 102.063L944.943 91.131L991.806 97.1616L991.385 108.094L973.447 105.781C973.137 105.739 972.874 105.985 972.859 106.331C972.844 106.678 973.081 106.992 973.39 107.035L991.891 109.411C992.2 109.454 992.463 109.208 992.479 108.861L992.476 108.874ZM985.969 152.221L987.64 109.218C987.655 108.871 987.418 108.556 987.109 108.514C986.799 108.472 986.536 108.718 986.521 109.064L984.878 151.441L947.616 146.649L949.258 104.272C949.274 103.925 949.037 103.611 948.727 103.569C948.418 103.527 948.155 103.772 948.139 104.119L946.468 147.122C946.453 147.469 946.69 147.783 946.999 147.825L985.381 152.771C985.69 152.813 985.953 152.568 985.969 152.221ZM972.279 150.223L974.437 94.5495C974.453 94.2027 974.216 93.8883 973.906 93.8462L961.967 92.3068C961.658 92.2647 961.395 92.5101 961.379 92.8569L959.221 148.53C959.206 148.877 959.443 149.192 959.752 149.234L971.691 150.773C972.001 150.815 972.264 150.57 972.279 150.223ZM962.47 93.6368L973.287 95.0355L971.174 149.452L960.357 148.053L962.47 93.6368ZM967.746 93.3545C968.05 93.3674 968.296 93.0888 968.286 92.7465C968.06 86.2314 965.728 83.4125 963.815 82.1918C961.298 80.5945 958.447 81.0598 956.862 82.1776C953.602 84.4893 957.085 91.198 957.231 91.4802C957.394 91.7955 957.738 91.904 958.005 91.7545C958.274 91.5926 958.346 91.2117 958.194 90.9004C958.159 90.834 955.146 84.9421 957.506 83.2594C958.861 82.2906 961.296 81.9892 963.317 83.2753C964.963 84.3197 966.964 86.8044 967.167 92.7019C967.18 93.0316 967.411 93.3168 967.698 93.3509C967.709 93.3549 967.732 93.363 967.744 93.367L967.746 93.3545ZM969.587 93.0185C970.242 87.2357 972.416 85.284 974.122 84.67C976.217 83.9092 978.6 84.8359 979.869 86.1397C982.08 88.4006 978.637 93.4787 978.603 93.5209C978.422 93.782 978.467 94.1907 978.723 94.4172C978.969 94.6396 979.329 94.6185 979.51 94.3573C979.673 94.1173 983.647 88.3603 980.598 85.233C979.117 83.7189 976.341 82.5172 973.717 83.4557C971.73 84.1734 969.208 86.3675 968.468 92.7568C968.429 93.0955 968.649 93.431 968.954 93.4982C968.965 93.5022 968.988 93.5103 968.999 93.5143C969.286 93.5484 969.54 93.3406 969.576 93.0145L969.587 93.0185ZM961.108 127.93L961.464 118.79C961.479 118.443 961.242 118.129 960.933 118.087L948.252 116.46C947.943 116.418 947.68 116.664 947.665 117.01L947.309 126.151C947.293 126.498 947.531 126.812 947.84 126.854L960.52 128.48C960.83 128.522 961.093 128.277 961.108 127.93ZM948.755 117.79L960.314 119.276L960.003 127.159L948.445 125.673L948.755 117.79ZM986.775 131.237L987.131 122.097C987.147 121.75 986.909 121.436 986.6 121.394L973.181 119.668C972.872 119.626 972.609 119.871 972.593 120.218L972.238 129.358C972.222 129.705 972.459 130.02 972.769 130.062L986.188 131.787C986.497 131.83 986.76 131.584 986.775 131.237ZM973.695 121.002L985.992 122.587L985.682 130.47L973.385 128.885L973.695 121.002ZM993.033 108.963L993.511 96.7773C993.541 96.0838 993.056 95.4509 992.434 95.3793L944.451 89.1954C943.832 89.1112 943.304 89.6147 943.284 90.3122L942.806 102.498C942.775 103.192 943.261 103.824 943.883 103.896L961.213 106.129C961.832 106.213 962.361 105.709 962.38 105.012C962.411 104.318 961.926 103.686 961.304 103.614L945.095 101.522L945.471 91.8468L991.213 97.7368L990.837 107.412L973.458 105.176C972.839 105.091 972.31 105.595 972.291 106.292C972.26 106.986 972.746 107.619 973.368 107.69L991.868 110.067C992.487 110.151 993.016 109.648 993.035 108.951L993.033 108.963ZM991.351 108.746C991.661 108.788 991.924 108.543 991.939 108.196L992.36 97.2633C992.376 96.9166 992.139 96.6022 991.829 96.5601L944.966 90.5294C944.656 90.4873 944.393 90.7327 944.378 91.0795L943.956 102.012C943.941 102.359 944.178 102.673 944.488 102.715L943.928 102.639L944.406 90.4528L992.389 96.6367L991.911 108.822L973.41 106.446L991.348 108.758L991.351 108.746ZM986.537 152.314L988.208 109.311C988.239 108.617 987.754 107.984 987.132 107.913C986.512 107.829 985.984 108.332 985.964 109.03L984.35 150.779L948.209 146.128L949.824 104.378C949.855 103.684 949.369 103.052 948.747 102.98C948.128 102.896 947.599 103.399 947.58 104.097L945.909 147.1C945.878 147.793 946.363 148.426 946.985 148.498L985.367 153.443C985.986 153.528 986.515 153.024 986.534 152.327L986.537 152.314ZM947.593 147.305L984.855 152.097C985.165 152.139 985.428 151.893 985.443 151.547L987.086 109.17L985.415 152.173L947.033 147.228L947.062 146.601C947.046 146.948 947.283 147.262 947.593 147.305ZM972.847 150.316L975.006 94.6426C975.036 93.9491 974.551 93.3163 973.929 93.2446L961.99 91.7053C961.371 91.6211 960.842 92.1245 960.823 92.822L958.664 148.495C958.634 149.189 959.119 149.822 959.741 149.893L971.68 151.433C972.299 151.517 972.828 151.014 972.847 150.316ZM960.346 148.713L971.163 150.111C971.472 150.154 971.735 149.908 971.751 149.561L973.864 95.1453C973.879 94.7985 973.642 94.4841 973.333 94.442L973.892 94.5186L971.734 150.192L959.795 148.653L959.823 148.026C959.808 148.373 960.045 148.687 960.355 148.729L960.346 148.713ZM963.019 94.3732L972.716 95.6188L970.649 148.777L960.951 147.532L963.019 94.3732ZM962.504 93.0393C962.195 92.9972 961.932 93.2426 961.916 93.5893L961.945 92.9627L962.504 93.0393ZM967.783 94.0179C968.087 94.0308 968.359 93.9106 968.571 93.6741C968.769 93.4462 968.875 93.1317 968.865 92.7895C968.624 85.9572 966.132 82.9732 964.079 81.6624C961.348 79.9216 958.265 80.4399 956.559 81.6636C952.875 84.2854 956.612 91.5045 956.778 91.8073C957.108 92.4253 957.802 92.6715 958.328 92.3435C958.583 92.19 958.763 91.9289 958.836 91.6023C958.908 91.2757 958.861 90.9339 958.704 90.6478C957.973 89.2371 956.267 84.9741 957.866 83.8479C959.089 82.981 961.282 82.7159 963.101 83.8625C964.607 84.8168 966.438 87.1324 966.636 92.7168C966.662 93.3762 967.127 93.9341 967.71 94.0188C967.721 94.0228 967.792 94.0345 967.806 94.026L967.783 94.0179ZM967.744 92.7574C967.57 87.7782 966.133 85.0735 964.661 83.6303C966.141 85.0901 967.57 87.7782 967.755 92.7614L967.744 92.7574ZM963.47 82.693C961.372 81.4203 958.884 81.6891 957.387 82.6346C958.329 82.0342 959.682 81.6876 961.113 81.8703C961.889 81.9693 962.702 82.2306 963.468 82.7055L963.47 82.693ZM970.167 93.17C970.792 87.6882 972.791 85.8639 974.35 85.306C976.243 84.6229 978.39 85.4523 979.539 86.6323C981.04 88.167 979.013 91.9458 978.181 93.1545C977.806 93.6852 977.912 94.4815 978.411 94.9429C978.91 95.4044 979.611 95.3415 979.986 94.8107C981.653 92.4352 983.731 87.6452 980.982 84.8274C979.382 83.1895 976.37 81.8905 973.532 82.9027C971.401 83.6639 968.703 85.9854 967.931 92.6883C967.895 93.0144 967.968 93.3517 968.162 93.6374C968.345 93.9191 968.61 94.1079 968.903 94.1711C968.925 94.1791 968.985 94.1868 969.008 94.1948C969.593 94.2669 970.096 93.8223 970.176 93.1866L970.167 93.17ZM974.114 84.0438C976.334 83.3274 978.657 84.2465 980.025 85.4906C979.127 84.6707 977.821 84.0313 976.438 83.8522C975.674 83.7572 974.879 83.8005 974.114 84.0438ZM961.699 128.031L962.055 118.891C962.086 118.198 961.6 117.565 960.978 117.493L948.298 115.867C947.679 115.783 947.15 116.286 947.131 116.984L946.775 126.124C946.744 126.818 947.23 127.45 947.852 127.522L960.532 129.148C961.151 129.232 961.68 128.729 961.699 128.031ZM948.459 126.329L960.018 127.814C960.327 127.856 960.59 127.611 960.606 127.264L960.916 119.381C960.931 119.034 960.694 118.72 960.385 118.678L960.944 118.755L960.589 127.895L947.908 126.269L947.937 125.642C947.921 125.989 948.158 126.303 948.468 126.345L948.459 126.329ZM949.329 118.522L959.766 119.867L959.512 126.497L949.076 125.152L949.329 118.522ZM948.815 117.188C948.505 117.146 948.243 117.392 948.227 117.738L948.255 117.112L948.815 117.188ZM987.378 131.343L987.733 122.202C987.764 121.509 987.279 120.876 986.657 120.804L973.238 119.079C972.619 118.994 972.09 119.498 972.071 120.195L971.715 129.336C971.684 130.029 972.17 130.662 972.792 130.734L986.21 132.459C986.83 132.544 987.358 132.04 987.378 131.343ZM973.4 129.54L985.696 131.125C986.006 131.168 986.269 130.922 986.284 130.575L986.594 122.692C986.61 122.346 986.373 122.031 986.063 121.989L986.623 122.066L986.267 131.206L972.848 129.48L972.877 128.854C972.861 129.2 973.098 129.515 973.408 129.557L973.4 129.54ZM974.269 121.734L985.433 123.174L985.179 129.804L974.016 128.364L974.269 121.734ZM973.755 120.4C973.445 120.358 973.183 120.603 973.167 120.95L973.195 120.323L973.755 120.4Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M664.366 106.898L664.454 101.708C664.538 97.087 662.476 92.749 659.085 90.3957L655.411 87.8379L659.683 87.8924C663.623 87.9489 667.307 85.4996 669.283 81.5009L671.507 77.0131L671.418 82.2029C671.335 86.8239 673.397 91.1619 676.788 93.5152L680.462 96.073L676.19 96.0185C672.25 95.962 668.566 98.4113 666.59 102.41L664.366 106.898ZM662.653 90.2187C664.573 92.3669 665.89 95.1519 666.447 98.1879C668.268 95.9334 670.635 94.3735 673.231 93.6958C671.31 91.5476 669.993 88.7626 669.426 85.723C667.605 87.9775 665.238 89.5374 662.653 90.2187Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M350.986 -1.85509L351.075 -7.04492C351.158 -11.6659 349.096 -16.0039 345.705 -18.3572L342.031 -20.915L346.303 -20.8605C350.243 -20.804 353.927 -23.2533 355.903 -27.252L358.127 -31.7399L358.039 -26.55C357.955 -21.9291 360.017 -17.591 363.408 -15.2378L367.082 -12.6799L362.81 -12.7345C358.87 -12.7909 355.186 -10.3416 353.21 -6.34298L350.986 -1.85509ZM349.273 -18.5342C351.194 -16.386 352.511 -13.601 353.067 -10.565C354.888 -12.8195 357.255 -14.3794 359.84 -15.0607C357.92 -17.2089 356.602 -19.9939 356.046 -23.0299C354.225 -20.7754 351.858 -19.2155 349.273 -18.5342Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1075.85 109.198L1075.94 104.008C1076.02 99.3868 1073.96 95.0488 1070.57 92.6955L1066.89 90.1377L1071.16 90.1922C1075.1 90.2487 1078.79 87.7994 1080.76 83.8007L1082.99 79.3129L1082.9 84.5027C1082.82 89.1237 1084.88 93.4617 1088.27 95.815L1091.94 98.3728L1087.67 98.3183C1083.73 98.2619 1080.05 100.711 1078.07 104.71L1075.85 109.198ZM1074.13 92.5185C1076.05 94.6668 1077.37 97.4517 1077.93 100.488C1079.75 98.2332 1082.12 96.6733 1084.7 95.992C1082.78 93.8438 1081.46 91.0588 1080.91 88.0228C1079.09 90.2773 1076.72 91.8372 1074.13 92.5185Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M860.102 49.5092L860.191 44.3194C860.274 39.6984 858.212 35.3604 854.821 33.0071L851.147 30.4492L855.42 30.5038C859.359 30.5602 863.043 28.1109 865.019 24.1123L867.243 19.6244L867.155 24.8142C867.071 29.4352 869.133 33.7732 872.524 36.1265L876.198 38.6844L871.926 38.6298C867.986 38.5734 864.302 41.0226 862.326 45.0213L860.102 49.5092ZM858.39 32.83C860.31 34.9783 861.627 37.7632 862.183 40.7992C864.004 38.5448 866.371 36.9848 868.956 36.3035C867.036 34.1553 865.719 31.3704 865.162 28.3343C863.341 30.5888 860.974 32.1488 858.39 32.83Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1085.93 223.949L1086.02 218.759C1086.1 214.138 1084.04 209.8 1080.65 207.447L1076.97 204.889L1081.24 204.943C1085.18 205 1088.87 202.55 1090.84 198.552L1093.07 194.064L1092.98 199.254C1092.9 203.875 1094.96 208.213 1098.35 210.566L1102.02 213.124L1097.75 213.069C1093.81 213.013 1090.13 215.462 1088.15 219.461L1085.93 223.949ZM1084.2 207.266C1086.12 209.414 1087.44 212.199 1088 215.235C1089.82 212.981 1092.19 211.421 1094.77 210.739C1092.85 208.591 1091.53 205.806 1090.98 202.77C1089.16 205.025 1086.79 206.585 1084.2 207.266Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M918.64 182.999C915.206 181.87 913.182 177.67 914.147 173.631C915.112 169.592 918.691 167.233 922.136 168.366C925.581 169.498 927.594 173.695 926.629 177.734C925.664 181.773 922.085 184.131 918.64 182.999ZM921.517 170.96C919.293 170.229 916.968 171.761 916.345 174.367C915.723 176.974 917.019 179.696 919.253 180.431C921.488 181.165 923.798 179.643 924.424 177.023C925.05 174.404 923.751 171.694 921.517 170.96Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M747.014 107.696C743.58 106.567 741.556 102.367 742.521 98.3281C743.486 94.2892 747.065 91.9307 750.51 93.0633C753.955 94.1958 755.968 98.3923 755.003 102.431C754.038 106.47 750.459 108.828 747.014 107.696ZM749.891 95.6569C747.667 94.926 745.342 96.4581 744.719 99.0646C744.097 101.671 745.393 104.394 747.627 105.128C749.862 105.863 752.176 104.327 752.798 101.72C753.421 99.1139 752.114 96.3878 749.891 95.6569Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1198.34 150.148C1194.91 149.019 1192.89 144.819 1193.85 140.78C1194.82 136.741 1198.4 134.383 1201.84 135.515C1205.29 136.648 1207.3 140.844 1206.33 144.883C1205.37 148.922 1201.79 151.281 1198.34 150.148ZM1201.22 138.109C1199 137.378 1196.67 138.91 1196.05 141.517C1195.43 144.123 1196.72 146.846 1198.96 147.58C1201.19 148.315 1203.51 146.779 1204.13 144.173C1204.75 141.566 1203.45 138.844 1201.22 138.109Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1211.27 272.834C1207.83 271.705 1205.81 267.505 1206.77 263.466C1207.74 259.427 1211.32 257.068 1214.76 258.201C1218.21 259.333 1220.22 263.53 1219.25 267.569C1218.29 271.608 1214.71 273.966 1211.27 272.834ZM1214.14 260.795C1211.92 260.064 1209.59 261.596 1208.97 264.202C1208.35 266.809 1209.64 269.531 1211.88 270.266C1214.11 271 1216.43 269.465 1217.05 266.858C1217.67 264.252 1216.38 261.529 1214.14 260.795Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M492.23 23.3395C488.796 22.2106 486.773 18.0105 487.738 13.9716C488.703 9.93279 492.282 7.57431 495.727 8.70681C499.172 9.83932 501.185 14.0359 500.22 18.0747C499.255 22.1135 495.676 24.472 492.23 23.3395ZM495.107 11.3004C492.884 10.5696 490.559 12.1016 489.936 14.7082C489.313 17.3147 490.61 20.0372 492.844 20.7717C495.078 21.5062 497.389 19.9834 498.015 17.364C498.641 14.7445 497.331 12.0313 495.107 11.3004Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M582.487 55.0531L580.614 56.2607L589.094 73.7969L590.966 72.5892L582.487 55.0531Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M592.581 58.3585L577.798 67.9805L579.001 70.4911L593.784 60.8691L592.581 58.3585Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M932.916 49.1556L931.044 50.3633L939.523 67.8994L941.396 66.6918L932.916 49.1556Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M943.01 52.461L928.228 62.083L929.43 64.5936L944.213 54.9716L943.01 52.461Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1152.81 229.313L1150.94 230.521L1159.42 248.057L1161.29 246.849L1152.81 229.313Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1162.9 232.572L1148.12 242.194L1149.32 244.705L1164.1 235.083L1162.9 232.572Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M423.871 -13.0054L421.463 -13.8301L417.069 5.32112L419.478 6.14578L423.871 -13.0054Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M428.99 -2.2022L412.492 -7.83203L411.951 -5.48272L428.449 0.147106L428.99 -2.2022Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M832.045 117.001L829.637 116.177L825.243 135.328L827.652 136.153L832.045 117.001Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M837.164 127.805L820.666 122.175L820.125 124.524L836.623 130.154L837.164 127.805Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1003 181.547L1000.59 180.723L996.199 199.874L998.608 200.699L1003 181.547Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1008.12 192.351L991.622 186.721L991.081 189.07L1007.58 194.7L1008.12 192.351Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1151.78 90.5893L1149.38 89.7646L1144.98 108.916L1147.39 109.741L1151.78 90.5893Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    }),
                    /*#__PURE__*/ _jsx("path", {
                        d: "M1156.9 101.393L1140.41 95.7627L1139.86 98.112L1156.36 103.742L1156.9 101.393Z",
                        fill: theme.palette.primary.main,
                        fillOpacity: "0.1"
                    })
                ]
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (HeroBgSvg)));


/***/ }),

/***/ 23254:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(57987);
/* harmony import */ var styled_components_CustomButtons_style__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(81029);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45269);
/* harmony import */ var utils_CommonValues__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(65401);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(58861);
/* harmony import */ var _DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(40116);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(28332);
/* harmony import */ var _assets_delivery_man_svg__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(55851);
/* harmony import */ var _assets_seller_svg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(51229);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var redux_slices_storeRegistrationData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(25189);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_4__]);
react_i18next__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];















const ImageContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Box)(({ theme  })=>({
        position: "relative",
        width: "175px",
        height: "175px",
        [theme.breakpoints.down("md")]: {
            width: "110px",
            height: "110px"
        },
        [theme.breakpoints.down("sm")]: {
            width: "95px",
            height: "95px"
        }
    }));
const TopText = ({ data  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const primary = theme.palette.primary.main;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
        alignItems: "center",
        justifyContent: "center",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                sx: {
                    opacity: ".9"
                },
                textAlign: "center",
                variant: isSmall ? "h7" : "h4",
                lineHeight: {
                    xs: "31px",
                    sm: "45px",
                    md: "57px"
                },
                component: "h2",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                    theme: theme,
                    text: data?.earning_title
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                textAlign: "center",
                fontSize: {
                    xs: "12px",
                    sm: "16px",
                    md: "18px"
                },
                lineHeight: {
                    xs: "15px",
                    sm: "24px",
                    md: "39px"
                },
                sx: {
                    color: "text.secondary",
                    width: "70%"
                },
                children: t(data?.earning_sub_title)
            })
        ]
    });
};
const Card = ({ headingText , subtitleText , buttonText , redirectLink , image , isSmall  })=>{
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_13__.useDispatch)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const redirectHandler = ()=>{
        dispatch((0,redux_slices_storeRegistrationData__WEBPACK_IMPORTED_MODULE_14__/* .setAllData */ .k6)(null));
        router.push({
            pathname: redirectLink,
            query: {
                active: "active"
            }
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomBoxFullWidth */ .uu, {
        sx: {
            padding: {
                xs: "15px 10px",
                sm: "25px 40px",
                md: "30px"
            },
            borderRadius: "10px",
            height: "100%",
            background: (theme)=>theme.palette.background.default,
            boxShadow: "0px 23px 40px rgba(3, 157, 85, 0.05)",
            "&:hover": {
                img: {
                    transform: "scale(1.04)"
                }
            }
        },
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            container: true,
            spacing: {
                xs: 0,
                sm: 0.5,
                md: 2
            },
            alignItems: "center",
            justifyContent: "center",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 4,
                    sm: 4,
                    md: 4,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImageContainer, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
                            height: "100%",
                            width: {
                                xs: "100%",
                                sm: "100%",
                                md: "70%"
                            },
                            src: image.src,
                            alt: t("Delivery man"),
                            objectFit: "cover"
                        })
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 5,
                    sm: 5,
                    md: 5.5,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        alignItems: "flex-start",
                        justifyContent: "flex-start",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                textAlign: "flex-start",
                                fontWeight: "700",
                                lineHeight: {
                                    xs: "18px",
                                    sm: "24px",
                                    md: "33px"
                                },
                                fontSize: {
                                    xs: "14px",
                                    sm: "18px",
                                    md: "26px"
                                },
                                component: "h3",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    theme: theme,
                                    text: headingText ? headingText : ""
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                variant: isSmall ? "body3" : "body1",
                                mt: "10px",
                                color: "text.secondary",
                                textAlign: "flex-start",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {
                                    theme: theme,
                                    text: subtitleText ? subtitleText : ""
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
                    item: true,
                    xs: 3,
                    sm: 3,
                    md: 2.5,
                    align: "end",
                    children: buttonText && redirectLink && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomButtons_style__WEBPACK_IMPORTED_MODULE_5__/* .CustomButtonPrimary */ .TG, {
                        onClick: redirectHandler,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                            variant: isSmall ? "body3" : "body1",
                            fontWeight: "bold",
                            color: "whiteContainer.main,",
                            children: buttonText ? buttonText : ""
                        })
                    })
                })
            ]
        })
    });
};
const CenterCards = ({ data , isSmall  })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
        direction: {
            xs: "column",
            md: "row"
        },
        spacing: {
            xs: 3,
            md: 4
        },
        justifyContent: "space-between",
        alignItems: "stretch",
        children: [
            data?.earning_seller_status ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Card, {
                image: _assets_seller_svg__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z,
                headingText: data?.earning_seller_title,
                subtitleText: data?.earning_seller_sub_title,
                buttonText: data?.earning_seller_button_name,
                redirectLink: "store-registration",
                isSmall: isSmall
            }) : null,
            data?.earning_dm_status ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Card, {
                image: _assets_delivery_man_svg__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z,
                headingText: data?.earning_dm_title,
                subtitleText: data?.earning_dm_sub_title,
                buttonText: data?.earning_dm_button_name,
                redirectLink: "deliveryman-registration",
                isSmall: isSmall
            }) : null
        ]
    });
};
const Registration = ({ data , isSmall , configData  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomStackFullWidth */ .Xw, {
            py: {
                xs: "1.125rem",
                md: "3rem"
            },
            spacing: (0,utils_CommonValues__WEBPACK_IMPORTED_MODULE_7__/* .IsSmallScreen */ .R)() ? 2.5 : 5,
            height: "100%",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(TopText, {
                    data: data
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CenterCards, {
                    data: data,
                    isSmall: isSmall
                })
            ]
        })
    });
};
Registration.propTypes = {};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (Registration)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 72778:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



const SolutionSvg = (props)=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: "100%",
        height: "100%",
        viewBox: "0 0 440 400",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M171.95 83.69C169.373 83.7622 166.921 84.8181 165.099 86.641C163.276 88.4638 162.22 90.9152 162.148 93.492C162.092 95.6803 162.757 97.8262 164.04 99.5995L164.131 99.7352L171.249 109.409C171.39 109.61 171.579 109.774 171.799 109.885C172.019 109.996 172.262 110.052 172.508 110.048C172.755 110.043 172.996 109.979 173.211 109.859C173.427 109.74 173.61 109.57 173.744 109.364L180.176 99.803C181.455 98.0268 182.17 95.9065 182.227 93.7182C182.224 92.381 181.955 91.0577 181.434 89.826C180.914 88.5942 180.152 87.4787 179.195 86.5448C178.238 85.6109 177.104 84.8773 175.86 84.3871C174.616 83.8969 173.287 83.6599 171.95 83.69ZM172.184 99.6824C171.052 99.6824 169.945 99.3467 169.004 98.7179C168.063 98.0891 167.329 97.1953 166.896 96.1496C166.463 95.1039 166.35 93.9532 166.571 92.8431C166.791 91.7329 167.336 90.7132 168.137 89.9129C168.937 89.1125 169.957 88.5674 171.067 88.3466C172.177 88.1258 173.328 88.2391 174.374 88.6723C175.419 89.1054 176.313 89.839 176.942 90.7801C177.571 91.7212 177.906 92.8277 177.906 93.9595C177.907 94.7113 177.76 95.456 177.473 96.1507C177.186 96.8455 176.764 97.4768 176.232 98.0084C175.701 98.54 175.07 98.9615 174.375 99.2488C173.68 99.536 172.935 99.6834 172.184 99.6824Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M324.244 63.324C324.832 59.079 318.838 55.588 314.337 55.2261C312.188 55.0527 309.956 55.3769 307.92 54.6681C303.517 53.1601 301.752 47.4373 297.454 45.6201C294.235 44.2629 290.533 45.4693 287.419 47.0376C284.305 48.606 281.221 50.5814 277.737 50.8076C274.721 50.9961 271.419 49.8727 268.772 51.3581C266.797 52.4589 265.756 54.736 263.939 56.0781C262.122 57.4202 259.837 57.669 257.628 57.7897C255.419 57.9103 253.104 57.9329 251.114 58.8528C249.123 59.7727 247.442 61.8688 247.856 64.0705L324.244 63.324Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M192.52 40.7348C192.829 38.4728 189.64 36.618 187.242 36.4219C186.096 36.3315 184.912 36.5049 183.826 36.1279C181.482 35.306 180.547 32.2825 178.254 31.3098C176.543 30.5935 174.575 31.2344 172.916 32.0638C171.257 32.8932 169.614 33.9488 167.759 34.0695C166.153 34.1675 164.396 33.5718 162.986 34.356C161.938 34.9441 161.387 36.158 160.415 36.8743C159.407 37.4941 158.242 37.8084 157.059 37.7791C155.878 37.7545 154.702 37.9488 153.591 38.3522C153.042 38.5662 152.576 38.9519 152.264 39.4519C151.951 39.9518 151.809 40.5393 151.857 41.1269L192.52 40.7348Z",
                fill: "#F5F5F5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M121.477 81.0358C121.937 77.6956 117.225 74.951 113.688 74.6645C112 74.5288 110.243 74.7852 108.644 74.2272C105.183 73.0208 103.796 68.542 100.418 67.117C97.8922 66.0614 94.9817 67.0039 92.5312 68.2329C90.0807 69.4619 87.6529 71.0227 84.9158 71.1961C82.5332 71.3469 79.9545 70.4421 77.8659 71.6259C76.3127 72.493 75.4984 74.2875 74.0959 75.3356C72.6935 76.3836 70.8462 76.6174 69.1045 76.6852C67.3627 76.7531 65.5757 76.7983 63.9923 77.5222C62.4089 78.246 61.1045 79.9199 61.4287 81.6239L121.477 81.0358Z",
                fill: "#F5F5F5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M387.948 73.9263C387.948 73.9263 387.511 73.8132 386.734 73.6549C385.637 73.436 384.51 73.4054 383.402 73.5644C381.764 73.7972 380.221 74.4724 378.938 75.5173C377.374 76.8003 376.27 78.5577 375.794 80.5238V80.5841L375.605 81.3381L375.319 80.6369C374.552 78.7682 373.238 77.1753 371.549 76.0677C370.171 75.1644 368.585 74.6273 366.942 74.5069C365.412 74.426 363.88 74.6201 362.418 75.0799C362.771 74.8544 363.158 74.6865 363.564 74.5823C364.66 74.2376 365.809 74.092 366.957 74.1525C368.674 74.2279 370.342 74.7475 371.798 75.6605C373.584 76.8005 374.975 78.4649 375.779 80.4258H375.304V80.3655C375.794 78.2816 376.971 76.4228 378.644 75.0875C379.996 74.0061 381.628 73.3314 383.349 73.1422C384.495 73.0046 385.658 73.0891 386.772 73.391C387.192 73.5004 387.59 73.6815 387.948 73.9263Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M58.2031 138.778L85.1963 285.318L141.347 295.497L191.654 263.128L245.459 276.12L301.255 240.32L273.938 101.305L218.383 128.999L170.459 118.594L118.282 146.22L58.2031 138.778Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M141.429 295.896L84.8789 285.642L84.8337 285.386L57.75 138.356L118.213 145.85L170.413 118.216L218.337 128.644L274.216 100.746L274.306 101.229L301.677 240.5L301.458 240.636L245.526 276.519L245.375 276.481L191.721 263.527L141.429 295.896ZM85.5198 284.994L141.271 295.105L191.585 262.72L191.736 262.758L245.39 275.712L300.832 240.138L273.688 101.862L218.435 129.398H218.307L170.511 119.016L118.349 146.635H118.251L58.685 139.2L85.5198 284.994Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M64 143.452L89.4927 282.43L140.968 290.219L191.132 256.914L243.806 269.453L295.998 237.914L271.418 107.117L219.271 133.756L170.412 125.296L117.059 151.332L93.1949 147.788L64 143.452Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M102.537 148.528L102.687 200.788L282.562 246.963L273.604 252.874L103.856 208.758L102.386 284.384L91.4453 282.725L93.1946 147.789L102.537 148.528Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M66.8125 155.887L93.8283 161.956L92.8934 170.544L67.7776 164.037L66.8125 155.887Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M73.2891 194.1L92.6442 189.832L92.5161 199.664L74.6915 203.66L73.2891 194.1Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M80.4219 232.961L92.0712 233.979L92.0033 239.604L81.3418 239.257L80.4219 232.961Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M102.387 284.384L117.301 286.638L120.747 256.554L144.166 258.937L146.405 286.608L156.313 280.033L156.109 222.337L103.857 208.758L102.387 284.384Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M162.088 223.888L161.802 254.885L161.598 276.517L156.312 280.031L155.77 220.035L162.088 223.888Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M186.307 260.112L161.802 254.887L161.734 262.148L178.601 265.232L186.307 260.112Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M130.127 144.954L126.176 206.819L135.058 209.096L140.064 140.105L130.127 144.954Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M156.797 214.677L158.305 137.437L163.651 139.571L163.236 166.443L218.798 182.533L232.001 129.158L242.165 123.473L225.901 184.192L213.309 231.551C213.309 231.551 205.973 229.847 206.229 228.641C206.485 227.434 216.272 192.275 216.272 192.275L162.376 174.797L161.404 219.208L156.797 214.677Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M220.75 191.617L258.088 202.535L275.438 128.5L272.158 112.184L252.878 192.688L222.183 183.263L220.75 191.617Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M200 259.585L206.22 228.641L213.61 230.405L207.042 261.711L200 259.585Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M276.917 183.383L261.656 258.67L275.16 250.157L288.453 200.265L286.538 187.221L276.917 183.383Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.1",
                d: "M117.059 151.332L140.968 290.219L89.4927 282.43L64 143.453L117.059 151.332Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M151.281 134.631L156.552 136.735L286.76 188.754L282.945 168.478L170.41 125.297L151.281 134.631Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.1",
                d: "M170.414 125.297L191.134 256.915L243.808 269.454L219.273 133.757L170.414 125.297Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M374.687 340.617H302.68L306.736 336.613H377.062L374.687 340.617Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M381.108 369.29C381.108 369.395 307.97 369.486 217.784 369.486C127.598 369.486 54.4453 369.395 54.4453 369.29C54.4453 369.184 127.583 369.094 217.784 369.094C307.985 369.094 381.108 369.169 381.108 369.29Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M146.289 104.085C146.289 104.138 145.43 103.791 143.831 103.437C141.573 102.942 139.245 102.85 136.955 103.165C133.554 103.615 130.346 105.001 127.688 107.169C124.429 109.82 122.13 113.468 121.143 117.552C121.143 117.589 121.143 117.627 121.143 117.665L120.955 118.419L120.668 117.71C119.062 113.845 116.319 110.558 112.804 108.285C109.942 106.423 106.651 105.325 103.243 105.096C100.948 104.932 98.6403 105.144 96.4123 105.722C94.8364 106.136 93.9995 106.476 93.9844 106.476C94.1705 106.361 94.3675 106.265 94.5725 106.189C95.1592 105.917 95.7638 105.685 96.3821 105.495C98.6243 104.851 100.96 104.596 103.289 104.741C106.774 104.928 110.152 106.017 113.091 107.901C116.697 110.219 119.505 113.587 121.136 117.552L120.661 117.597V117.476C121.67 113.286 124.037 109.548 127.394 106.845C130.129 104.649 133.426 103.267 136.91 102.856C139.238 102.567 141.6 102.71 143.877 103.279C144.493 103.43 145.097 103.624 145.686 103.859C145.895 103.913 146.097 103.989 146.289 104.085Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M220.476 77.3285C220.476 77.3285 219.994 77.1928 219.111 77.0043C217.87 76.7549 216.595 76.7192 215.341 76.8987C213.491 77.153 211.748 77.9151 210.305 79.1004C208.534 80.5474 207.284 82.5331 206.746 84.7554V84.8157L206.557 85.5697L206.271 84.861C205.405 82.7524 203.92 80.9566 202.011 79.7112C200.452 78.6901 198.659 78.0829 196.801 77.9468C195.535 77.8442 194.262 77.9486 193.031 78.2559C192.164 78.4671 191.696 78.6556 191.681 78.6179C191.666 78.5802 191.787 78.5425 192.005 78.4369C192.32 78.2902 192.645 78.1667 192.978 78.0674C194.519 77.5961 196.144 77.464 197.741 77.68C199.338 77.8961 200.869 78.4552 202.229 79.3191C204.237 80.6043 205.8 82.4759 206.708 84.68H206.233V84.6122C206.8 82.2804 208.126 80.2034 210.003 78.7083C211.523 77.4982 213.351 76.7381 215.281 76.5142C216.571 76.3657 217.878 76.4578 219.134 76.7856C219.474 76.8735 219.807 76.9869 220.129 77.1249C220.371 77.2531 220.484 77.3059 220.476 77.3285Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M170.093 50.9141C170.093 50.9141 169.626 51.4569 168.774 52.4221C167.578 53.7821 166.499 55.2399 165.546 56.7802C162.381 61.8669 160.721 67.7464 160.759 73.7376C160.755 73.808 160.755 73.8784 160.759 73.9488H160.261C159.774 70.732 158.725 67.6259 157.162 64.7726C155.025 60.8528 152.008 57.4821 148.348 54.9253C147.788 54.5761 147.247 54.1986 146.727 53.7943C146.888 53.8521 147.042 53.928 147.187 54.0205C147.481 54.1864 147.941 54.4051 148.461 54.7745C149.986 55.7504 151.404 56.8853 152.691 58.16C157.013 62.3936 159.844 67.9156 160.759 73.896H160.261V73.6849C160.217 67.6027 161.952 61.6404 165.252 56.5314C166.238 54.9916 167.372 53.5522 168.638 52.2336C169.075 51.751 169.46 51.4268 169.701 51.193C169.825 51.0905 169.956 50.9973 170.093 50.9141Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M399.197 300.223H196.688V304.913H399.197V300.223Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M198.73 305.005C198.73 305.005 198.73 304.923 198.73 304.742C198.73 304.561 198.73 304.274 198.73 303.912C198.73 303.158 198.73 302.035 198.73 300.512V300.444H198.791C210.734 300.353 250.116 300.293 296.811 300.293L369.285 300.353L391.242 300.421L397.213 300.466L391.242 300.512L369.285 300.579L296.811 300.647C250.153 300.647 210.772 300.579 198.828 300.489L198.889 300.429C198.889 301.937 198.889 303.075 198.889 303.829C198.889 304.191 198.889 304.463 198.889 304.659C198.889 304.855 198.73 305.005 198.73 305.005Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M222.844 300.555C223.135 302.023 223.135 303.535 222.844 305.003C222.552 303.535 222.552 302.023 222.844 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M249.398 300.555C249.69 302.023 249.69 303.535 249.398 305.003C249.107 303.535 249.107 302.023 249.398 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M275.953 300.555C276.245 302.023 276.245 303.535 275.953 305.003C275.661 303.535 275.661 302.023 275.953 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M302.512 300.555C302.803 302.023 302.803 303.535 302.512 305.003C302.22 303.535 302.22 302.023 302.512 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M329.066 300.555C329.358 302.023 329.358 303.535 329.066 305.003C328.775 303.535 328.775 302.023 329.066 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M355.625 300.555C355.916 302.023 355.916 303.535 355.625 305.003C355.333 303.535 355.333 302.023 355.625 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M382.148 300.555C382.44 302.023 382.44 303.535 382.148 305.003C381.857 303.535 381.857 302.023 382.148 300.555Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M286.037 73.0664H232.375V299.998H286.037V73.0664Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.622 84.3906H242.312V115.817H258.622V84.3906Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M250.953 115.825C250.832 115.825 250.734 108.783 250.734 100.104C250.734 91.4254 250.832 84.3906 250.953 84.3906C251.074 84.3906 251.164 91.4254 251.164 100.104C251.164 108.783 251.051 115.825 250.953 115.825Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.622 95.3084C255.91 95.5268 253.19 95.5998 250.471 95.5271C247.749 95.5998 245.026 95.5268 242.312 95.3084C245.026 95.09 247.749 95.017 250.471 95.0897C253.19 95.017 255.91 95.09 258.622 95.3084Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.71 106.551C255.974 106.769 253.228 106.842 250.484 106.769C247.743 106.842 244.999 106.769 242.266 106.551C244.999 106.332 247.743 106.259 250.484 106.332C253.228 106.259 255.974 106.332 258.71 106.551Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 125.863H242.379V157.29H258.688V125.863Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M250.992 157.294C250.871 157.294 250.773 150.259 250.773 141.581C250.773 132.902 250.871 125.867 250.992 125.867C251.113 125.867 251.211 132.902 251.211 141.581C251.211 150.259 251.113 157.294 250.992 157.294Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 136.781C255.974 136.999 253.251 137.072 250.53 137C247.811 137.072 245.09 136.999 242.379 136.781C245.09 136.563 247.811 136.49 250.53 136.562C253.251 136.49 255.974 136.563 258.688 136.781Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.773 148.023C256.039 148.242 253.296 148.315 250.554 148.242C247.81 148.315 245.064 148.242 242.328 148.023C245.064 147.805 247.81 147.732 250.554 147.805C253.296 147.732 256.039 147.805 258.773 148.023Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 166.969H242.379V198.395H258.688V166.969Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M250.992 198.395C250.871 198.395 250.773 191.361 250.773 182.682C250.773 174.004 250.871 166.969 250.992 166.969C251.113 166.969 251.211 174.004 251.211 182.682C251.211 191.361 251.113 198.395 250.992 198.395Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 177.887C255.974 178.105 253.251 178.178 250.53 178.105C247.811 178.178 245.09 178.105 242.379 177.887C245.09 177.668 247.811 177.595 250.53 177.668C253.251 177.595 255.974 177.668 258.688 177.887Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.773 189.129C256.039 189.347 253.296 189.42 250.554 189.347C247.81 189.42 245.064 189.347 242.328 189.129C245.064 188.91 247.81 188.837 250.554 188.91C253.296 188.837 256.039 188.91 258.773 189.129Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 209.262H242.379V240.688H258.688V209.262Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M250.992 240.696C250.871 240.696 250.773 233.661 250.773 224.983C250.773 216.304 250.871 209.262 250.992 209.262C251.113 209.262 251.211 216.297 251.211 224.983C251.211 233.669 251.113 240.696 250.992 240.696Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 220.178C255.974 220.396 253.251 220.469 250.53 220.396C247.811 220.469 245.09 220.396 242.379 220.178C245.09 219.969 247.811 219.898 250.53 219.967C253.251 219.899 255.974 219.969 258.688 220.178Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.773 231.422C256.039 231.64 253.296 231.713 250.554 231.64C247.81 231.713 245.064 231.64 242.328 231.422C245.064 231.203 247.81 231.13 250.554 231.203C253.296 231.13 256.039 231.203 258.773 231.422Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M308.86 73.0664H269.758V299.998H308.86V73.0664Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M308.86 73.0664H269.758V299.998H308.86V73.0664Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.164 84.3906H280.855V115.817H297.164V84.3906Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M289.476 115.825C289.356 115.825 289.258 108.783 289.258 100.104C289.258 91.4254 289.356 84.3906 289.476 84.3906C289.597 84.3906 289.695 91.4254 289.695 100.104C289.695 108.783 289.597 115.825 289.476 115.825Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.164 95.3084C294.453 95.5268 291.733 95.5998 289.014 95.5271C286.292 95.5998 283.569 95.5268 280.855 95.3084C283.569 95.09 286.292 95.017 289.014 95.0897C291.733 95.017 294.453 95.09 297.164 95.3084Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.257 106.551C294.521 106.769 291.775 106.842 289.031 106.769C286.29 106.842 283.546 106.769 280.812 106.551C283.546 106.332 286.29 106.259 289.031 106.332C291.775 106.259 294.521 106.332 297.257 106.551Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.231 127.047H280.922V158.474H297.231V127.047Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M289.535 158.481C289.414 158.481 289.316 151.439 289.316 142.76C289.316 134.082 289.414 127.047 289.535 127.047C289.656 127.047 289.754 134.082 289.754 142.76C289.754 151.439 289.656 158.481 289.535 158.481Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.231 137.965C294.517 138.183 291.794 138.256 289.073 138.183C286.354 138.256 283.633 138.183 280.922 137.965C283.633 137.746 286.354 137.673 289.073 137.746C291.794 137.673 294.517 137.746 297.231 137.965Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.316 149.207C294.582 149.425 291.839 149.498 289.097 149.426C286.353 149.498 283.607 149.425 280.871 149.207C283.607 148.988 286.353 148.915 289.097 148.988C291.839 148.916 294.582 148.989 297.316 149.207Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.231 166.969H280.922V198.395H297.231V166.969Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M289.535 198.395C289.414 198.395 289.316 191.361 289.316 182.682C289.316 174.004 289.414 166.969 289.535 166.969C289.656 166.969 289.754 174.004 289.754 182.682C289.754 191.361 289.656 198.395 289.535 198.395Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.231 177.887C294.517 178.105 291.794 178.178 289.073 178.105C286.354 178.178 283.633 178.105 280.922 177.887C283.633 177.668 286.354 177.595 289.073 177.668C291.794 177.595 294.517 177.668 297.231 177.887Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.316 189.129C294.582 189.347 291.839 189.42 289.097 189.347C286.353 189.42 283.607 189.347 280.871 189.129C283.607 188.91 286.353 188.837 289.097 188.91C291.839 188.837 294.582 188.91 297.316 189.129Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.895 209.949H281.586V241.376H297.895V209.949Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M290.199 241.376C290.079 241.376 289.988 234.341 289.988 225.663C289.988 216.984 290.079 209.949 290.199 209.949C290.32 209.949 290.418 216.984 290.418 225.663C290.418 234.341 290.32 241.376 290.199 241.376Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.895 220.867C295.184 221.085 292.463 221.158 289.744 221.086C287.023 221.158 284.3 221.085 281.586 220.867C284.3 220.649 287.023 220.576 289.744 220.648C292.463 220.576 295.184 220.649 297.895 220.867Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.98 232.109C295.246 232.327 292.503 232.4 289.762 232.328C287.02 232.4 284.277 232.327 281.543 232.109C284.277 231.891 287.02 231.818 289.762 231.89C292.503 231.818 295.246 231.891 297.98 232.109Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 252.555H242.379V283.981H258.688V252.555Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M250.992 283.969C250.871 283.969 250.773 276.927 250.773 268.249C250.773 259.57 250.871 252.535 250.992 252.535C251.113 252.535 251.211 259.57 251.211 268.249C251.211 276.927 251.113 283.969 250.992 283.969Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.688 263.472C255.974 263.691 253.251 263.764 250.53 263.691C247.811 263.764 245.09 263.691 242.379 263.472C245.09 263.254 247.811 263.181 250.53 263.254C253.251 263.181 255.974 263.254 258.688 263.472Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M258.773 274.715C256.039 274.933 253.296 275.006 250.554 274.933C247.81 275.006 245.064 274.933 242.328 274.715C245.064 274.496 247.81 274.423 250.554 274.496C253.296 274.423 256.039 274.496 258.773 274.715Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.231 253.906H280.922V285.333H297.231V253.906Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M289.535 285.333C289.414 285.333 289.316 278.298 289.316 269.62C289.316 260.941 289.414 253.906 289.535 253.906C289.656 253.906 289.754 260.941 289.754 269.62C289.754 278.298 289.656 285.333 289.535 285.333Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.231 264.824C294.517 265.042 291.794 265.115 289.073 265.043C286.354 265.115 283.633 265.042 280.922 264.824C283.633 264.606 286.354 264.533 289.073 264.605C291.794 264.533 294.517 264.606 297.231 264.824Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M297.316 276.066C294.582 276.285 291.839 276.358 289.097 276.285C286.353 276.358 283.607 276.285 280.871 276.066C283.607 275.848 286.353 275.775 289.097 275.848C291.839 275.775 294.582 275.848 297.316 276.066Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M335.566 198.977H354.582V171.493H335.566V198.977Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M335.566 198.977H354.582V171.493H335.566V198.977Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M318.461 198.977H337.477V171.493H318.461V198.977Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M322.998 193.426C322.998 193.426 322.998 193.336 322.998 193.147C322.998 192.959 322.998 192.649 322.998 192.303C322.998 191.549 322.998 190.44 322.998 189.075C322.998 186.278 322.96 182.35 322.93 177.765V177.652H331.631L331.767 177.796V182.176C331.767 183.601 331.767 184.974 331.767 186.301C331.767 188.94 331.767 191.353 331.767 193.441V193.547H331.631L325.29 193.494H323.578H323.141C323.043 193.494 322.998 193.494 322.998 193.494H323.163H323.623H325.358L331.631 193.441L331.525 193.539C331.525 191.451 331.525 189.015 331.525 186.399C331.525 185.072 331.525 183.699 331.525 182.274V177.894C331.405 177.765 331.691 178.052 331.661 178.022H322.998L323.126 177.894C323.126 182.418 323.081 186.338 323.065 189.121C323.065 190.493 323.065 191.594 323.028 192.37C323.028 192.732 323.028 193.026 323.028 193.245C323.022 193.306 323.012 193.366 322.998 193.426Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M324.723 186.447C324.723 186.447 324.934 186.447 325.04 186.665C325.071 186.74 325.083 186.821 325.075 186.901C325.067 186.981 325.039 187.058 324.995 187.125C324.928 187.205 324.838 187.262 324.738 187.289C324.637 187.317 324.531 187.313 324.433 187.279C324.335 187.245 324.249 187.181 324.188 187.097C324.127 187.013 324.093 186.912 324.09 186.808C324.098 186.727 324.126 186.65 324.171 186.581C324.215 186.513 324.275 186.457 324.346 186.416C324.587 186.288 324.753 186.416 324.723 186.416C324.693 186.416 324.58 186.416 324.452 186.545C324.413 186.571 324.382 186.609 324.364 186.653C324.345 186.696 324.34 186.744 324.348 186.791C324.356 186.838 324.377 186.881 324.408 186.916C324.44 186.952 324.481 186.977 324.527 186.989C324.761 187.08 324.889 186.869 324.851 186.688C324.814 186.507 324.716 186.484 324.723 186.447Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M299.081 300.172H377.941V193.88H299.081V300.172Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M346.363 300.171L388.663 300.223V193.887H346.363V300.171Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M346.363 300.171L388.663 300.223V193.887H346.363V300.171Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M304.873 265.977H319.297V251.553H304.873V265.977Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M311.53 267.424C311.455 267.424 311.395 263.692 311.395 259.13C311.395 254.568 311.455 250.836 311.53 250.836C311.606 250.836 311.666 254.561 311.666 259.13C311.666 263.699 311.606 267.424 311.53 267.424Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M302.164 256.386C302.164 256.31 306.356 256.25 311.529 256.25C316.701 256.25 320.901 256.31 320.901 256.386C320.901 256.461 316.709 256.521 311.529 256.521C306.349 256.521 302.164 256.461 302.164 256.386Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M325.447 265.977H339.871V251.553H325.447V265.977Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M332.104 267.424C332.029 267.424 331.961 263.692 331.961 259.13C331.961 254.568 332.029 250.836 332.104 250.836C332.18 250.836 332.24 254.561 332.24 259.13C332.24 263.699 332.18 267.424 332.104 267.424Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M322.734 256.386C322.734 256.31 326.927 256.25 332.099 256.25C337.271 256.25 341.471 256.31 341.471 256.386C341.471 256.461 337.279 256.521 332.099 256.521C326.919 256.521 322.734 256.461 322.734 256.386Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M304.873 243.191H319.297V228.767H304.873V243.191Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M311.53 244.639C311.455 244.639 311.395 240.906 311.395 236.345C311.395 231.783 311.455 228.051 311.53 228.051C311.606 228.051 311.666 231.776 311.666 236.345C311.666 240.914 311.606 244.639 311.53 244.639Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M302.164 233.601C302.164 233.525 306.356 233.465 311.529 233.465C316.701 233.465 320.901 233.525 320.901 233.601C320.901 233.676 316.709 233.736 311.529 233.736C306.349 233.736 302.164 233.676 302.164 233.601Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M325.447 243.191H339.871V228.767H325.447V243.191Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M332.104 244.639C332.029 244.639 331.961 240.906 331.961 236.345C331.961 231.783 332.029 228.051 332.104 228.051C332.18 228.051 332.24 231.776 332.24 236.345C332.24 240.914 332.18 244.639 332.104 244.639Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M322.734 233.601C322.734 233.525 326.927 233.465 332.099 233.465C337.271 233.465 341.471 233.525 341.471 233.601C341.471 233.676 337.279 233.736 332.099 233.736C326.919 233.736 322.734 233.676 322.734 233.601Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M304.873 220.344H319.297V205.92H304.873V220.344Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M311.53 221.799C311.455 221.799 311.395 218.067 311.395 213.505C311.395 208.943 311.455 205.211 311.53 205.211C311.606 205.211 311.666 208.936 311.666 213.505C311.666 218.074 311.606 221.799 311.53 221.799Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M302.164 210.761C302.164 210.685 306.356 210.625 311.529 210.625C316.701 210.625 320.901 210.685 320.901 210.761C320.901 210.836 316.709 210.896 311.529 210.896C306.349 210.896 302.164 210.829 302.164 210.761Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M325.447 220.344H339.871V205.92H325.447V220.344Z",
                fill: "#EBEBEB"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M332.104 221.799C332.029 221.799 331.961 218.067 331.961 213.505C331.961 208.943 332.029 205.211 332.104 205.211C332.18 205.211 332.24 208.936 332.24 213.505C332.24 218.074 332.18 221.799 332.104 221.799Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M322.734 210.761C322.734 210.685 326.927 210.625 332.099 210.625C337.271 210.625 341.471 210.685 341.471 210.761C341.471 210.836 337.279 210.896 332.099 210.896C326.919 210.896 322.734 210.829 322.734 210.761Z",
                fill: "#687981"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.7",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M360.849 220.348H375.273V205.924H360.849V220.348Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M368.065 221.799C367.99 221.799 367.93 218.067 367.93 213.505C367.93 208.943 367.99 205.211 368.065 205.211C368.141 205.211 368.201 208.936 368.201 213.505C368.201 218.074 368.141 221.799 368.065 221.799Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M358.141 210.761C358.141 210.685 362.34 210.625 367.513 210.625C372.685 210.625 376.878 210.685 376.878 210.761C376.878 210.836 372.685 210.896 367.513 210.896C362.34 210.896 358.141 210.829 358.141 210.761Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.7",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M360.849 243.41H375.273V228.986H360.849V243.41Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M368.065 244.865C367.99 244.865 367.93 241.133 367.93 236.571C367.93 232.01 367.99 228.277 368.065 228.277C368.141 228.277 368.201 232.002 368.201 236.571C368.201 241.141 368.141 244.865 368.065 244.865Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M358.141 233.827C358.141 233.752 362.34 233.691 367.513 233.691C372.685 233.691 376.878 233.752 376.878 233.827C376.878 233.903 372.685 233.963 367.513 233.963C362.34 233.963 358.141 233.903 358.141 233.827Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.7",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M360.849 266.484H375.273V252.06H360.849V266.484Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M368.065 267.924C367.99 267.924 367.93 264.199 367.93 259.63C367.93 255.061 367.99 251.336 368.065 251.336C368.141 251.336 368.201 255.068 368.201 259.63C368.201 264.192 368.141 267.924 368.065 267.924Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M358.141 256.894C358.141 256.818 362.34 256.758 367.513 256.758C372.685 256.758 376.878 256.818 376.878 256.894C376.878 256.969 372.685 257.029 367.513 257.029C362.34 257.029 358.141 256.969 358.141 256.894Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M315.411 299.696C315.411 299.696 315.411 299.651 315.411 299.568C315.411 299.485 315.411 299.342 315.411 299.184C315.411 298.827 315.411 298.337 315.411 297.713C315.411 296.409 315.411 294.547 315.373 292.224C315.373 287.527 315.373 280.982 315.32 273.48V273.352H330.4V273.48C330.4 281.02 330.4 287.647 330.355 292.39C330.355 294.735 330.355 296.62 330.355 297.932C330.355 298.573 330.355 299.063 330.355 299.44C330.355 299.598 330.355 299.726 330.355 299.824C330.355 299.923 330.355 299.953 330.355 299.953C330.352 299.91 330.352 299.867 330.355 299.824C330.355 299.726 330.355 299.598 330.355 299.44C330.355 299.078 330.355 298.588 330.355 297.932C330.355 296.62 330.355 294.735 330.355 292.39C330.355 287.647 330.355 281.042 330.31 273.48L330.438 273.615H315.66L315.795 273.48C315.795 281.02 315.758 287.527 315.743 292.224C315.743 294.547 315.743 296.409 315.705 297.713C315.705 298.342 315.705 298.832 315.705 299.184C315.705 299.342 315.705 299.47 315.705 299.568C315.705 299.666 315.411 299.696 315.411 299.696Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M323.299 287.098H328.336V275.041H323.299V287.098Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M328.352 287.111H323.285V275.047H328.352V287.111ZM323.308 287.111H328.322V275.047H323.338L323.308 287.111Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M317.276 287.098H322.312V275.041H317.276V287.098Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M322.325 287.111H317.258V275.047H322.325V287.111ZM317.28 287.111H322.295V275.047H317.303L317.28 287.111Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M317.169 288.347C317.169 288.385 316.92 288.385 316.807 288.671C316.774 288.747 316.756 288.83 316.756 288.913C316.756 288.996 316.774 289.078 316.807 289.154C316.855 289.237 316.927 289.304 317.012 289.347C317.098 289.39 317.195 289.407 317.29 289.395C317.383 289.369 317.466 289.317 317.53 289.245C317.594 289.172 317.637 289.083 317.652 288.988C317.666 288.907 317.658 288.824 317.628 288.747C317.599 288.67 317.55 288.602 317.486 288.551C317.245 288.355 317.018 288.4 317.011 288.362C317.003 288.324 317.245 288.181 317.599 288.4C317.703 288.464 317.786 288.556 317.84 288.665C317.893 288.775 317.914 288.897 317.901 289.018C317.901 289.182 317.843 289.341 317.737 289.467C317.631 289.592 317.483 289.676 317.321 289.703C317.16 289.73 316.993 289.699 316.852 289.615C316.711 289.531 316.604 289.4 316.551 289.244C316.505 289.134 316.485 289.014 316.494 288.895C316.504 288.776 316.541 288.66 316.604 288.558C316.642 288.489 316.694 288.429 316.758 288.382C316.822 288.335 316.895 288.302 316.973 288.287C317.116 288.302 317.169 288.325 317.169 288.347Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M301.667 273.48C301.663 273.425 301.663 273.37 301.667 273.315C301.667 273.171 301.667 273.005 301.667 272.809C301.667 272.312 301.667 271.671 301.667 270.887H301.704H310.119L310.172 270.94V273.563H310.119H304.087H302.33H304.102H310.134L310.081 273.616V271.045C310.187 271.158 310.081 271.045 310.134 271.105H301.719V271.068C301.719 271.822 301.719 272.478 301.719 272.968C301.719 273.164 301.719 273.337 301.719 273.48C301.719 273.624 301.667 273.48 301.667 273.48Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M334.405 268.132C334.402 268.074 334.402 268.016 334.405 267.958C334.405 267.815 334.405 267.649 334.405 267.453C334.405 266.963 334.405 266.322 334.405 265.538V265.5H334.442H342.857C342.857 265.5 342.804 265.44 342.91 265.553V268.192H342.857H336.825H335.068H336.833H342.865L342.812 268.253V265.666L342.865 265.719H334.45C334.45 266.473 334.45 267.129 334.45 267.612C334.45 267.815 334.45 267.981 334.45 268.124C334.45 268.268 334.405 268.132 334.405 268.132Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M339.652 247.023C339.652 247.023 339.652 246.971 339.652 246.858V246.352C339.652 245.862 339.652 245.221 339.652 244.43H348.067L348.127 244.482V247.106H348.075H342.043H340.286H342.05H348.082L348.029 247.159C348.029 246.752 348.029 246.322 348.029 245.892V244.588C348.142 244.701 348.029 244.588 348.082 244.648H339.667L339.705 244.611C339.705 245.365 339.705 246.028 339.705 246.511V247.023C339.688 247.024 339.67 247.024 339.652 247.023Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M309.395 224.328V224.155C309.395 224.011 309.395 223.846 309.395 223.65C309.395 223.159 309.395 222.519 309.395 221.734H317.817L317.869 221.787V224.404H317.817H311.785H310.028H311.792H317.824L317.771 224.464C317.771 224.049 317.771 223.627 317.771 223.19V221.878L317.832 221.93H309.41H309.447C309.447 222.684 309.447 223.34 309.447 223.823V224.336C309.402 224.26 309.395 224.328 309.395 224.328Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M333.35 200.094C333.347 200.039 333.347 199.983 333.35 199.928C333.35 199.785 333.35 199.619 333.35 199.423C333.35 198.92 333.35 198.279 333.35 197.5H341.765L341.818 197.553V200.177H341.765H335.733H333.976H335.74H341.772L341.72 200.229V197.658C341.825 197.771 341.72 197.658 341.772 197.719H333.358V197.681C333.358 198.435 333.358 199.098 333.358 199.581C333.358 199.777 333.358 199.95 333.358 200.094C333.358 200.237 333.35 200.094 333.35 200.094Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M304.299 226.832C304.296 226.776 304.296 226.721 304.299 226.666V226.16C304.299 225.67 304.299 225.029 304.299 224.245V224.208H304.337H312.752C312.752 224.208 312.699 224.155 312.812 224.268V225.572C312.812 226.01 312.812 226.432 312.812 226.839V226.892H312.759H306.727H304.978H306.742H312.774L312.722 226.945V224.373L312.774 224.426H304.36H304.397C304.397 225.18 304.397 225.836 304.397 226.319C304.397 226.522 304.397 226.688 304.397 226.832C304.365 226.833 304.332 226.833 304.299 226.832Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M343.266 249.563C343.266 249.563 343.266 249.51 343.266 249.397C343.266 249.284 343.266 249.088 343.266 248.891C343.266 248.394 343.266 247.753 343.266 246.969H351.68L351.741 247.022V248.326C351.741 248.756 351.741 249.178 351.741 249.593V249.645H351.688H345.656H343.907H345.671H351.703L351.65 249.698V247.022L351.703 247.074H343.288L343.326 247.037C343.326 247.811 343.326 248.444 343.326 248.937C343.326 249.133 343.326 249.299 343.326 249.449C343.326 249.6 343.266 249.563 343.266 249.563Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M339.652 202.688C339.652 202.688 339.652 202.635 339.652 202.522V202.016C339.652 201.519 339.652 200.878 339.652 200.094H348.067L348.127 200.147V202.77H348.075H342.043H340.286H342.05H348.082L348.029 202.823C348.029 202.409 348.029 201.986 348.029 201.557V200.252L348.082 200.305H339.667L339.705 200.267C339.705 201.046 339.705 201.68 339.705 202.167V202.537C339.66 202.62 339.652 202.688 339.652 202.688Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M298.94 276.074C298.937 276.019 298.937 275.964 298.94 275.908C298.94 275.765 298.94 275.599 298.94 275.403C298.94 274.913 298.94 274.272 298.94 273.48H298.978H307.392L307.445 273.533V276.157H307.392H301.36H299.604H301.375H307.407L307.355 276.21V274.943C307.355 274.725 307.355 274.506 307.355 274.287V273.639L307.415 273.699H299V273.661C299 274.415 299 275.079 299 275.562C299 275.758 299 275.931 299 276.074H298.94Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M371.897 103.23H299.234V153.809H326.409L335.683 163.89L344.912 153.809H371.897V103.23Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M335.272 71.6841C332.451 71.747 329.702 72.5799 327.32 74.0927C324.939 75.6055 323.016 77.7406 321.761 80.2671C320.505 82.7936 319.965 85.6153 320.197 88.427C320.43 91.2386 321.426 93.9332 323.08 96.2193L323.23 96.4228L334.201 111.299C334.425 111.603 334.718 111.848 335.057 112.014C335.395 112.181 335.768 112.263 336.145 112.255C336.522 112.247 336.892 112.148 337.223 111.968C337.553 111.787 337.836 111.529 338.047 111.216L347.954 96.4907C349.824 93.633 351.113 90.6472 351.113 87.126C351.11 85.0653 350.695 83.026 349.893 81.1278C349.09 79.2297 347.917 77.5109 346.441 76.0725C344.965 74.6341 343.217 73.5049 341.299 72.7513C339.381 71.9977 337.332 71.6349 335.272 71.6841ZM335.641 98.4059C333.34 98.4059 331.091 97.7235 329.178 96.4451C327.264 95.1668 325.773 93.3497 324.893 91.2239C324.012 89.098 323.782 86.7587 324.231 84.5019C324.68 82.2451 325.788 80.1721 327.415 78.545C329.042 76.9179 331.115 75.8099 333.372 75.361C335.628 74.9121 337.968 75.1425 340.093 76.023C342.219 76.9036 344.036 78.3948 345.315 80.308C346.593 82.2213 347.275 84.4706 347.275 86.7716C347.275 89.8572 346.05 92.8164 343.868 94.9983C341.686 97.1801 338.727 98.4059 335.641 98.4059Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M335.272 71.6841C332.451 71.747 329.702 72.5799 327.32 74.0927C324.939 75.6055 323.016 77.7406 321.761 80.2671C320.505 82.7936 319.965 85.6153 320.197 88.427C320.43 91.2386 321.426 93.9332 323.08 96.2193L323.23 96.4228L334.201 111.299C334.425 111.603 334.718 111.848 335.057 112.014C335.395 112.181 335.768 112.263 336.145 112.255C336.522 112.247 336.892 112.148 337.223 111.968C337.553 111.787 337.836 111.529 338.047 111.216L347.954 96.4907C349.824 93.633 351.113 90.6472 351.113 87.126C351.11 85.0653 350.695 83.026 349.893 81.1278C349.09 79.2297 347.917 77.5109 346.441 76.0725C344.965 74.6341 343.217 73.5049 341.299 72.7513C339.381 71.9977 337.332 71.6349 335.272 71.6841ZM335.641 98.4059C333.34 98.4059 331.091 97.7235 329.178 96.4451C327.264 95.1668 325.773 93.3497 324.893 91.2239C324.012 89.098 323.782 86.7587 324.231 84.5019C324.68 82.2451 325.788 80.1721 327.415 78.545C329.042 76.9179 331.115 75.8099 333.372 75.361C335.628 74.9121 337.968 75.1425 340.093 76.023C342.219 76.9036 344.036 78.3948 345.315 80.308C346.593 82.2213 347.275 84.4706 347.275 86.7716C347.275 89.8572 346.05 92.8164 343.868 94.9983C341.686 97.1801 338.727 98.4059 335.641 98.4059Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M334.354 71.6841C331.533 71.747 328.784 72.5799 326.402 74.0927C324.021 75.6055 322.098 77.7406 320.843 80.2671C319.588 82.7936 319.047 85.6153 319.279 88.427C319.512 91.2386 320.508 93.9332 322.162 96.2193L322.312 96.4228L333.283 111.299C333.508 111.603 333.802 111.848 334.141 112.014C334.48 112.181 334.854 112.263 335.231 112.255C335.609 112.247 335.979 112.148 336.31 111.968C336.642 111.787 336.925 111.529 337.136 111.216L347.036 96.4907C348.914 93.633 350.195 90.6472 350.195 87.126C350.192 85.0653 349.777 83.026 348.975 81.1278C348.172 79.2297 346.999 77.5109 345.523 76.0725C344.047 74.6341 342.299 73.5049 340.381 72.7513C338.463 71.9977 336.414 71.6349 334.354 71.6841ZM334.723 96.3097C332.98 96.3112 331.275 95.7955 329.824 94.8279C328.374 93.8603 327.243 92.4842 326.575 90.8738C325.906 89.2633 325.731 87.4908 326.07 85.7805C326.409 84.0702 327.248 82.499 328.48 81.2655C329.713 80.0321 331.283 79.1919 332.993 78.8511C334.703 78.5104 336.476 78.6845 338.087 79.3515C339.698 80.0184 341.075 81.1481 342.044 82.5978C343.013 84.0474 343.53 85.7519 343.53 87.4955C343.53 89.8319 342.602 92.0727 340.951 93.7254C339.3 95.3782 337.06 96.3077 334.723 96.3097Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M348.083 124.626C348.083 124.731 340.905 124.822 332.045 124.822C323.186 124.822 316 124.731 316 124.626C316 124.52 323.186 124.43 332.045 124.43C340.905 124.43 348.083 124.513 348.083 124.626Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M346.378 131.052C346.378 131.157 340.444 131.248 333.123 131.248C325.801 131.248 319.875 131.157 319.875 131.052C319.875 130.946 325.809 130.855 333.123 130.855C340.437 130.855 346.378 130.946 346.378 131.052Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M349.026 137.731C349.026 137.844 344.615 137.927 339.179 137.927C333.743 137.927 329.324 137.844 329.324 137.731C329.324 137.618 333.735 137.535 339.179 137.535C344.623 137.535 349.026 137.626 349.026 137.731Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M364.19 145.458C364.19 145.571 357.404 145.654 349.027 145.654C340.65 145.654 333.895 145.571 333.895 145.458C333.895 145.345 340.681 145.262 349.057 145.262C357.434 145.262 364.19 145.352 364.19 145.458Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M113.447 342.606H40L44.1319 338.527H115.86L113.447 342.606Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M175.141 256.535C175.602 256.311 176.042 256.043 176.453 255.736C177.244 255.208 178.323 254.469 179.469 253.632L180.064 253.21L179.846 253.157C180.479 254.265 181.044 255.238 181.467 255.924C181.677 256.31 181.93 256.672 182.221 257.002C182.085 256.59 181.9 256.195 181.67 255.826C181.301 255.11 180.758 254.115 180.162 253.006L180.072 252.855L179.936 252.953L179.333 253.376C178.157 254.213 177.071 254.982 176.317 255.555C175.891 255.838 175.496 256.167 175.141 256.535Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M262.006 339.856C262.96 326.235 252.691 314.42 239.069 313.466C225.448 312.513 213.633 322.782 212.68 336.403C211.726 350.024 221.995 361.839 235.616 362.793C249.238 363.746 261.053 353.477 262.006 339.856Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M211.61 337.676V337.744C211.581 344.242 214.118 350.489 218.67 355.127C223.222 359.766 229.42 362.42 235.918 362.513C242.416 362.607 248.688 360.132 253.372 355.626C258.055 351.121 260.771 344.949 260.929 338.452C260.929 338.452 260.929 338.407 260.929 338.392L211.61 337.676Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M218.955 337.85C218.9 341.281 219.865 344.653 221.727 347.536C223.589 350.419 226.265 352.685 229.416 354.046C232.567 355.408 236.051 355.804 239.427 355.184C242.803 354.564 245.919 352.957 248.38 350.565C250.842 348.173 252.538 345.104 253.255 341.748C253.972 338.391 253.676 334.897 252.406 331.708C251.135 328.52 248.947 325.78 246.119 323.836C243.29 321.891 239.948 320.83 236.516 320.787C231.927 320.728 227.502 322.491 224.21 325.69C220.918 328.888 219.029 333.261 218.955 337.85Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M236.514 320.787C231.925 320.728 227.499 322.491 224.208 325.69C220.916 328.888 219.027 333.261 218.953 337.85L253.577 338.347C253.635 333.758 251.872 329.333 248.674 326.041C245.475 322.75 241.103 320.86 236.514 320.787Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M225.716 337.946C225.685 340.034 226.274 342.084 227.408 343.837C228.543 345.591 230.172 346.968 232.089 347.795C234.007 348.623 236.127 348.863 238.18 348.485C240.234 348.107 242.13 347.128 243.628 345.673C245.125 344.218 246.158 342.351 246.594 340.308C247.03 338.266 246.851 336.14 246.079 334.2C245.307 332.26 243.976 330.592 242.256 329.408C240.536 328.224 238.503 327.576 236.415 327.548C233.618 327.51 230.92 328.583 228.914 330.533C226.908 332.482 225.758 335.148 225.716 337.946Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M224.564 301.934C224.564 301.934 249.816 294.296 260.266 321.727L207.426 338.096L224.564 301.934Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M59.44 337.741C59.3704 342.619 60.7488 347.407 63.4008 351.502C66.0528 355.596 69.8593 358.812 74.339 360.742C78.8187 362.673 83.7703 363.232 88.5677 362.349C93.3651 361.465 97.7928 359.179 101.291 355.779C104.789 352.379 107.2 348.018 108.22 343.248C109.239 338.477 108.821 333.512 107.018 328.979C105.216 324.446 102.11 320.55 98.0924 317.783C94.0753 315.015 89.3278 313.501 84.4502 313.432C81.2116 313.385 77.9956 313.977 74.9857 315.174C71.9759 316.37 69.2313 318.148 66.9087 320.405C64.5862 322.663 62.7311 325.356 61.4496 328.33C60.1681 331.305 59.4852 334.503 59.44 337.741Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M59.4377 337.676V337.744C59.4091 344.242 61.9464 350.489 66.4983 355.127C71.0501 359.766 77.2485 362.42 83.7464 362.513C90.2443 362.607 96.5165 360.132 101.2 355.626C105.883 351.121 108.599 344.949 108.757 338.452C108.757 338.452 108.757 338.407 108.757 338.392L59.4377 337.676Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M66.7835 337.849C66.7285 341.282 67.6937 344.654 69.5568 347.538C71.4199 350.422 74.0971 352.688 77.2492 354.049C80.4012 355.41 83.8863 355.804 87.2629 355.183C90.6395 354.561 93.7556 352.951 96.2164 350.557C98.6772 348.163 100.372 345.092 101.086 341.734C101.8 338.376 101.501 334.881 100.227 331.693C98.9535 328.505 96.762 325.766 93.9304 323.825C91.0988 321.883 87.7546 320.826 84.3215 320.786C79.7362 320.734 75.3168 322.5 72.0301 325.697C68.7434 328.895 66.8569 333.264 66.7835 337.849Z",
                fill: "#FAFAFA"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M84.3185 320.787C79.7293 320.728 75.3041 322.491 72.0124 325.69C68.7208 328.888 66.8313 333.261 66.7578 337.85L101.381 338.347C101.44 333.758 99.6768 329.333 96.4785 326.041C93.2802 322.75 88.9074 320.86 84.3185 320.787Z",
                fill: "#E0E0E0"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M73.5441 337.946C73.513 340.034 74.1019 342.084 75.2364 343.837C76.3709 345.591 77.9999 346.968 79.9174 347.795C81.8349 348.623 83.9547 348.863 86.0085 348.485C88.0624 348.107 89.9581 347.128 91.4557 345.673C92.9534 344.218 93.9856 342.351 94.422 340.308C94.8583 338.266 94.6791 336.14 93.907 334.2C93.1349 332.26 91.8046 330.592 90.0844 329.408C88.3643 328.224 86.3315 327.576 84.2434 327.548C81.4463 327.51 78.7483 328.583 76.7422 330.533C74.7361 332.482 73.5858 335.148 73.5441 337.946Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M119.18 328.197C119.006 328.265 106.188 326.191 106.188 326.191C105.494 327.099 104.61 327.844 103.598 328.374C102.586 328.904 101.471 329.206 100.33 329.26C94.7878 329.524 89.359 329.773 84.6616 330.014C82.5667 330.11 80.5947 331.03 79.1752 332.574C77.7558 334.118 77.0041 336.16 77.0839 338.255C77.1692 340.252 78.0018 342.144 79.4165 343.556C80.8312 344.968 82.7248 345.797 84.7219 345.878L112.032 346.949C116.556 347.13 122.497 344.401 125.302 340.917L119.18 328.197Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M52.0808 317.28C52.0808 317.28 50.9045 293.25 73.4944 288.236V285.16H152.619V292.504C152.619 292.504 141.008 306.49 144.8 318.102C148.593 329.714 149.777 330.92 149.777 330.92H194.813C198.364 325.922 200.343 319.978 200.498 313.85C200.739 303.663 196.502 286.231 193.343 275.094C190.47 264.96 188.653 256.493 188.653 256.493L202.157 251.969C202.157 251.969 227.16 284.655 228.178 286.494C229.195 288.334 232.702 292.617 231.857 302.012C231.013 311.407 208.573 340.405 202.655 343.678C196.736 346.95 191.39 347.154 186.112 347.976C181.497 348.684 147.409 348.209 138.489 348.074C135.389 348.057 132.349 347.213 129.682 345.631C127.013 344.017 125.008 341.34 122.798 336.945L118.101 327.753L52.0808 317.28Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M58.131 315.637L48.1631 331.222C47.8776 331.657 47.7396 332.173 47.7697 332.693C47.7997 333.213 47.9961 333.71 48.33 334.109C48.6638 334.509 49.1173 334.791 49.6236 334.913C50.1298 335.035 50.662 334.992 51.1414 334.788C52.3814 334.241 53.5128 333.474 54.4817 332.526C59.0434 328.183 67.1715 316.76 67.1715 316.76L58.131 315.637Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M129.605 318.417C129.616 318.34 129.634 318.264 129.658 318.19C129.708 318.035 129.776 317.816 129.861 317.534C130.101 316.692 130.275 315.832 130.382 314.963C130.729 311.743 130.208 308.489 128.874 305.538C127.967 303.506 126.726 301.64 125.202 300.019C123.447 298.17 121.411 296.61 119.17 295.397C116.685 294.055 114.025 293.066 111.268 292.456C108.295 291.814 105.261 291.5 102.22 291.521C99.1925 291.545 96.17 291.767 93.1717 292.185C90.2537 292.585 87.4489 293.067 84.8099 293.693C80.1188 294.686 75.5976 296.357 71.3887 298.654C68.5633 300.224 65.9804 302.195 63.7205 304.505C62.9212 305.327 62.3557 306.013 61.9712 306.481L61.5414 307.016C61.4966 307.078 61.4461 307.136 61.3906 307.189C62.061 306.202 62.818 305.276 63.6526 304.422C65.8914 302.065 68.4712 300.057 71.3057 298.466C75.5194 296.122 80.0577 294.417 84.7722 293.406C87.4187 292.796 90.2236 292.306 93.1491 291.898C96.1718 291.47 99.2197 291.243 102.273 291.22C105.329 291.198 108.379 291.517 111.366 292.17C114.151 292.804 116.835 293.819 119.343 295.186C121.615 296.418 123.676 298.004 125.45 299.883C126.989 301.53 128.236 303.427 129.138 305.493C130.476 308.48 130.978 311.774 130.593 315.024C130.473 315.898 130.278 316.761 130.012 317.602L129.778 318.251C129.724 318.309 129.666 318.365 129.605 318.417Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M125.037 313.027C124.999 313.027 125.165 312.642 125.338 311.956C125.561 310.965 125.589 309.941 125.421 308.94C125.19 307.468 124.695 306.05 123.959 304.755C123.539 303.981 123.049 303.246 122.496 302.561C121.907 301.825 121.242 301.153 120.513 300.555C119.099 299.397 117.511 298.468 115.808 297.803C114.411 297.266 112.964 296.872 111.487 296.627C110.489 296.459 109.482 296.344 108.471 296.28C108.098 296.277 107.725 296.25 107.355 296.197C107.453 296.184 107.552 296.184 107.65 296.197C107.838 296.197 108.117 296.197 108.479 296.197C109.489 296.213 110.496 296.296 111.495 296.446C112.993 296.664 114.464 297.041 115.883 297.57C117.623 298.233 119.245 299.173 120.686 300.352C121.426 300.971 122.096 301.669 122.684 302.433C123.254 303.14 123.759 303.897 124.192 304.695C124.935 306.026 125.423 307.483 125.632 308.993C125.779 310.013 125.712 311.053 125.436 312.046C125.366 312.307 125.27 312.559 125.15 312.8C125.119 312.879 125.081 312.954 125.037 313.027Z",
                fill: "#F5F5F5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.4",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M109.547 291.965C113.808 292.749 117.862 294.399 121.46 296.813C125.079 299.218 127.867 302.68 129.445 306.728C131.021 310.792 130.787 316.176 129.121 319.546L134.715 320.006C136.6 313.733 134.55 306.027 130.026 301.111C127.435 298.247 124.276 295.954 120.75 294.379C117.224 292.804 113.409 291.982 109.547 291.965Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M152.582 287.955C152.582 288.046 134.795 288.114 112.861 288.114C90.9275 288.114 73.1406 288.046 73.1406 287.955C73.1406 287.865 90.9275 287.797 112.861 287.797C134.795 287.797 152.582 287.872 152.582 287.955Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M152.618 285.159C153.421 284.137 153.918 282.908 154.051 281.615C154.172 279.625 153.297 277.137 151.133 277.137H123.808C122.755 277.137 121.712 277.344 120.739 277.748C119.766 278.151 118.882 278.742 118.138 279.487C117.393 280.232 116.803 281.116 116.401 282.09C115.999 283.063 115.792 284.106 115.793 285.159H152.618Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M188.653 256.476L183.895 246.569C183.26 245.209 183.154 243.661 183.599 242.228C184.044 240.795 185.007 239.579 186.3 238.818L200.506 230.343C201.249 229.898 202.098 229.664 202.964 229.664H206.032L207.269 249.69L202.526 251.545L205.542 256.416L188.653 256.476Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M206.078 230.387C206.078 230.387 210.941 231.503 211.552 238.997C212.163 246.492 207.269 248.799 207.269 248.799L206.078 230.387Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M206.077 230.386C206.11 230.517 206.128 230.651 206.129 230.786L206.22 231.864C206.303 232.844 206.401 234.171 206.529 235.8C206.785 239.117 207.125 243.679 207.457 248.814L207.178 248.648C207.7 248.362 208.18 248.004 208.603 247.585C209.566 246.653 210.299 245.509 210.744 244.244C211.165 243.065 211.392 241.825 211.415 240.572C211.494 238.437 211.084 236.312 210.216 234.359C209.609 233.054 208.664 231.935 207.479 231.117C207.036 230.824 206.566 230.572 206.077 230.363C206.216 230.372 206.354 230.403 206.484 230.454C206.86 230.588 207.221 230.76 207.562 230.966C208.816 231.755 209.822 232.882 210.465 234.216C211.393 236.198 211.842 238.37 211.777 240.557C211.763 241.842 211.537 243.116 211.106 244.327C210.633 245.651 209.859 246.846 208.844 247.818C208.396 248.263 207.888 248.644 207.336 248.949L207.072 249.085V248.783C206.74 243.558 206.484 238.906 206.318 235.596C206.243 233.99 206.175 232.678 206.129 231.705L206.084 230.672C206.074 230.577 206.072 230.481 206.077 230.386Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M188.576 242.925C188.576 242.925 175.629 249.063 174.046 250.035C172.953 250.737 172.01 251.958 172.87 254.115C174.34 257.779 180.41 254.333 180.41 254.333L192.474 248.301C192.474 248.301 197.103 246.107 195.392 243.378C193.446 240.347 188.576 242.925 188.576 242.925Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M186.939 234.89C189.059 234.89 190.777 231.862 190.777 228.127C190.777 224.391 189.059 221.363 186.939 221.363C184.82 221.363 183.102 224.391 183.102 228.127C183.102 231.862 184.82 234.89 186.939 234.89Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M187.566 232.778L189.678 240.084C190.063 239.891 190.37 239.572 190.549 239.179C190.727 238.787 190.766 238.345 190.658 237.928C190.13 235.424 189.828 233.645 189.248 231.451C189.18 231.232 187.566 232.778 187.566 232.778Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M145.839 321.221C145.628 320.618 145.417 320.007 145.213 319.374C145.009 318.741 144.806 318.175 144.647 317.587C144.401 316.685 144.224 315.764 144.12 314.835C140.561 329.319 145.99 339.521 155.324 340.237C168.949 341.285 185.567 342.047 192.27 340.282C204.523 337.07 209.016 326.854 210.087 325.202C211.158 323.551 220.907 305.704 214.935 288.558C208.964 271.412 198.558 253.195 198.551 253.195L188.636 256.505C188.636 256.505 190.453 264.973 193.326 275.107C196.485 286.243 200.722 303.676 200.481 313.862C200.326 319.991 198.347 325.935 194.796 330.933H149.775C149.775 330.933 148.81 329.968 145.839 321.251",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M50.2781 313.509L50.5948 310.07L132.781 319.541C133.88 319.67 134.94 320.023 135.898 320.578C136.856 321.132 137.69 321.876 138.35 322.764C139.01 323.652 139.482 324.665 139.736 325.742C139.991 326.819 140.023 327.936 139.831 329.026L139.461 331.107L54.4025 318.741C53.1757 318.563 52.0641 317.921 51.2968 316.947C50.5294 315.974 50.1648 314.743 50.2781 313.509Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M50.2781 313.509L50.5948 310.07L132.781 319.541C133.88 319.67 134.94 320.023 135.898 320.578C136.856 321.132 137.69 321.876 138.35 322.764C139.01 323.652 139.482 324.665 139.736 325.742C139.991 326.819 140.023 327.936 139.831 329.026L139.461 331.107L54.4025 318.741C53.1757 318.563 52.0641 317.921 51.2968 316.947C50.5294 315.974 50.1648 314.743 50.2781 313.509Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M210.102 336.505C210.102 336.505 228.198 316.607 231.93 300.954C233.805 300.944 235.679 301.083 237.532 301.368C237.532 301.368 226.825 330.458 210.102 336.505Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M231.664 293.941C231.714 294.106 231.746 294.275 231.762 294.447C231.807 294.778 231.906 295.261 231.973 295.902C232.139 297.701 232.091 299.513 231.83 301.3C231.412 303.955 230.606 306.533 229.44 308.954C228.009 311.895 226.41 314.752 224.652 317.511C221.499 322.555 217.957 327.345 214.058 331.837C212.588 333.579 211.374 334.967 210.522 335.917L209.549 337.01C209.44 337.143 209.319 337.267 209.188 337.379C209.278 337.235 209.381 337.098 209.497 336.972L210.432 335.841L213.892 331.694C217.728 327.177 221.233 322.389 224.381 317.368C226.132 314.616 227.735 311.771 229.184 308.848C230.345 306.462 231.162 303.923 231.611 301.308C231.894 299.536 231.972 297.737 231.845 295.947C231.808 295.314 231.725 294.824 231.702 294.492C231.674 294.31 231.661 294.126 231.664 293.941Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M200.385 336.361C198.383 334.694 196.52 332.869 194.812 330.902C195.846 331.696 196.814 332.571 197.708 333.519C198.676 334.392 199.571 335.342 200.385 336.361Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M146.684 335.75C146.972 334.819 147.421 333.946 148.011 333.171C148.518 332.341 149.16 331.602 149.911 330.984C149.986 331.045 149.157 332.04 148.275 333.344C147.392 334.649 146.767 335.787 146.684 335.75Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M111.915 347.244C112.904 346.341 113.737 345.281 114.381 344.107C115.058 342.825 115.47 341.42 115.595 339.976C115.779 338.215 115.472 336.438 114.708 334.841C113.944 333.244 112.753 331.889 111.267 330.928C110.068 330.112 108.716 329.548 107.293 329.269C105.976 329.028 104.628 329.01 103.305 329.216C103.305 329.216 103.395 329.178 103.576 329.133C103.823 329.064 104.075 329.014 104.33 328.982C105.318 328.846 106.321 328.869 107.301 329.05C108.761 329.308 110.153 329.865 111.388 330.686C112.935 331.665 114.174 333.062 114.963 334.715C115.751 336.368 116.056 338.209 115.844 340.028C115.705 341.506 115.261 342.939 114.539 344.236C114.063 345.109 113.452 345.903 112.73 346.588C112.481 346.837 112.247 346.988 112.111 347.108C112.052 347.161 111.986 347.207 111.915 347.244Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M81.9004 340.938C81.6966 339.987 81.598 339.016 81.6064 338.043C81.5062 337.073 81.5062 336.095 81.6064 335.125C81.8105 336.079 81.9091 337.052 81.9004 338.028C82.0048 338.995 82.0048 339.971 81.9004 340.938Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M84.0803 340.946C83.8039 340.002 83.627 339.031 83.5525 338.05C83.3795 337.083 83.3062 336.1 83.3338 335.117C83.6154 336.06 83.7924 337.031 83.8616 338.013C84.0436 338.979 84.117 339.963 84.0803 340.946Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M117.98 285.158C117.98 285.241 107.99 285.317 95.6619 285.317C83.334 285.317 73.3359 285.241 73.3359 285.158C73.3359 285.075 83.334 285 95.6619 285C107.99 285 117.98 285.068 117.98 285.158Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M65.6512 354.841C65.5535 354.764 65.465 354.675 65.3873 354.577C65.2289 354.396 64.9726 354.133 64.686 353.763C63.8408 352.741 63.084 351.649 62.424 350.498C60.2432 346.687 59.1041 342.368 59.1213 337.976C59.1385 333.585 60.3114 329.275 62.5221 325.481C63.1811 324.334 63.9379 323.247 64.7841 322.231C65.0706 321.861 65.3345 321.605 65.4928 321.424C65.5741 321.327 65.665 321.239 65.7643 321.16C65.7009 321.267 65.6277 321.368 65.5456 321.462C65.3948 321.658 65.1535 321.929 64.8821 322.306C64.0799 323.342 63.3589 324.439 62.7256 325.586C60.5931 329.367 59.4638 333.631 59.4454 337.972C59.4269 342.313 60.5198 346.586 62.6201 350.385C63.248 351.538 63.9612 352.642 64.7539 353.688C65.0178 354.072 65.2591 354.336 65.4023 354.54C65.4971 354.63 65.5807 354.731 65.6512 354.841Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M149.918 345.041C149.918 345.041 150.612 361.169 150.627 361.946L154.05 364.54L162.261 362.496L161.507 344.672L149.918 345.041Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M172.538 203.139L181.127 207.731L195.49 197.258L199.667 204.466C199.667 204.466 190.921 212.903 187.814 215.776C184.708 218.649 182.672 220.179 180.403 219.735C178.133 219.29 165.496 212.27 165.496 212.27C165.496 212.27 169.176 203.29 172.538 203.139Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M181.172 210.927C181.172 210.927 181.225 210.979 181.255 211.07V211.145H181.066V211.077V210.851C181.014 210.421 180.987 209.988 180.984 209.554C180.912 208.934 180.966 208.306 181.142 207.707C181.353 208.296 181.433 208.924 181.376 209.547C181.376 210.052 181.376 210.512 181.338 210.851V211.077V211.145C180.946 211.145 181.225 211.145 181.142 211.145V211.062C181.119 210.979 181.149 210.927 181.172 210.927Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M197.277 206.425C197.563 206.516 200.24 203.628 200.24 203.628C200.24 203.628 205.254 203.538 206.453 202.874C207.652 202.211 209.469 199.737 209.469 199.737L207.049 192.363C204.81 192.51 202.582 192.787 200.376 193.193C198.777 193.638 194.954 197.641 194.954 197.641L193.311 200.197C193.311 200.197 192.798 205.046 197.277 206.425Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M205.754 203.287C206.369 203.243 206.98 203.165 207.586 203.053C208.793 202.85 210.037 202.744 209.999 201.545C210.002 201.347 209.963 201.149 209.884 200.967C209.804 200.785 209.687 200.622 209.539 200.49C209.539 200.49 210.429 200.12 210.421 199.449C210.419 199.254 210.371 199.062 210.281 198.889C210.19 198.716 210.06 198.567 209.901 198.454C209.901 198.454 211.13 197.888 211.168 196.893C211.173 196.525 211.075 196.163 210.886 195.848C210.697 195.532 210.424 195.275 210.097 195.106C210.097 195.106 213.867 194.028 214.169 193.907C215.239 193.47 217.283 192.497 216.431 191.698C216.121 191.404 216.001 191.08 213.844 191.344C211.884 191.577 208.8 192.301 208.8 192.301C208.8 192.301 206.161 192.429 204.774 192.573C203.054 192.73 201.351 193.035 199.684 193.485C197.905 194.307 196.352 196.644 196.352 196.644L200.265 203.626L205.754 203.287Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M209.242 200.461C208.89 200.413 208.534 200.392 208.179 200.4H207.025C206.797 200.382 206.568 200.382 206.339 200.4C206.078 200.433 205.835 200.55 205.646 200.732C205.542 200.825 205.466 200.944 205.426 201.077C205.386 201.21 205.384 201.352 205.419 201.486C205.496 201.722 205.661 201.919 205.879 202.036C206.058 202.147 206.247 202.238 206.445 202.308L206.943 202.496C207.259 202.609 207.508 202.685 207.697 202.73C207.885 202.775 207.975 202.798 207.975 202.783C207.975 202.768 207.598 202.632 206.995 202.391C206.641 202.257 206.298 202.096 205.97 201.908C205.788 201.806 205.651 201.639 205.585 201.441C205.561 201.336 205.565 201.226 205.598 201.124C205.632 201.022 205.692 200.93 205.774 200.86C205.938 200.704 206.146 200.601 206.369 200.566C206.59 200.548 206.812 200.548 207.033 200.566H208.187C208.541 200.559 208.894 200.524 209.242 200.461Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M205.126 195.31C205.519 195.143 205.865 194.885 206.137 194.556C206.454 194.274 206.695 193.916 206.838 193.516C206.8 193.516 206.491 193.953 206.016 194.443C205.541 194.933 205.096 195.272 205.126 195.31Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M201.942 193.57C202.941 193.811 203.85 194.334 204.559 195.078C205.26 195.82 205.844 196.664 206.293 197.582C206.67 198.336 206.994 199.203 206.579 199.904C206.327 200.247 205.957 200.486 205.54 200.575C205.123 200.664 204.688 200.597 204.317 200.386C203.594 199.95 203.024 199.299 202.689 198.524C202.356 197.752 201.931 197.022 201.422 196.353",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M201.477 196.346C201.477 196.346 201.612 196.519 201.831 196.866C202.107 197.356 202.359 197.859 202.585 198.374C202.755 198.738 202.957 199.086 203.188 199.414C203.452 199.801 203.797 200.125 204.199 200.364C204.656 200.625 205.194 200.703 205.707 200.583C205.989 200.52 206.249 200.382 206.461 200.183C206.664 199.978 206.799 199.715 206.845 199.429C206.898 198.869 206.785 198.305 206.521 197.808C206.294 197.352 206.042 196.909 205.767 196.481C205.315 195.748 204.744 195.096 204.078 194.551C203.627 194.186 203.117 193.9 202.57 193.707C202.421 193.652 202.267 193.612 202.11 193.586C202.004 193.586 201.952 193.586 201.952 193.586C201.952 193.586 202.17 193.646 202.547 193.79C203.077 194.004 203.57 194.299 204.01 194.664C204.657 195.211 205.21 195.861 205.646 196.587C205.908 197.011 206.147 197.449 206.362 197.899C206.611 198.36 206.718 198.885 206.672 199.407C206.633 199.662 206.517 199.898 206.34 200.085C206.156 200.259 205.93 200.381 205.684 200.44C205.21 200.559 204.707 200.492 204.281 200.251C203.898 200.023 203.567 199.718 203.309 199.354C203.078 199.034 202.874 198.696 202.698 198.344C202.45 197.824 202.171 197.321 201.861 196.836C201.748 196.67 201.642 196.549 201.575 196.466C201.507 196.383 201.477 196.338 201.477 196.346Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M209.129 200.46C207.583 200.461 206.038 200.542 204.5 200.702C204.06 200.782 203.607 200.743 203.188 200.588C202.864 200.43 202.743 199.616 202.66 199.269L208.33 198.387",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M208.331 198.387C208.184 198.386 208.038 198.398 207.893 198.424L206.687 198.59L202.645 199.186H202.562V199.277C202.623 199.533 202.676 199.819 202.766 200.098C202.802 200.215 202.853 200.326 202.917 200.43C202.948 200.483 202.986 200.531 203.03 200.573C203.079 200.617 203.135 200.653 203.196 200.679C203.41 200.763 203.637 200.804 203.867 200.8C204.312 200.8 204.719 200.739 205.111 200.709C205.865 200.641 206.619 200.581 207.192 200.543C207.765 200.506 208.263 200.49 208.602 200.475C208.773 200.488 208.944 200.488 209.115 200.475C208.945 200.447 208.774 200.434 208.602 200.438C208.263 200.438 207.78 200.438 207.185 200.438C206.589 200.438 205.88 200.506 205.096 200.566C204.704 200.566 204.289 200.649 203.874 200.641C203.665 200.646 203.457 200.608 203.264 200.528C203.083 200.468 203 200.257 202.924 200.053C202.849 199.85 202.789 199.51 202.728 199.246L202.661 199.344C204.259 199.096 205.677 198.862 206.687 198.688L207.886 198.477C208.036 198.459 208.185 198.429 208.331 198.387Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M209.984 198.072L204.08 199.203C203.666 199.307 203.238 199.34 202.813 199.301C202.602 199.28 202.399 199.207 202.223 199.088C202.046 198.97 201.902 198.81 201.803 198.622C201.716 198.345 201.723 198.047 201.822 197.775C201.922 197.502 202.108 197.27 202.353 197.114C202.858 196.814 203.421 196.624 204.004 196.556C205.799 196.203 207.564 195.712 209.282 195.086",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M209.263 195.062C209.204 195.071 209.146 195.086 209.09 195.108L208.6 195.266C208.177 195.394 207.567 195.59 206.805 195.794C206.044 195.997 205.124 196.231 204.098 196.435C203.545 196.507 203.005 196.665 202.5 196.902C202.229 197.044 202.002 197.258 201.844 197.521C201.669 197.793 201.599 198.12 201.648 198.44C201.685 198.599 201.755 198.749 201.853 198.879C201.952 199.009 202.077 199.116 202.221 199.194C202.489 199.341 202.79 199.416 203.096 199.413C203.647 199.373 204.194 199.29 204.732 199.164L207.469 198.621L209.308 198.244L209.806 198.131L209.98 198.079C209.92 198.07 209.859 198.07 209.799 198.079L209.293 198.161L207.446 198.486L204.702 198.998C204.173 199.119 203.636 199.198 203.096 199.232C202.819 199.236 202.546 199.169 202.304 199.036C202.181 198.97 202.074 198.879 201.99 198.768C201.905 198.658 201.845 198.531 201.814 198.395C201.773 198.117 201.834 197.833 201.987 197.596C202.13 197.361 202.333 197.168 202.575 197.038C203.066 196.806 203.59 196.651 204.128 196.578C205.154 196.367 206.074 196.126 206.835 195.907C207.597 195.688 208.208 195.47 208.622 195.319L209.097 195.13L209.263 195.062Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M198.172 199.52C198.172 199.52 198.255 199.693 198.481 199.897C198.784 200.15 199.139 200.332 199.522 200.432C199.903 200.535 200.302 200.551 200.69 200.477C200.984 200.417 201.15 200.334 201.143 200.311C200.619 200.395 200.085 200.382 199.567 200.274C199.057 200.115 198.583 199.859 198.172 199.52Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M166.227 241.289C166.227 241.289 180.553 243.936 181.548 244.207C182.543 244.478 186.637 246.409 186.826 247.645C186.935 249.272 186.935 250.904 186.826 252.531C186.826 252.531 186.072 253.127 185.635 251.936C185.332 250.777 185.202 249.58 185.25 248.384L182.988 247.51L184.225 249.711L184.428 254.869C184.428 254.869 182.845 254.725 182.536 253.489C182.341 252.633 182.24 251.758 182.234 250.88L180.575 249.478L181.819 251.159L182.234 254.869C182.234 254.869 181.028 255.261 180.643 254.439C180.368 253.367 180.231 252.265 180.236 251.159L175.561 249.523L172.47 251.249L169.114 249.41C168.645 249.15 168.238 248.791 167.923 248.357C167.608 247.923 167.392 247.425 167.29 246.899L166.227 241.289Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M137.62 170.114L138.095 195.109C138.132 197.075 138.912 198.954 140.279 200.369C141.646 201.783 143.497 202.627 145.461 202.732C146.524 202.786 147.586 202.622 148.583 202.25C149.58 201.878 150.49 201.305 151.257 200.568C152.024 199.83 152.631 198.943 153.041 197.961C153.451 196.979 153.656 195.924 153.642 194.86C153.642 192.477 153.567 190.532 153.567 190.532C153.567 190.532 159.644 189.906 160.036 183.882C160.255 180.398 160.036 172.466 159.863 166.389C159.797 164.4 158.984 162.509 157.587 161.092C156.19 159.676 154.31 158.837 152.323 158.743L148.681 158.555C147.19 158.57 145.718 158.883 144.35 159.476C142.982 160.068 141.747 160.928 140.716 162.005C139.686 163.082 138.881 164.354 138.349 165.747C137.817 167.139 137.569 168.624 137.62 170.114Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M153.568 190.472C150.785 190.317 148.103 189.37 145.84 187.742C145.84 187.742 147.551 192.266 153.599 191.995L153.568 190.472Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M158.43 172.05C158.325 172.163 157.676 171.643 156.764 171.598C155.852 171.552 155.135 171.982 155.045 171.862C154.954 171.741 155.113 171.613 155.422 171.409C155.839 171.156 156.322 171.035 156.809 171.062C157.292 171.086 157.754 171.263 158.129 171.568C158.4 171.794 158.491 172.005 158.43 172.05Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M149.512 174.033C149.504 174.258 149.408 174.472 149.244 174.627C149.081 174.782 148.863 174.867 148.637 174.863C148.527 174.865 148.418 174.845 148.316 174.805C148.213 174.764 148.12 174.704 148.041 174.628C147.962 174.552 147.898 174.461 147.855 174.36C147.811 174.259 147.787 174.151 147.785 174.041C147.793 173.815 147.889 173.602 148.053 173.447C148.216 173.292 148.434 173.207 148.66 173.211C148.77 173.208 148.88 173.227 148.982 173.267C149.085 173.307 149.179 173.367 149.258 173.443C149.338 173.52 149.401 173.611 149.444 173.713C149.488 173.814 149.511 173.923 149.512 174.033Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M157.949 174.033C157.941 174.258 157.845 174.472 157.682 174.627C157.518 174.782 157.3 174.867 157.075 174.863C156.965 174.866 156.855 174.847 156.752 174.807C156.649 174.767 156.556 174.707 156.476 174.63C156.397 174.554 156.334 174.462 156.29 174.361C156.247 174.26 156.224 174.151 156.223 174.041C156.231 173.815 156.327 173.602 156.49 173.447C156.654 173.292 156.872 173.207 157.097 173.211C157.207 173.208 157.317 173.227 157.42 173.267C157.523 173.307 157.616 173.367 157.696 173.443C157.775 173.52 157.838 173.611 157.882 173.713C157.925 173.814 157.948 173.923 157.949 174.033Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M149.483 171.718C149.37 171.824 148.729 171.304 147.817 171.258C146.904 171.213 146.188 171.643 146.09 171.522C145.992 171.402 146.165 171.274 146.474 171.078C146.888 170.817 147.374 170.693 147.862 170.723C148.344 170.746 148.807 170.923 149.181 171.228C149.453 171.462 149.536 171.666 149.483 171.718Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M152.405 179.091C152.897 178.964 153.404 178.898 153.913 178.895C154.146 178.895 154.38 178.85 154.425 178.692C154.455 178.449 154.413 178.202 154.305 177.983L153.686 176.143C153.117 174.583 152.673 172.979 152.359 171.348C153.054 172.858 153.626 174.421 154.071 176.022C154.275 176.671 154.463 177.282 154.652 177.87C154.785 178.163 154.809 178.495 154.719 178.805C154.681 178.887 154.625 178.96 154.554 179.018C154.484 179.075 154.401 179.116 154.312 179.136C154.18 179.154 154.045 179.154 153.913 179.136C153.41 179.183 152.904 179.168 152.405 179.091Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M149.64 179.59C149.798 179.59 149.745 180.6 150.567 181.354C151.389 182.108 152.467 182.056 152.467 182.199C152.467 182.342 152.218 182.38 151.766 182.372C151.176 182.348 150.613 182.119 150.175 181.724C149.755 181.33 149.502 180.79 149.466 180.216C149.451 179.824 149.572 179.582 149.64 179.59Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M149.593 168.355C149.488 168.596 148.575 168.43 147.475 168.505C146.374 168.581 145.492 168.83 145.356 168.596C145.296 168.49 145.461 168.257 145.831 168.03C146.317 167.752 146.862 167.592 147.422 167.563C147.982 167.525 148.543 167.62 149.058 167.842C149.45 168.023 149.639 168.234 149.593 168.355Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M158.153 168.705C157.979 168.908 157.353 168.652 156.584 168.607C155.815 168.561 155.159 168.674 155.024 168.441C154.963 168.335 155.076 168.132 155.37 167.943C155.763 167.724 156.213 167.627 156.662 167.664C157.11 167.702 157.538 167.872 157.889 168.154C158.153 168.38 158.213 168.607 158.153 168.705Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M139.421 174.711C139.323 174.659 135.342 173.271 135.259 177.396C135.176 181.52 139.361 180.758 139.361 180.668C139.361 180.578 139.421 174.711 139.421 174.711Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M138.117 179.048C138.117 179.048 138.05 179.101 137.921 179.154C137.749 179.219 137.558 179.219 137.386 179.154C137.13 178.974 136.926 178.731 136.794 178.448C136.661 178.164 136.606 177.852 136.632 177.54C136.631 177.187 136.705 176.837 136.851 176.515C136.893 176.386 136.965 176.269 137.063 176.174C137.16 176.08 137.279 176.01 137.409 175.972C137.491 175.952 137.577 175.962 137.653 175.999C137.728 176.036 137.789 176.098 137.823 176.175C137.876 176.296 137.823 176.379 137.876 176.386C137.929 176.394 137.967 176.319 137.936 176.145C137.913 176.043 137.857 175.95 137.778 175.881C137.664 175.795 137.521 175.755 137.378 175.768C137.211 175.802 137.054 175.877 136.923 175.986C136.791 176.095 136.688 176.235 136.624 176.394C136.439 176.747 136.345 177.141 136.353 177.54C136.325 177.908 136.406 178.275 136.586 178.597C136.766 178.919 137.036 179.181 137.363 179.35C137.475 179.381 137.591 179.389 137.706 179.372C137.82 179.355 137.93 179.314 138.027 179.252C138.11 179.161 138.132 179.056 138.117 179.048Z",
                fill: "#EB996E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M137.139 174.447C137.532 174.444 137.919 174.546 138.259 174.744C138.598 174.941 138.878 175.227 139.07 175.571C139.303 176.174 139.333 176.845 139.567 177.448C139.658 177.759 139.849 178.031 140.111 178.22C140.373 178.41 140.691 178.507 141.015 178.496C141.233 178.44 141.432 178.328 141.592 178.17C141.752 178.013 141.868 177.815 141.927 177.599C142.038 177.166 142.066 176.715 142.01 176.272C141.859 174.334 141.558 172.404 141.58 170.458C141.523 168.503 142.048 166.574 143.088 164.916C143.618 164.098 144.358 163.438 145.231 163.005C146.104 162.573 147.078 162.384 148.05 162.458C149.324 162.624 150.462 163.356 151.729 163.605C152.477 163.738 153.245 163.7 153.976 163.495C154.707 163.291 155.382 162.923 155.952 162.421C156.102 162.293 156.766 161.9 156.766 161.9C156.772 161.441 156.644 160.991 156.396 160.604C153.991 158.138 149.475 157.248 146.097 157.919C144.38 158.247 142.755 158.945 141.336 159.964C139.916 160.984 138.736 162.301 137.878 163.823C136.28 166.877 136.483 171.25 137.124 174.447",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M154.9 161.239C152.638 161.322 148.257 162.167 146.455 163.569C146.244 163.735 146.01 164.006 146.153 164.24C146.297 164.474 146.508 164.421 146.711 164.414C148.804 164.52 150.88 164.836 152.909 165.356C154.201 165.812 155.567 166.02 156.936 165.967C157.619 165.929 158.282 165.715 158.858 165.345C159.434 164.975 159.905 164.462 160.223 163.856L160.804 164.074C160.143 163.137 159.254 162.385 158.221 161.889C157.187 161.392 156.044 161.169 154.9 161.239Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M159.631 164.013C158.401 162.856 156.824 162.135 155.144 161.962C149.927 161.487 141.361 163.055 136.822 172.02C136.328 170.469 136.019 168.864 135.902 167.24C135.902 166.011 136.656 158.705 144.196 156.443C144.211 156.443 155.567 152.168 159.631 164.013Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.3",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M159.631 164.013C158.323 162.616 156.521 161.785 154.609 161.698C149.934 161.472 141.097 163.568 136.822 172.02C136.328 170.469 136.019 168.864 135.902 167.24C135.902 166.011 136.656 158.705 144.196 156.443C144.211 156.443 155.567 152.168 159.631 164.013Z",
                    fill: "black"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M137.53 170.744C139.792 166.974 143.185 164.373 146.842 162.111C150.499 159.849 156.523 157.64 160.678 156.554C161.908 156.157 163.209 156.029 164.493 156.177C165.133 156.26 165.736 156.523 166.233 156.933C166.731 157.344 167.102 157.887 167.305 158.499C167.697 160.068 164.908 162.465 163.596 163.408C162.381 164.217 161.123 164.957 159.826 165.625C159.826 165.625 159.675 162.82 155.03 162.209C148.704 161.38 137.334 170.903 137.53 170.744Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M146.148 159.174C147.526 158.525 148.966 158.02 150.446 157.666C151.942 157.435 153.458 157.351 154.97 157.417C154.545 157.262 154.096 157.18 153.643 157.175C152.549 157.088 151.448 157.149 150.371 157.356C149.297 157.567 148.257 157.922 147.279 158.412C146.864 158.604 146.483 158.861 146.148 159.174Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M162.369 361.492L162.414 362.201C162.414 362.201 175.232 366.476 175.526 368.746L150.674 369.696L150.523 361.756C152.409 362.533 154.435 362.91 156.474 362.865C158.512 362.819 160.52 362.352 162.369 361.492Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M150.671 369.697L150.633 367.789L174.444 367.57C174.444 367.57 175.575 367.993 175.5 368.747L150.671 369.697Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M162.502 362.261C162.502 362.374 161.906 362.45 161.333 362.849C160.76 363.249 160.474 363.746 160.353 363.709C160.232 363.671 160.353 362.955 161.107 362.517C161.861 362.08 162.524 362.155 162.502 362.261Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M165.172 363.196C165.21 363.309 164.697 363.52 164.313 364.033C163.928 364.546 163.845 365.066 163.724 365.066C163.604 365.066 163.483 364.41 163.973 363.784C164.463 363.159 165.165 363.083 165.172 363.196Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M166.836 366.155C166.723 366.155 166.52 365.604 166.791 364.956C167.063 364.307 167.621 364.036 167.673 364.126C167.726 364.217 167.402 364.579 167.183 365.114C166.965 365.649 166.957 366.155 166.836 366.155Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M164.357 305.99L160.15 291.966L154.547 274.111L154.856 264.92L145.477 258.458C139.347 258.563 121.484 257.508 121.484 257.508C121.484 257.508 121.944 266.827 122.864 273.538C123.051 274.869 123.544 276.139 124.304 277.248L132.53 289.244L146.676 315.634C146.676 315.634 147.618 325.059 148.01 333.202C148.447 342.325 149.918 358.838 149.918 358.838L164.47 359.185L165.382 322.631C165.752 317.142 166.159 311.193 164.357 305.99Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M173.367 305.547C175.041 306.904 176.542 325.354 173.782 324.012L177.062 327.111L185.838 325.603L187.052 306.218L173.367 305.547Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M148.559 250.406C148.559 250.406 184.917 260.299 188.687 268.125C190.206 270.688 190.916 273.65 190.723 276.623C190.504 281.901 187.503 319.85 187.503 319.85L173.773 318.945L172.453 304.943L172.227 283.748L173.185 281.335C172.134 281.578 171.04 281.565 169.995 281.298C168.434 280.838 144.744 273.667 144.744 273.667L135.492 259.085L148.559 250.406Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M186.051 324.541V325.295C186.051 325.295 198.93 331.048 198.93 333.528L172.984 332.442L173.693 323.824C175.581 324.824 177.662 325.405 179.794 325.529C181.927 325.652 184.061 325.315 186.051 324.541Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("g", {
                opacity: "0.6",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                    d: "M173.008 332.441L173.174 330.367L197.988 332.169C197.988 332.169 199.119 332.72 198.953 333.526L173.008 332.441Z",
                    fill: "white"
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M186.109 325.392C186.109 325.52 185.461 325.55 184.82 325.927C184.179 326.304 183.825 326.832 183.711 326.771C183.598 326.711 183.817 326.017 184.601 325.55C185.385 325.082 186.147 325.271 186.109 325.392Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M188.789 326.626C188.789 326.755 188.262 326.943 187.802 327.463C187.342 327.984 187.206 328.542 187.048 328.534C186.889 328.527 186.874 327.78 187.447 327.169C188.02 326.559 188.797 326.506 188.789 326.626Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M190.197 329.962C190.084 329.962 189.933 329.343 190.288 328.665C190.642 327.986 191.245 327.73 191.298 327.835C191.351 327.941 190.966 328.303 190.68 328.861C190.393 329.419 190.325 329.962 190.197 329.962Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M178.995 274.293C178.559 274.494 178.157 274.761 177.803 275.085C176.905 275.815 176.097 276.65 175.398 277.573C174.698 278.503 174.116 279.516 173.664 280.589C173.447 281.018 173.299 281.478 173.227 281.954C173.918 280.501 174.73 279.108 175.654 277.792C176.666 276.532 177.783 275.362 178.995 274.293Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M176.042 271.414C175.703 271.828 175.424 272.287 175.212 272.779C174.063 275.091 173.408 277.618 173.29 280.198C173.242 280.729 173.265 281.264 173.357 281.789C173.447 281.268 173.5 280.742 173.516 280.213C173.634 278.942 173.85 277.681 174.164 276.443C174.481 275.214 174.895 274.011 175.401 272.847C175.643 272.382 175.857 271.904 176.042 271.414Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M151.689 266.027C151.787 266.027 153.431 270.551 155.353 276.131C157.276 281.711 158.754 286.325 158.648 286.363C158.543 286.4 156.907 281.876 154.984 276.259C153.061 270.642 151.583 266.065 151.689 266.027Z",
                fill: "#455A64"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M157.234 199.308L163.168 196.926L178.648 205.333L172.329 219.795L158.705 213.031L157.234 199.308Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M163.169 196.924L153.759 193.365C153.759 193.365 151.7 197.716 147.199 196.381C142.697 195.046 137.736 191.035 137.736 191.035C137.736 191.035 129.178 194.428 126.569 195.974C123.961 197.52 122.551 237.625 122.551 237.625L121.842 253.142L121.42 256.068C121.24 257.468 121.146 258.878 121.141 260.29C137.088 263.872 152.854 260.079 161.306 255.389C161.306 255.389 162.422 254.514 161.94 252.516C161.457 250.518 160.432 250.171 160.432 250.171L160.643 232.633L162.211 214.696L163.169 196.924Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M171.589 242.286L150.417 233.524L137.297 204.473L125.625 209.374C125.625 209.374 138.156 240.876 143.02 243.492C147.883 246.109 167.939 247.315 167.939 247.315L171.589 242.286Z",
                fill: "#FFBE9D"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M126.544 195.974C126.544 195.974 122.133 198.183 122.141 206.628C122.141 213.964 124.305 225.658 124.305 225.658L145.085 218.428L138.661 203.498C137.153 199.94 133.805 193.395 126.544 195.974Z",
                fill: theme.palette.primary.main
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M126.703 224.832C126.815 224.773 126.931 224.723 127.05 224.681L128.068 224.289L131.891 222.901L145.048 218.249L144.935 218.491C144.279 216.515 143.563 214.404 142.778 212.255C141.542 208.87 140.253 205.695 138.933 202.868C138.35 201.522 137.641 200.234 136.814 199.022C136.116 197.962 135.144 197.11 134.002 196.557C132.314 195.791 130.456 195.477 128.611 195.644C128.114 195.701 127.628 195.834 127.171 196.036C127.021 196.134 126.865 196.219 126.703 196.293C126.703 196.293 126.703 196.255 126.809 196.202C126.908 196.113 127.017 196.034 127.133 195.969C127.586 195.725 128.079 195.564 128.588 195.494C130.469 195.261 132.379 195.54 134.115 196.3C135.313 196.862 136.337 197.738 137.078 198.834C137.93 200.054 138.66 201.354 139.257 202.717C140.607 205.544 141.904 208.749 143.148 212.119C143.902 214.276 144.656 216.387 145.289 218.37L145.35 218.551L145.176 218.611L131.974 223.135L128.113 224.417L127.073 224.749C126.954 224.793 126.829 224.821 126.703 224.832Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M159.479 250.789C159.157 251.092 158.811 251.369 158.446 251.618C158.107 251.875 157.692 252.184 157.172 252.501C156.652 252.817 156.086 253.217 155.415 253.571C154.744 253.926 154.013 254.325 153.191 254.717C152.369 255.109 151.494 255.471 150.552 255.841C148.492 256.59 146.374 257.168 144.218 257.568C142.058 257.927 139.871 258.103 137.681 258.095C136.671 258.095 135.706 258.05 134.816 257.937C133.987 257.874 133.161 257.769 132.343 257.62C131.589 257.515 130.918 257.341 130.322 257.213C129.726 257.085 129.229 256.942 128.814 256.814C128.385 256.707 127.966 256.564 127.562 256.384C127.998 256.446 128.429 256.539 128.852 256.663C129.267 256.768 129.764 256.896 130.36 256.994C130.955 257.093 131.619 257.258 132.373 257.341C133.127 257.424 133.949 257.568 134.839 257.613C135.728 257.658 136.671 257.711 137.674 257.733C139.842 257.723 142.005 257.537 144.143 257.175C146.278 256.787 148.379 256.227 150.424 255.502C151.351 255.132 152.248 254.808 153.048 254.423C153.847 254.039 154.601 253.669 155.31 253.33C156.018 252.991 156.561 252.621 157.082 252.312C157.53 252.06 157.965 251.786 158.386 251.49C158.731 251.228 159.097 250.993 159.479 250.789Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M159.571 213.867H153.758V216.619H159.571V213.867Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M162.864 205.324C162.977 205.324 162.759 209.577 162.389 214.794C162.02 220.012 161.635 224.25 161.522 224.242C161.409 224.235 161.628 219.99 161.997 214.772C162.367 209.554 162.736 205.317 162.864 205.324Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M112.859 224.832H57.9375V236.828H112.859V224.832Z",
                fill: "#CE9E6C"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M116.561 236.953H54.2734V284.99H116.561V236.953Z",
                fill: "#CE9E6C"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M100.952 284.662C100.885 284.662 100.824 273.955 100.824 260.745C100.824 247.535 100.885 236.828 100.952 236.828C101.02 236.828 101.073 247.535 101.073 260.745C101.073 273.955 101.02 284.662 100.952 284.662Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M114.391 274.066H106.504V281.953H114.391V274.066Z",
                fill: "#F5F5F5"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.3",
                d: "M80.3069 236.953H73.2344V247.208H80.3069V236.953Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.3",
                d: "M80.346 274.746H73.2734V285H80.346V274.746Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.3",
                d: "M116.561 236.828H100.953V285.129H116.561V236.828Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M116.35 236.954C116.35 237.067 102.477 237.15 85.3683 237.15C68.26 237.15 54.3789 237.067 54.3789 236.954C54.3789 236.841 68.2525 236.758 85.3683 236.758C102.484 236.758 116.35 236.848 116.35 236.954Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                opacity: "0.3",
                d: "M112.858 224.832H97.4844V236.745H112.858V224.832Z",
                fill: "black"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M97.3641 236.667C97.1702 234.741 97.1047 232.804 97.168 230.869C97.1044 228.934 97.1699 226.997 97.3641 225.07C97.5627 226.996 97.6282 228.934 97.5601 230.869C97.6279 232.804 97.5624 234.741 97.3641 236.667Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M81.7949 224.832H74.0664V228.466H81.7949V224.832Z",
                fill: "white"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M84.8853 225.064C84.8755 225.007 84.8755 224.948 84.8853 224.891L84.9456 224.371C84.9984 223.926 85.0964 223.262 85.2774 222.41C85.7637 220.001 86.6862 217.701 87.9993 215.624C88.4497 214.939 88.954 214.291 89.5073 213.686C90.0691 212.993 90.7416 212.396 91.4979 211.922C91.9264 211.665 92.4249 211.549 92.9229 211.59C93.1855 211.635 93.4326 211.745 93.642 211.909C93.8514 212.074 94.0163 212.288 94.1218 212.533C94.4506 213.508 94.4743 214.56 94.1897 215.549C93.6332 217.657 92.4846 219.562 90.8796 221.038C89.1673 222.578 87.2853 223.919 85.2698 225.034L84.9909 225.2L84.8778 225.268L84.7722 225.192C82.9093 223.87 81.1453 222.413 79.4942 220.834C77.9461 219.354 76.67 217.614 75.7242 215.692C75.4837 215.237 75.3037 214.753 75.1889 214.252C75.066 213.749 75.111 213.219 75.317 212.744C75.419 212.5 75.5787 212.285 75.7823 212.117C75.9859 211.949 76.2273 211.833 76.4857 211.779C76.9861 211.727 77.4879 211.861 77.8957 212.156C78.2663 212.417 78.6054 212.721 78.9061 213.061C79.2077 213.377 79.4867 213.702 79.7581 214.018C80.2746 214.633 80.7579 215.275 81.2058 215.941C82.5747 217.944 83.6251 220.146 84.3198 222.471C84.5024 223.1 84.6509 223.74 84.7647 224.386L84.8401 224.891C84.8434 224.949 84.8434 225.007 84.8401 225.064C84.8401 225.064 84.8401 225.012 84.7873 224.898L84.6742 224.401C84.5762 223.963 84.4178 223.323 84.1615 222.516C83.4252 220.237 82.3609 218.078 81.0022 216.107C80.5532 215.453 80.07 214.824 79.5545 214.222C79.2831 213.905 79.0041 213.588 78.7025 213.287C78.4155 212.966 78.0915 212.68 77.7374 212.435C77.3997 212.19 76.9839 212.077 76.5687 212.118C76.3665 212.159 76.1775 212.25 76.0184 212.381C75.8593 212.513 75.735 212.681 75.6563 212.872C75.2718 213.686 75.6563 214.674 76.071 215.541C77.0069 217.442 78.2674 219.164 79.7958 220.631C81.4307 222.193 83.177 223.635 85.021 224.944H84.8024L85.0813 224.778C87.0711 223.676 88.9302 222.353 90.6232 220.834C92.1813 219.42 93.3013 217.588 93.8504 215.556C94.1343 214.64 94.1343 213.66 93.8504 212.744C93.767 212.548 93.6356 212.376 93.4682 212.244C93.3008 212.112 93.1029 212.025 92.8928 211.99C92.468 211.955 92.043 212.055 91.6788 212.276C90.9505 212.731 90.299 213.299 89.7486 213.958C89.1984 214.549 88.6943 215.182 88.2406 215.85C86.9215 217.886 85.9697 220.137 85.4282 222.501C85.2321 223.338 85.1115 224.009 85.0286 224.438L84.9381 224.944L84.8853 225.064Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M116.743 258.196C116.743 258.302 102.778 258.392 85.5646 258.392C68.3508 258.392 54.3867 258.302 54.3867 258.196C54.3867 258.09 68.3433 258 85.5646 258C102.786 258 116.743 258.083 116.743 258.196Z",
                fill: "#263238"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M85.0085 285.77C84.903 285.77 84.8125 272.033 84.8125 255.09C84.8125 238.148 84.903 224.402 85.0085 224.402C85.1141 224.402 85.2046 238.14 85.2046 255.09C85.2046 272.04 85.1216 285.77 85.0085 285.77Z",
                fill: "#263238"
            })
        ]
    });
};
SolutionSvg.propTypes = {};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (SolutionSvg)));


/***/ }),

/***/ 22137:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(99881);
/* harmony import */ var _mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(64845);
/* harmony import */ var _mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _CustomPopover__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(59652);
/* harmony import */ var _index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(30725);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CustomPopover__WEBPACK_IMPORTED_MODULE_5__, _index__WEBPACK_IMPORTED_MODULE_6__]);
([_CustomPopover__WEBPACK_IMPORTED_MODULE_5__, _index__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const CustomButtonComponent = (props)=>{
    const { landingPageData , title , t , urls  } = props;
    const customButtonRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const [anchorEl, setAnchorEl] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(null);
    const open = Boolean(anchorEl);
    const handleClick = (event)=>{
        setAnchorEl(event.currentTarget);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_index__WEBPACK_IMPORTED_MODULE_6__/* .CustomButton */ .o, {
                ref: customButtonRef,
                variant: "contained",
                onClick: (e)=>handleClick(e),
                children: [
                    title,
                    open === true ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowUp__WEBPACK_IMPORTED_MODULE_3___default()), {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_KeyboardArrowDown__WEBPACK_IMPORTED_MODULE_4___default()), {})
                ]
            }),
            open && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomPopover__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                t: t,
                urls: urls,
                openPopover: open,
                anchorEl: anchorEl,
                handleClose: ()=>setAnchorEl(null),
                landingPageData: landingPageData,
                width: `${customButtonRef?.current?.offsetWidth}px`
            })
        ]
    });
};
CustomButtonComponent.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomButtonComponent);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 59652:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(86201);
/* harmony import */ var _CustomDivider__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(35740);
/* harmony import */ var _assets_AppleLogo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(56085);
/* harmony import */ var _assets_PlayStoreIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(62820);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_6__]);
react_hot_toast__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const ItemWrapper = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_3__.Box)(({ theme  })=>({
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        padding: "12px",
        position: "relative",
        gap: "10px",
        cursor: "pointer"
    }));
const Item = ({ image , title , link , t  })=>{
    const [hover, setHover] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const handleClick = ()=>{
        if (link) {
            router.push(link);
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_6__.toast.error(t("No Redirect Url found"));
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ItemWrapper, {
        onMouseEnter: ()=>setHover(true),
        onMouseLeave: ()=>setHover(false),
        onClick: handleClick,
        children: [
            image,
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                color: hover ? "primary" : "text.secondary",
                children: title
            })
        ]
    });
};
const CustomPopover = (props)=>{
    const { width , openPopover , handleClose , anchorEl , t , urls  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.ClickAwayListener, {
        onClickAway: handleClose,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Popper, {
            open: openPopover,
            anchorEl: anchorEl,
            placement: "bottom",
            onClose: handleClose,
            disablePortal: false,
            modifiers: {
                flip: {
                    enabled: false
                },
                preventOverflow: {
                    enabled: true,
                    boundariesElement: "scrollParent"
                }
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Paper, {
                sx: {
                    marginTop: "6px",
                    width: width
                },
                children: [
                    urls?.playStoreStatus === "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                        image: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_PlayStoreIcon__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}),
                        title: t("Google Play"),
                        link: urls?.playStoreUrl,
                        t: t
                    }),
                    urls?.playStoreStatus === "1" && urls?.appStoreStatus === "1" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomDivider__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z, {}) : null,
                    urls?.appStoreStatus === "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Item, {
                        image: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_assets_AppleLogo__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {}),
                        title: t("App Store"),
                        link: urls?.appStoreUrl,
                        t: t
                    })
                ]
            })
        })
    });
};
CustomPopover.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomPopover);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 19188:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(58861);
/* harmony import */ var _CustomButtonComponent__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(22137);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_4__]);
_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const LargerScreen = (props)=>{
    const { landingPageData , goToApp , t  } = props;
    const isUpSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)("(min-width: 1000px) and (max-width: 1550px)");
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                alignItems: "center",
                justifyContent: "center",
                height: isUpSmall ? "300px" : "500px",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                    spacing: 4,
                    sx: {
                        paddingInlineStart: "2rem"
                    },
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                    variant: "h4",
                                    color: "primary.deep",
                                    fontWeight: 800,
                                    fontSize: {
                                        xs: "16px",
                                        sm: "22px",
                                        md: "36px"
                                    },
                                    component: "h2",
                                    children: landingPageData?.business_title
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                    variant: "h4",
                                    color: "primary.main",
                                    fontWeight: 700,
                                    fontSize: {
                                        xs: "14px",
                                        sm: "28px",
                                        md: "30px"
                                    },
                                    component: "h3",
                                    children: landingPageData?.business_sub_title
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                            spacing: 2,
                            children: landingPageData?.download_business_app_links && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomStackFullWidth */ .Xw, {
                                gap: 4,
                                direction: "row",
                                flexGrow: 1,
                                flexWrap: "wrap",
                                alignItems: "center",
                                children: [
                                    (landingPageData?.download_business_app_links?.seller_playstore_url_status === "1" || landingPageData?.download_business_app_links?.seller_appstore_url_status === "1") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        t: t,
                                        landingPageData: landingPageData,
                                        title: t("Seller App"),
                                        urls: {
                                            playStoreStatus: landingPageData?.download_business_app_links?.seller_playstore_url_status,
                                            playStoreUrl: landingPageData?.download_business_app_links?.seller_playstore_url,
                                            appStoreStatus: landingPageData?.download_business_app_links?.seller_appstore_url_status,
                                            appStoreUrl: landingPageData?.download_business_app_links?.seller_appstore_url
                                        }
                                    }),
                                    (landingPageData?.download_business_app_links?.dm_playstore_url_status === "1" || landingPageData?.download_business_app_links?.dm_appstore_url_status === "1") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                                        t: t,
                                        landingPageData: landingPageData,
                                        title: t("Deliveryman App"),
                                        urls: {
                                            playStoreStatus: landingPageData?.download_business_app_links?.dm_playstore_url_status,
                                            playStoreUrl: landingPageData?.download_business_app_links?.dm_playstore_url,
                                            appStoreStatus: landingPageData?.download_business_app_links?.dm_appstore_url_status,
                                            appStoreUrl: landingPageData?.download_business_app_links?.dm_appstore_url
                                        }
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Stack, {
                sx: {
                    position: "absolute",
                    // width:"40%",
                    height: "100%",
                    top: 0,
                    right: 0
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                    src: landingPageData?.business_image_full_url,
                    objectfit: "cover",
                    // height="100%"
                    // width="100%"
                    aspectRatio: "500/500",
                    maxWidth: "500px"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LargerScreen);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 18474:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(58861);
/* harmony import */ var _DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(40116);
/* harmony import */ var _CustomButtonComponent__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22137);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_6__]);
_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Wrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomBoxFullWidth */ .uu)(({ theme  })=>({
        position: "relative",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
    }));
const ImageWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw)(({ theme  })=>({
        // position: "relative",
        opacity: 0.1,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        [theme.breakpoints.down("md")]: {
            width: "420px"
        },
        [theme.breakpoints.down("sm")]: {
            width: "100%",
            height: "100%"
        }
    }));
const SmallerScreen = (props)=>{
    const { theme , landingPageData , goToApp , t  } = props;
    const [openPopover, setOpenPopover] = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({
        open: false,
        for: ""
    });
    const handleButtonClick = (type)=>{
        setOpenPopover({
            open: true,
            for: type
        });
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
        container: true,
        justifyContent: "center",
        alignItems: "center",
        // paddingY="2rem"
        spacing: 2,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Grid, {
            item: true,
            xs: 12,
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Wrapper, {
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImageWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                            src: landingPageData?.business_image_full_url,
                            objectFit: "cover",
                            height: "auto",
                            width: "100%"
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                        sx: {
                            position: "absolute",
                            top: "50%",
                            left: "50%",
                            transform: "translate(-50%, -50%)",
                            paddingX: {
                                xs: "2rem"
                            }
                        },
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "h4",
                                        fontSize: "16px",
                                        fontWeight: 800,
                                        color: "primary.deep",
                                        component: "h2",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            theme: theme,
                                            text: landingPageData?.business_title
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                        variant: "h4",
                                        fontSize: "14px",
                                        fontWeight: 700,
                                        color: "primary.main",
                                        component: "h3",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                            theme: theme,
                                            text: landingPageData?.business_sub_title
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                                spacing: 2,
                                children: landingPageData?.download_business_app_links && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                                    gap: {
                                        xs: 2,
                                        sm: 4
                                    },
                                    direction: "row",
                                    flexGrow: 1,
                                    flexWrap: "wrap",
                                    alignItems: "center",
                                    children: [
                                        (landingPageData?.download_business_app_links?.seller_playstore_url_status === "1" || landingPageData?.download_business_app_links?.seller_appstore_url_status === "1") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            t: t,
                                            landingPageData: landingPageData,
                                            title: t("Seller App"),
                                            urls: {
                                                playStoreStatus: landingPageData?.download_business_app_links?.seller_playstore_url_status,
                                                playStoreUrl: landingPageData?.download_business_app_links?.seller_playstore_url,
                                                appStoreStatus: landingPageData?.download_business_app_links?.seller_appstore_url_status,
                                                appStoreUrl: landingPageData?.download_business_app_links?.seller_appstore_url
                                            }
                                        }),
                                        (landingPageData?.download_business_app_links?.dm_playstore_url_status === "1" || landingPageData?.download_business_app_links?.dm_appstore_url_status === "1") && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomButtonComponent__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                                            t: t,
                                            landingPageData: landingPageData,
                                            title: t("Deliveryman App"),
                                            urls: {
                                                playStoreStatus: landingPageData?.download_business_app_links?.dm_playstore_url_status,
                                                playStoreUrl: landingPageData?.download_business_app_links?.dm_playstore_url,
                                                appStoreStatus: landingPageData?.download_business_app_links?.dm_appstore_url_status,
                                                appStoreUrl: landingPageData?.download_business_app_links?.dm_appstore_url
                                            }
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
SmallerScreen.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SmallerScreen);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 56085:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);



const AppleLogo = (props)=>{
    const { size =25  } = props;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("g", {
                "clip-path": "url(#clip0_2275_12134)",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M16.6192 0C16.6751 0 16.7309 0 16.7899 0C16.9269 1.69253 16.2809 2.95719 15.4958 3.87301C14.7254 4.78251 13.6704 5.6646 11.9642 5.53076C11.8504 3.86247 12.4975 2.69161 13.2816 1.77789C14.0087 0.92636 15.3419 0.168621 16.6192 0Z",
                        fill: theme.palette.neutral[1000]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                        d: "M21.7841 17.6183C21.7841 17.6352 21.7841 17.65 21.7841 17.6658C21.3046 19.118 20.6206 20.3626 19.7859 21.5177C19.024 22.5663 18.0903 23.9774 16.423 23.9774C14.9824 23.9774 14.0254 23.0511 12.549 23.0258C10.9871 23.0005 10.1282 23.8004 8.70019 24.0017C8.53683 24.0017 8.37348 24.0017 8.21329 24.0017C7.16468 23.8499 6.31842 23.0195 5.7019 22.2712C3.88396 20.0602 2.47914 17.2042 2.21777 13.5493C2.21777 13.191 2.21777 12.8337 2.21777 12.4754C2.32843 9.85968 3.59941 7.73295 5.28878 6.70225C6.18036 6.15423 7.40602 5.68737 8.7708 5.89603C9.3557 5.98667 9.95325 6.1869 10.477 6.38503C10.9734 6.57579 11.5941 6.91408 12.1822 6.89617C12.5806 6.88457 12.9768 6.67696 13.3784 6.53047C14.5545 6.10576 15.7074 5.61886 17.2271 5.84756C19.0535 6.12367 20.3498 6.93516 21.1507 8.18717C19.6057 9.17044 18.3843 10.6522 18.593 13.1826C18.7784 15.4811 20.1148 16.8258 21.7841 17.6183Z",
                        fill: theme.palette.neutral[1000]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("defs", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("clipPath", {
                    id: "clip0_2275_12134",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("rect", {
                        width: "24",
                        height: "24",
                        fill: "white"
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppleLogo);


/***/ }),

/***/ 62820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const PlayStoreIcon = (props)=>{
    const { size =25  } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        width: size,
        height: size,
        viewBox: "0 0 24 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M17.9234 8.23178C15.1354 6.67239 10.6605 4.16836 3.7196 0.281998C3.25164 -0.0270497 2.71324 -0.0675497 2.24805 0.0899037L14.1567 11.9985L17.9234 8.23178Z",
                fill: "#32BBFF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M2.24788 0.0908203C2.16069 0.120352 2.07585 0.155977 1.9947 0.199008C1.481 0.476884 1.10352 1.01159 1.10352 1.68785V22.311C1.10352 22.9873 1.48095 23.522 1.9947 23.7998C2.07571 23.8428 2.1605 23.8786 2.2476 23.9083L14.1565 11.9994L2.24788 0.0908203Z",
                fill: "#32BBFF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M14.1569 11.9989L2.24805 23.9078C2.71338 24.0664 3.25178 24.029 3.71988 23.7154C10.451 19.9462 14.8755 17.4718 17.6958 15.8992C17.7743 15.8551 17.8512 15.812 17.9272 15.7693L14.1569 11.9989Z",
                fill: "#32BBFF"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M1.10352 11.9989V22.3105C1.10352 22.9868 1.48095 23.5215 1.9947 23.7993C2.07571 23.8423 2.1605 23.8781 2.2476 23.9078L14.1565 11.9989H1.10352Z",
                fill: "#2C9FD9"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M3.71984 0.282559C3.16414 -0.0843794 2.50882 -0.0739263 1.99512 0.198699L13.9762 12.1798L17.9236 8.23234C15.1356 6.67295 10.6607 4.16893 3.71984 0.282559Z",
                fill: "#29CC5E"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M13.9762 11.8171L1.99512 23.7982C2.50887 24.0708 3.16414 24.0865 3.71984 23.7143C10.451 19.9451 14.8755 17.4707 17.6957 15.8981C17.7743 15.854 17.8512 15.8108 17.9272 15.7681L13.9762 11.8171Z",
                fill: "#D93F21"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M22.8956 11.9997C22.8956 11.4283 22.6073 10.8516 22.0358 10.5318C22.0358 10.5318 20.9671 9.93552 17.6913 8.10327L13.7949 11.9997L17.6951 15.8999C20.9349 14.0808 22.0357 13.4675 22.0357 13.4675C22.6073 13.1477 22.8956 12.5711 22.8956 11.9997Z",
                fill: "#FFD500"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M22.0358 13.4669C22.6073 13.1471 22.8956 12.5704 22.8956 11.999H13.7949L17.6951 15.8993C20.935 14.0802 22.0358 13.4669 22.0358 13.4669Z",
                fill: "#FFAA00"
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (PlayStoreIcon);


/***/ }),

/***/ 30725:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "o": () => (/* binding */ CustomButton)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57987);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(28332);
/* harmony import */ var _LargerScreen__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19188);
/* harmony import */ var _SmallerScreen__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(18474);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _LargerScreen__WEBPACK_IMPORTED_MODULE_5__, _SmallerScreen__WEBPACK_IMPORTED_MODULE_6__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_2__, _LargerScreen__WEBPACK_IMPORTED_MODULE_5__, _SmallerScreen__WEBPACK_IMPORTED_MODULE_6__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);







const Wrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Box)(({ theme  })=>({
        background: `linear-gradient(112.54deg, rgba(255, 255, 255, 0.2) 0%, rgba(153, 245, 202, 0.2) 33.19%, ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.primary.main, 0.2)} 66.37%, rgba(255, 255, 255, 0.2) 99.56%)`,
        width: "100%",
        position: "relative"
    }));
const CustomButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Button)(({ theme  })=>({
        borderRadius: "10px",
        gap: "10px",
        padding: "12px 15px",
        fontSize: "16px",
        fontWeight: 700,
        maxWidth: "400px",
        background: `linear-gradient(133deg, ${theme.palette.primary.customType1} 0%, ${theme.palette.primary.main} 51.01%)`,
        color: theme.palette.whiteContainer.main,
        [theme.breakpoints.down("md")]: {
            padding: "12px 15px",
            fontSize: "14px",
            gap: "8px"
        },
        [theme.breakpoints.down("sm")]: {
            padding: "10px",
            fontSize: "12px",
            gap: "5px"
        }
    }));
const AppDownloadSection = ({ configData , landingPageData  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("md"));
    const primaryColor = theme.palette.primary.dark;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const goToApp = (s)=>{
        window.open(s);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_container__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Wrapper, {
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                children: isSmall ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_SmallerScreen__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                    theme: theme,
                    landingPageData: landingPageData,
                    goToApp: goToApp,
                    t: t
                }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_LargerScreen__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                    landingPageData: landingPageData,
                    goToApp: goToApp,
                    t: t
                })
            })
        })
    });
};
AppDownloadSection.propTypes = {};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (AppDownloadSection)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 98488:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const DownArrow = ()=>{
    return /*#__PURE__*/ _jsx("svg", {
        width: "83",
        height: "80",
        viewBox: "0 0 83 80",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ _jsx("path", {
            d: "M0.875222 4.51754C0.607816 4.58645 0.446907 4.85909 0.51582 5.1265C0.584733 5.39391 0.857373 5.55481 1.12478 5.4859L0.875222 4.51754ZM67.7098 79.0107C67.7153 79.2868 67.9435 79.5062 68.2196 79.5007L72.7187 79.4111C72.9948 79.4056 73.2142 79.1773 73.2087 78.9012C73.2032 78.6252 72.9749 78.4058 72.6988 78.4113L68.6996 78.4909L68.62 74.4917C68.6145 74.2156 68.3862 73.9963 68.1101 74.0018C67.8341 74.0073 67.6147 74.2355 67.6202 74.5116L67.7098 79.0107ZM3.66269 4.85442C3.93122 4.79002 4.0967 4.52013 4.0323 4.2516C3.9679 3.98307 3.69801 3.8176 3.42948 3.882L3.66269 4.85442ZM8.41536 2.77679C8.14474 2.83175 7.96991 3.09568 8.02487 3.3663C8.07983 3.63692 8.34376 3.81175 8.61438 3.75679L8.41536 2.77679ZM13.6903 2.82752C13.9629 2.78322 14.1479 2.52635 14.1036 2.25378C14.0593 1.98122 13.8025 1.79617 13.5299 1.84048L13.6903 2.82752ZM18.6497 1.1193C18.3755 1.15181 18.1795 1.40047 18.212 1.67469C18.2446 1.94891 18.4932 2.14486 18.7674 2.11234L18.6497 1.1193ZM23.8466 1.63028C24.1221 1.61086 24.3296 1.37181 24.3102 1.09635C24.2908 0.820895 24.0517 0.613336 23.7763 0.632758L23.8466 1.63028ZM28.9138 0.404489C28.6377 0.40931 28.4178 0.63704 28.4226 0.913141C28.4274 1.18924 28.6551 1.40916 28.9312 1.40434L28.9138 0.404489ZM34.0327 1.46376C34.3086 1.47531 34.5416 1.26102 34.5532 0.985122C34.5647 0.709222 34.3504 0.476191 34.0745 0.464632L34.0327 1.46376ZM39.2434 0.850892C38.9689 0.820968 38.7221 1.01925 38.6922 1.29377C38.6623 1.56828 38.8605 1.81508 39.1351 1.845L39.2434 0.850892ZM44.185 2.58347C44.4565 2.6338 44.7174 2.45448 44.7678 2.18297C44.8181 1.91145 44.6388 1.65054 44.3673 1.60022L44.185 2.58347ZM49.4143 2.75147C49.148 2.67866 48.873 2.83558 48.8002 3.10195C48.7274 3.36832 48.8843 3.64328 49.1507 3.71609L49.4143 2.75147ZM53.9876 5.27882C54.246 5.37605 54.5344 5.24536 54.6316 4.9869C54.7289 4.72844 54.5982 4.4401 54.3397 4.34286L53.9876 5.27882ZM59.1016 6.41577C58.8545 6.29246 58.5543 6.39279 58.431 6.63987C58.3077 6.88695 58.408 7.18721 58.6551 7.31052L59.1016 6.41577ZM63.076 9.83252C63.3076 9.98279 63.6173 9.91681 63.7676 9.68514C63.9178 9.45346 63.8518 9.14383 63.6202 8.99356L63.076 9.83252ZM67.8044 12.0765C67.5924 11.8995 67.2771 11.9279 67.1001 12.1398C66.9231 12.3518 66.9515 12.6671 67.1635 12.8441L67.8044 12.0765ZM70.842 16.3281C71.0301 16.5303 71.3465 16.5418 71.5486 16.3537C71.7508 16.1656 71.7622 15.8492 71.5742 15.647L70.842 16.3281ZM74.8643 19.6742C74.7037 19.4496 74.3915 19.3976 74.1668 19.5582C73.9421 19.7187 73.8902 20.031 74.0507 20.2557L74.8643 19.6742ZM76.7286 24.5649C76.859 24.8083 77.162 24.8999 77.4054 24.7695C77.6488 24.6391 77.7405 24.3361 77.6101 24.0927L76.7286 24.5649ZM79.7695 28.8206C79.6708 28.5627 79.3817 28.4337 79.1238 28.5324C78.8659 28.6312 78.7369 28.9203 78.8357 29.1782L79.7695 28.8206ZM80.3564 34.021C80.423 34.289 80.6943 34.4522 80.9623 34.3856C81.2303 34.319 81.3935 34.0477 81.3269 33.7798L80.3564 34.021ZM82.2805 38.8873C82.2457 38.6134 81.9954 38.4195 81.7215 38.4543C81.4475 38.4891 81.2537 38.7394 81.2884 39.0133L82.2805 38.8873ZM81.6418 44.0837C81.6456 44.3598 81.8725 44.5806 82.1486 44.5768C82.4247 44.5731 82.6455 44.3462 82.6418 44.0701L81.6418 44.0837ZM82.4289 49.2562C82.4551 48.9813 82.2535 48.7372 81.9786 48.711C81.7037 48.6848 81.4596 48.8864 81.4334 49.1613L82.4289 49.2562ZM80.6831 54.1917C80.628 54.4623 80.8028 54.7263 81.0734 54.7813C81.344 54.8363 81.608 54.6616 81.663 54.391L80.6831 54.1917ZM80.366 59.4173C80.4487 59.1539 80.3021 58.8732 80.0387 58.7905C79.7752 58.7078 79.4946 58.8544 79.4119 59.1178L80.366 59.4173ZM77.6424 63.8853C77.5332 64.139 77.6503 64.4331 77.904 64.5423C78.1576 64.6515 78.4517 64.5344 78.5609 64.2807L77.6424 63.8853ZM76.2683 68.937C76.4028 68.6958 76.3162 68.3913 76.0751 68.2568C75.8339 68.1224 75.5293 68.2089 75.3949 68.4501L76.2683 68.937ZM72.6931 72.7624C72.5347 72.9886 72.5896 73.3004 72.8158 73.4588C73.042 73.6172 73.3538 73.5623 73.5122 73.3361L72.6931 72.7624ZM70.3232 77.4258C70.504 77.2171 70.4813 76.9013 70.2726 76.7205C70.0638 76.5398 69.7481 76.5624 69.5673 76.7712L70.3232 77.4258ZM1.12478 5.4859C1.97804 5.26601 2.824 5.05556 3.66269 4.85442L3.42948 3.882C2.58526 4.08446 1.73385 4.29626 0.875222 4.51754L1.12478 5.4859ZM8.61438 3.75679C10.3391 3.40653 12.031 3.09722 13.6903 2.82752L13.5299 1.84048C11.8573 2.11233 10.1526 2.424 8.41536 2.77679L8.61438 3.75679ZM18.7674 2.11234C20.4987 1.90707 22.1917 1.74697 23.8466 1.63028L23.7763 0.632758C22.1051 0.750591 20.3963 0.912207 18.6497 1.1193L18.7674 2.11234ZM28.9312 1.40434C30.678 1.37384 32.3783 1.39445 34.0327 1.46376L34.0745 0.464632C32.3998 0.394475 30.6797 0.373661 28.9138 0.404489L28.9312 1.40434ZM39.1351 1.845C40.8751 2.03467 42.5582 2.28195 44.185 2.58347L44.3673 1.60022C42.7152 1.29402 41.0075 1.04318 39.2434 0.850892L39.1351 1.845ZM49.1507 3.71609C50.8318 4.17556 52.4438 4.69802 53.9876 5.27882L54.3397 4.34286C52.7661 3.75086 51.1246 3.21891 49.4143 2.75147L49.1507 3.71609ZM58.6551 7.31052C60.2112 8.08717 61.6845 8.92993 63.076 9.83252L63.6202 8.99356C62.1967 8.07023 60.6908 7.2089 59.1016 6.41577L58.6551 7.31052ZM67.1635 12.8441C68.4827 13.9457 69.7084 15.1096 70.842 16.3281L71.5742 15.647C70.412 14.3977 69.1558 13.2049 67.8044 12.0765L67.1635 12.8441ZM74.0507 20.2557C75.0425 21.6434 75.9346 23.0827 76.7286 24.5649L77.6101 24.0927C76.7961 22.5732 75.8813 21.0973 74.8643 19.6742L74.0507 20.2557ZM78.8357 29.1782C79.4416 30.7605 79.948 32.3779 80.3564 34.021L81.3269 33.7798C80.9088 32.0979 80.3903 30.4416 79.7695 28.8206L78.8357 29.1782ZM81.2884 39.0133C81.5014 40.6902 81.6187 42.3834 81.6418 44.0837L82.6418 44.0701C82.6181 42.3328 82.4982 40.6021 82.2805 38.8873L81.2884 39.0133ZM81.4334 49.1613C81.2731 50.8431 81.0225 52.5229 80.6831 54.1917L81.663 54.391C82.0094 52.6879 82.2652 50.9733 82.4289 49.2562L81.4334 49.1613ZM79.4119 59.1178C78.9061 60.729 78.3158 62.3209 77.6424 63.8853L78.5609 64.2807C79.2479 62.685 79.85 61.061 80.366 59.4173L79.4119 59.1178ZM75.3949 68.4501C74.5727 69.9249 73.6717 71.365 72.6931 72.7624L73.5122 73.3361C74.5105 71.9104 75.4297 70.4414 76.2683 68.937L75.3949 68.4501ZM69.5673 76.7712C69.0129 77.4113 68.4401 78.0394 67.8492 78.6543L68.5702 79.3472C69.1732 78.7198 69.7575 78.079 70.3232 77.4258L69.5673 76.7712Z",
            fill: "#93A2AE"
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DownArrow)));


/***/ }),

/***/ 81650:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const DownArrowRTL = ()=>{
    return /*#__PURE__*/ _jsx("svg", {
        width: "83",
        height: "80",
        viewBox: "0 0 83 80",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ _jsx("path", {
            d: "M82.2708 4.62692C82.5382 4.69583 82.6991 4.96847 82.6302 5.23587C82.5613 5.50328 82.2886 5.66419 82.0212 5.59528L82.2708 4.62692ZM15.4362 79.1201C15.4307 79.3962 15.2025 79.6156 14.9264 79.6101L10.4273 79.5205C10.1512 79.515 9.93181 79.2867 9.93731 79.0106C9.9428 78.7345 10.1711 78.5152 10.4472 78.5207L14.4464 78.6003L14.526 74.6011C14.5315 74.325 14.7598 74.1057 15.0359 74.1112C15.3119 74.1166 15.5313 74.3449 15.5258 74.621L15.4362 79.1201ZM79.4833 4.9638C79.2148 4.8994 79.0493 4.6295 79.1137 4.36098C79.1781 4.09245 79.448 3.92697 79.7165 3.99137L79.4833 4.9638ZM74.7306 2.88617C75.0013 2.94113 75.1761 3.20506 75.1211 3.47568C75.0662 3.7463 74.8022 3.92112 74.5316 3.86617L74.7306 2.88617ZM69.4557 2.9369C69.1831 2.89259 68.9981 2.63572 69.0424 2.36316C69.0867 2.09059 69.3435 1.90555 69.6161 1.94985L69.4557 2.9369ZM64.4963 1.22867C64.7705 1.26119 64.9665 1.50985 64.934 1.78407C64.9014 2.05829 64.6528 2.25423 64.3786 2.22172L64.4963 1.22867ZM59.2994 1.73966C59.0239 1.72023 58.8164 1.48119 58.8358 1.20573C58.8552 0.93027 59.0943 0.722711 59.3697 0.742133L59.2994 1.73966ZM54.2322 0.513864C54.5083 0.518685 54.7282 0.746415 54.7234 1.02252C54.7186 1.29862 54.4909 1.51853 54.2148 1.51371L54.2322 0.513864ZM49.1133 1.57313C48.8374 1.58469 48.6044 1.3704 48.5928 1.0945C48.5813 0.818597 48.7956 0.585566 49.0715 0.574007L49.1133 1.57313ZM43.9026 0.960267C44.1771 0.930343 44.4239 1.12862 44.4538 1.40314C44.4837 1.67766 44.2855 1.92445 44.0109 1.95438L43.9026 0.960267ZM38.961 2.69285C38.6894 2.74317 38.4285 2.56386 38.3782 2.29234C38.3279 2.02082 38.5072 1.75992 38.7787 1.70959L38.961 2.69285ZM33.7317 2.86084C33.998 2.78804 34.273 2.94495 34.3458 3.21133C34.4186 3.4777 34.2617 3.75265 33.9953 3.82546L33.7317 2.86084ZM29.1584 5.38819C28.8999 5.48543 28.6116 5.35473 28.5144 5.09628C28.4171 4.83782 28.5478 4.54947 28.8063 4.45224L29.1584 5.38819ZM24.0444 6.52514C24.2915 6.40183 24.5917 6.50216 24.715 6.74924C24.8383 6.99633 24.738 7.29659 24.4909 7.4199L24.0444 6.52514ZM20.07 9.94189C19.8383 10.0922 19.5287 10.0262 19.3784 9.79451C19.2282 9.56284 19.2942 9.25321 19.5258 9.10293L20.07 9.94189ZM15.3416 12.1859C15.5536 12.0089 15.8689 12.0372 16.0459 12.2492C16.2228 12.4612 16.1945 12.7765 15.9825 12.9535L15.3416 12.1859ZM12.304 16.4375C12.1159 16.6397 11.7995 16.6511 11.5974 16.463C11.3952 16.275 11.3838 15.9586 11.5718 15.7564L12.304 16.4375ZM8.28169 19.7836C8.44225 19.559 8.75454 19.507 8.97921 19.6676C9.20387 19.8281 9.25584 20.1404 9.09528 20.3651L8.28169 19.7836ZM6.41741 24.6743C6.28701 24.9177 5.98398 25.0093 5.74056 24.8789C5.49715 24.7485 5.40553 24.4455 5.53593 24.202L6.41741 24.6743ZM3.37645 28.9299C3.4752 28.6721 3.7643 28.5431 4.02219 28.6418C4.28007 28.7405 4.40907 29.0297 4.31033 29.2875L3.37645 28.9299ZM2.78957 34.1304C2.72296 34.3983 2.45171 34.5616 2.18372 34.495C1.91574 34.4284 1.75249 34.1571 1.81911 33.8891L2.78957 34.1304ZM0.865517 38.9967C0.900307 38.7228 1.15058 38.5289 1.42452 38.5637C1.69846 38.5985 1.89234 38.8487 1.85755 39.1227L0.865517 38.9967ZM1.50415 44.193C1.5004 44.4692 1.27351 44.6899 0.997398 44.6862C0.721283 44.6824 0.500488 44.4556 0.504242 44.1794L1.50415 44.193ZM0.717087 49.3655C0.69088 49.0906 0.892487 48.8465 1.16738 48.8203C1.44228 48.7941 1.68637 48.9957 1.71258 49.2706L0.717087 49.3655ZM2.46291 54.3011C2.51795 54.5717 2.3432 54.8356 2.0726 54.8907C1.80199 54.9457 1.53801 54.771 1.48298 54.5004L2.46291 54.3011ZM2.78003 59.5267C2.69733 59.2632 2.84386 58.9826 3.10732 58.8999C3.37079 58.8172 3.65142 58.9637 3.73412 59.2272L2.78003 59.5267ZM5.50359 63.9947C5.61278 64.2484 5.49567 64.5425 5.24203 64.6517C4.98839 64.7609 4.69426 64.6437 4.58508 64.3901L5.50359 63.9947ZM6.87769 69.0464C6.74323 68.8052 6.82975 68.5006 7.07095 68.3662C7.31214 68.2317 7.61667 68.3183 7.75113 68.5595L6.87769 69.0464ZM10.4529 72.8718C10.6113 73.098 10.5564 73.4098 10.3302 73.5682C10.104 73.7266 9.7922 73.6716 9.6338 73.4454L10.4529 72.8718ZM12.8228 77.5352C12.642 77.3265 12.6647 77.0107 12.8734 76.8299C13.0822 76.6491 13.3979 76.6718 13.5787 76.8805L12.8228 77.5352ZM82.0212 5.59528C81.168 5.37538 80.322 5.16494 79.4833 4.9638L79.7165 3.99137C80.5607 4.19384 81.4121 4.40564 82.2708 4.62692L82.0212 5.59528ZM74.5316 3.86617C72.8069 3.5159 71.115 3.2066 69.4557 2.9369L69.6161 1.94985C71.2887 2.22171 72.9934 2.53337 74.7306 2.88617L74.5316 3.86617ZM64.3786 2.22172C62.6473 2.01644 60.9543 1.85634 59.2994 1.73966L59.3697 0.742133C61.0409 0.859966 62.7497 1.02158 64.4963 1.22867L64.3786 2.22172ZM54.2148 1.51371C52.468 1.48322 50.7677 1.50383 49.1133 1.57313L49.0715 0.574007C50.7462 0.50385 52.4663 0.483036 54.2322 0.513864L54.2148 1.51371ZM44.0109 1.95438C42.2709 2.14405 40.5878 2.39132 38.961 2.69285L38.7787 1.70959C40.4308 1.4034 42.1385 1.15255 43.9026 0.960267L44.0109 1.95438ZM33.9953 3.82546C32.3142 4.28494 30.7022 4.80739 29.1584 5.38819L28.8063 4.45224C30.3798 3.86024 32.0214 3.32829 33.7317 2.86084L33.9953 3.82546ZM24.4909 7.4199C22.9348 8.19655 21.4615 9.0393 20.07 9.94189L19.5258 9.10293C20.9493 8.1796 22.4552 7.31828 24.0444 6.52514L24.4909 7.4199ZM15.9825 12.9535C14.6633 14.055 13.4376 15.219 12.304 16.4375L11.5718 15.7564C12.734 14.5071 13.9902 13.3143 15.3416 12.1859L15.9825 12.9535ZM9.09528 20.3651C8.10353 21.7527 7.2114 23.1921 6.41741 24.6743L5.53593 24.202C6.34991 22.6825 7.26467 21.2067 8.28169 19.7836L9.09528 20.3651ZM4.31033 29.2875C3.70444 30.8699 3.198 32.4872 2.78957 34.1304L1.81911 33.8891C2.23715 32.2073 2.75572 30.551 3.37645 28.9299L4.31033 29.2875ZM1.85755 39.1227C1.6446 40.7996 1.52728 42.4928 1.50415 44.193L0.504242 44.1794C0.52787 42.4422 0.647758 40.7115 0.865517 38.9967L1.85755 39.1227ZM1.71258 49.2706C1.87291 50.9525 2.12349 52.6322 2.46291 54.3011L1.48298 54.5004C1.1366 52.7973 0.880798 51.0827 0.717087 49.3655L1.71258 49.2706ZM3.73412 59.2272C4.23988 60.8383 4.83015 62.4303 5.50359 63.9947L4.58508 64.3901C3.89814 62.7943 3.29599 61.1703 2.78003 59.5267L3.73412 59.2272ZM7.75113 68.5595C8.57328 70.0342 9.47431 71.4744 10.4529 72.8718L9.6338 73.4454C8.63547 72.0198 7.71632 70.5508 6.87769 69.0464L7.75113 68.5595ZM13.5787 76.8805C14.1331 77.5207 14.7059 78.1488 15.2968 78.7637L14.5758 79.4566C13.9728 78.8291 13.3885 78.1884 12.8228 77.5352L13.5787 76.8805Z",
            fill: "#93A2AE"
        })
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (DownArrowRTL)));


/***/ }),

/***/ 3358:
/***/ ((__unused_webpack_module, __unused_webpack___webpack_exports__, __webpack_require__) => {

/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


const MobileFrame = (props)=>{
    const { width ="246" , height ="427" , color ="white"  } = props;
    return /*#__PURE__*/ _jsxs("svg", {
        width: width,
        height: height,
        viewBox: "0 0 249 427",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ _jsx("path", {
                "fill-rule": "evenodd",
                "clip-rule": "evenodd",
                d: "M1.87305 22.0006C1.87305 10.8853 10.8838 1.87451 21.9992 1.87451L229.001 1.87451C240.116 1.87451 249.127 10.8853 249.127 22.0006L249.127 496.86C249.127 507.976 240.116 516.986 229.001 516.986L21.9992 516.986C10.8838 516.986 1.87305 507.976 1.87305 496.86L1.87305 22.0006ZM11.2388 26.8937C11.2388 18.2485 18.2472 11.2401 26.8925 11.2401L58.6867 11.2401C61.4481 11.2401 63.6867 13.4787 63.6867 16.2401L63.6867 22.1447C63.6867 26.4673 67.1909 29.9715 71.5135 29.9715L179.487 29.9715C183.809 29.9715 187.314 26.4673 187.314 22.1447L187.314 16.2401C187.314 13.4787 189.552 11.2401 192.314 11.2401L224.108 11.2401C232.753 11.2401 239.761 18.2485 239.761 26.8937L239.761 491.967C239.761 500.612 232.753 507.621 224.108 507.621L26.8925 507.621C18.2472 507.621 11.2388 500.612 11.2388 491.967L11.2388 26.8937Z",
                fill: "white"
            }),
            /*#__PURE__*/ _jsx("rect", {
                x: "106.767",
                y: "14.9841",
                width: "37.4627",
                height: "3.74627",
                rx: "1.87313",
                fill: "#5E5E5E"
            }),
            /*#__PURE__*/ _jsx("circle", {
                cx: "157.354",
                cy: "16.8477",
                r: "3.74627",
                fill: "#36393E"
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (MobileFrame)));


/***/ }),

/***/ 86776:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(45269);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(58861);
/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(28332);
/* harmony import */ var _assets_MobileFrame__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(3358);
/* harmony import */ var _HeroLocationForm__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(80558);
/* harmony import */ var _HeroTitleSection__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(61923);
/* harmony import */ var components_landing_page_HeroBgSvg__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(51610);
/* harmony import */ var _bg_img__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(2313);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__, _HeroLocationForm__WEBPACK_IMPORTED_MODULE_10__, _HeroTitleSection__WEBPACK_IMPORTED_MODULE_11__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_5__, _HeroLocationForm__WEBPACK_IMPORTED_MODULE_10__, _HeroTitleSection__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const DynamicModuleSelection = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>Promise.resolve(/* import() */).then(__webpack_require__.bind(__webpack_require__, 10818)), {
    loadableGenerated: {
        modules: [
            "..\\src\\components\\landing-page\\hero-section\\HeroSection.js -> " + "./module-selection/ModuleSelectionRaw"
        ]
    }
});
const HeroSection = ({ configData , landingPageData , handleOrderNow  })=>{
    const theme = useTheme();
    const isXSmall = useMediaQuery(theme.breakpoints.down("sm"));
    const isSmall = useMediaQuery(theme.breakpoints.down("md"));
    const { t  } = useTranslation();
    const [currentLocation, setCurrentLocation] = useState(null);
    useEffect(()=>{
        if (false) {}
    }, []);
    const calculateTopMargin = ()=>{
        if (currentLocation) {
            return {
                xs: "4rem",
                sm: "5rem",
                md: "7rem"
            };
        } else {
            return {
                xs: "4rem",
                sm: "5rem",
                md: "5rem"
            };
        }
    };
    return /*#__PURE__*/ _jsxs(CustomContainer, {
        children: [
            /*#__PURE__*/ _jsxs(CustomBoxFullWidth, {
                sx: {
                    marginTop: calculateTopMargin(),
                    borderRadius: "20px",
                    position: "relative",
                    overflow: "hidden",
                    ".shape img": {
                        transition: "all ease-in 1s"
                    }
                },
                children: [
                    /*#__PURE__*/ _jsx(Box, {
                        sx: {
                            position: "absolute",
                            pointerEvents: "none"
                        },
                        className: "shape",
                        children: /*#__PURE__*/ _jsx(BGimage, {})
                    }),
                    /*#__PURE__*/ _jsxs(Grid, {
                        container: true,
                        children: [
                            /*#__PURE__*/ _jsx(Grid, {
                                item: true,
                                xs: 8,
                                md: 7,
                                sx: {
                                    padding: {
                                        xs: "1rem",
                                        sm: "2rem",
                                        md: "3rem"
                                    }
                                },
                                children: /*#__PURE__*/ _jsx(NoSsr, {
                                    children: /*#__PURE__*/ _jsx(HeroTitleSection, {
                                        configData: configData,
                                        landingPageData: landingPageData,
                                        handleOrderNow: handleOrderNow
                                    })
                                })
                            }),
                            /*#__PURE__*/ _jsx(Grid, {
                                item: true,
                                xs: 4,
                                md: 5,
                                align: "right",
                                children: /*#__PURE__*/ _jsx(CustomStackFullWidth, {
                                    height: "100%",
                                    alignItems: "flex-start",
                                    justifyContent: "flex-end",
                                    paddingTop: {
                                        xs: "2rem",
                                        md: "3rem"
                                    }
                                })
                            })
                        ]
                    })
                ]
            }),
            isXSmall && /*#__PURE__*/ _jsx(_Fragment, {
                children: currentLocation ? /*#__PURE__*/ _jsx(DynamicModuleSelection, {
                    isSmall: true
                }) : /*#__PURE__*/ _jsx(CustomStackFullWidth, {
                    mt: "10px",
                    children: /*#__PURE__*/ _jsx(HeroLocationForm, {})
                })
            })
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (HeroSection)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 61923:
/***/ ((module, __unused_webpack___webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _DollarSignHighlighter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(40116);
/* harmony import */ var _assets_DownArrow__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(98488);
/* harmony import */ var _assets_DownArrowRTL__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(81650);
/* harmony import */ var _HeroLocationForm__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(80558);
/* harmony import */ var _module_selection_ModuleSelectionRaw__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(10818);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_HeroLocationForm__WEBPACK_IMPORTED_MODULE_7__, _module_selection_ModuleSelectionRaw__WEBPACK_IMPORTED_MODULE_8__]);
([_HeroLocationForm__WEBPACK_IMPORTED_MODULE_7__, _module_selection_ModuleSelectionRaw__WEBPACK_IMPORTED_MODULE_8__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);











const HeroTitleSection = ({ configData , landingPageData , handleOrderNow  })=>{
    const theme = useTheme();
    const isXSmall = useMediaQuery(theme.breakpoints.down("sm"));
    const currentLanguage = getLanguage();
    const [currentLocation, setCurrentLocation] = useState(null);
    const lanDirection = getLanguage() ? getLanguage() : "ltr";
    useEffect(()=>{
        if (false) {}
    }, []);
    const getSearchOrModulesBySelectedModules = ()=>{
        if (currentLocation) {
            return /*#__PURE__*/ _jsx(ModuleSelectionRaw, {});
        } else {
            return /*#__PURE__*/ _jsx(CustomStackFullWidth, {
                mt: "15px",
                children: /*#__PURE__*/ _jsx(HeroLocationForm, {})
            });
        }
    };
    return /*#__PURE__*/ _jsxs(CustomStackFullWidth, {
        children: [
            /*#__PURE__*/ _jsxs(CustomStackFullWidth, {
                spacing: 0.4,
                children: [
                    /*#__PURE__*/ _jsx(Stack, {
                        direction: "row",
                        alignItems: "center",
                        justifyContent: "flex-start",
                        spacing: 0.5,
                        flexWrap: "wrap",
                        children: /*#__PURE__*/ _jsx(Typography, {
                            sx: {
                                color: (theme)=>theme.palette.primary.main,
                                fontSize: isXSmall ? "20px" : "54px",
                                lineHeight: isXSmall ? "24px" : "58px",
                                fontWeight: "bold"
                            },
                            component: "h1",
                            children: /*#__PURE__*/ _jsx(DollarSignHighlighter, {
                                theme: theme,
                                text: landingPageData?.header_title
                            })
                        })
                    }),
                    /*#__PURE__*/ _jsx(Typography, {
                        color: alpha(theme.palette.neutral[700], 0.8),
                        fontSize: isXSmall ? "16px" : "35px",
                        lineHeight: isXSmall ? "22px" : "58px",
                        fontWeight: "400",
                        component: "h2",
                        children: /*#__PURE__*/ _jsx(DollarSignHighlighter, {
                            theme: theme,
                            text: landingPageData?.header_sub_title
                        })
                    })
                ]
            }),
            /*#__PURE__*/ _jsxs(CustomStackFullWidth, {
                flexDirection: "row",
                spacing: 2,
                justifyContent: "space-between",
                mt: "14px",
                sx: {
                    position: "relative"
                },
                children: [
                    /*#__PURE__*/ _jsx(Typography, {
                        sx: {
                            fontSize: {
                                xs: "12px",
                                md: "20px"
                            },
                            color: (theme)=>alpha(theme.palette.neutral[500], 0.5)
                        },
                        fontWeight: "400",
                        children: /*#__PURE__*/ _jsx(DollarSignHighlighter, {
                            theme: theme,
                            text: landingPageData?.header_tag_line
                        })
                    }),
                    !getCurrentModuleType() && !isXSmall && /*#__PURE__*/ _jsx(Stack, {
                        sx: {},
                        children: lanDirection === "rtl" ? /*#__PURE__*/ _jsx(DownArrowRTL, {}) : /*#__PURE__*/ _jsx(DownArrow, {})
                    })
                ]
            }),
            !isXSmall && getSearchOrModulesBySelectedModules()
        ]
    });
};
/* unused harmony default export */ var __WEBPACK_DEFAULT_EXPORT__ = ((/* unused pure expression or super */ null && (HeroTitleSection)));

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 10818:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(57987);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(90603);
/* harmony import */ var redux_slices_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(67493);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(45269);
/* harmony import */ var utils_CommonValues__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(65401);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58861);
/* harmony import */ var _sliderSettings__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(25341);
/* harmony import */ var api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(38579);
/* harmony import */ var redux_slices_configData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(53236);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_5__, api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_13__]);
([react_i18next__WEBPACK_IMPORTED_MODULE_5__, api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_13__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
















const CardWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack)(({ theme , bg_change  })=>({
        backgroundColor: theme.palette.background.paper,
        color: "inherit",
        minWidth: "163px",
        minHeight: "80px",
        padding: "12px",
        border: `1px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.alpha)(theme.palette.neutral[400], 0.2)}`,
        borderRadius: "10px",
        cursor: "pointer",
        transition: "all ease 0.5s",
        position: "relative",
        zIndex: "99",
        "&:hover": {
            backgroundColor: theme.palette.primary.main,
            color: theme.palette.whiteContainer.main,
            ".text": {
                color: theme.palette.whiteContainer.main
            }
        }
    }));
const ImageWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Box)(({ theme  })=>({
        width: "33px",
        height: "33px",
        position: "relative"
    }));
const Card = ({ item , configData , isSelected , handleClick  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_5__.useTranslation)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(CardWrapper, {
        onClick: ()=>handleClick(item),
        bg_change: isSelected === item?.module_type ? "true" : "false",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                sx: {
                    cursor: "pointer"
                },
                variant: (0,utils_CommonValues__WEBPACK_IMPORTED_MODULE_10__/* .IsSmallScreen */ .R)() ? "h7" : "h6",
                component: "h3",
                children: item?.module_name
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
                direction: "row",
                alignItems: "center",
                spacing: 1,
                justifyContent: item?.module_type !== "parcel" ? "space-between" : "flex-end",
                sx: {
                    position: "relative",
                    "&:hover": {
                        color: (theme)=>theme.palette.whiteContainer.main
                    }
                },
                children: [
                    item?.module_type !== "parcel" && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                variant: "body2",
                                color: "text.secondary",
                                className: "text",
                                children: t("Over")
                            }),
                            item?.module_type === "ecommerce" ? /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                variant: "body2",
                                color: "text.secondary",
                                className: "text",
                                children: [
                                    item?.items_count > 2 ? item?.items_count - 1 : item?.items_count,
                                    item?.items_count > 2 && "+",
                                    " ",
                                    t("Items")
                                ]
                            }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
                                variant: "body2",
                                color: "text.secondary",
                                className: "text",
                                children: [
                                    item?.stores_count > 2 ? item?.stores_count - 1 : item?.stores_count,
                                    item?.stores_count > 2 && "+",
                                    " ",
                                    item?.module_type === "food" ? t("Restaurants") : t("Store")
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ImageWrapper, {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                            src: item?.icon_full_url,
                            alt: item?.module_name,
                            height: "100%",
                            width: "100%",
                            obejctfit: "contained",
                            borderRadius: "5px"
                        })
                    })
                ]
            })
        ]
    });
};
const ModuleSelectionRaw = (props)=>{
    const { isSmall  } = props;
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useDispatch)();
    const { modules , configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_6__.useSelector)((state)=>state.configData);
    const [isSelected, setIsSelected] = (0,react__WEBPACK_IMPORTED_MODULE_4__.useState)((0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_15__/* .getCurrentModuleType */ .X)());
    const { data , refetch  } = (0,api_manage_hooks_react_query_useGetModule__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z)();
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        refetch();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_4__.useEffect)(()=>{
        if (data) {
            dispatch((0,redux_slices_configData__WEBPACK_IMPORTED_MODULE_14__/* .setModules */ .rm)(data));
        }
    }, [
        data
    ]);
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_3__.useRouter)();
    const handleClick = (item)=>{
        setIsSelected(item?.module_type);
        dispatch((0,redux_slices_utils__WEBPACK_IMPORTED_MODULE_8__/* .setSelectedModule */ .$w)(item));
        localStorage.setItem("module", JSON.stringify(item));
        router.replace("/home");
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: isSmall ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomBoxFullWidth */ .uu, {
            sx: {
                mt: "15px"
            },
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .SliderCustom */ .$_, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_7___default()), {
                    ..._sliderSettings__WEBPACK_IMPORTED_MODULE_12__/* .settings */ .X,
                    children: modules?.length > 0 && modules.map((item, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Card, {
                            item: item,
                            configData: configData,
                            isSelected: isSelected,
                            handleClick: handleClick
                        }, index);
                    })
                })
            })
        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_9__/* .CustomStackFullWidth */ .Xw, {
            flexDirection: "row",
            alignItems: "center",
            flexWrap: "wrap",
            gap: "15px",
            mt: "30px",
            children: modules?.length > 0 && modules.map((item, index)=>{
                return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Card, {
                    item: item,
                    configData: configData,
                    isSelected: isSelected,
                    handleClick: handleClick
                }, index);
            })
        })
    });
};
ModuleSelectionRaw.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ModuleSelectionRaw);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 25341:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "X": () => (/* binding */ settings)
/* harmony export */ });
const settings = {
    dots: false,
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 1,
    responsive: [
        {
            breakpoint: 760,
            settings: {
                slidesToShow: 3.5,
                slidesToScroll: 1,
                infinite: false
            }
        },
        {
            breakpoint: 650,
            settings: {
                slidesToShow: 3,
                slidesToScroll: 1,
                infinite: false
            }
        },
        {
            breakpoint: 550,
            settings: {
                slidesToShow: 2.5,
                slidesToScroll: 1,
                infinite: false
            }
        },
        {
            breakpoint: 450,
            settings: {
                slidesToShow: 2,
                slidesToScroll: 1
            }
        },
        {
            breakpoint: 350,
            settings: {
                slidesToShow: 1.5,
                slidesToScroll: 1
            }
        }
    ]
};


/***/ }),

/***/ 42994:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var components_landing_page_AvailableZoneSection__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(12703);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5152);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dynamic__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_geolocated__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(11022);
/* harmony import */ var react_geolocated__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_geolocated__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _CookiesConsent__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(26873);
/* harmony import */ var _PushNotificationLayout__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(74724);
/* harmony import */ var _app_download_section_index__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(30725);
/* harmony import */ var _Banners__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(53073);
/* harmony import */ var _ComponentOne__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(47922);
/* harmony import */ var _ComponentTwo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(21281);
/* harmony import */ var _DiscountBanner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(98463);
/* harmony import */ var _hero_section_HeroSection__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(86776);
/* harmony import */ var _Registration__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(23254);
/* harmony import */ var _bg_img__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(2313);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(41664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(45269);
/* harmony import */ var _hero_section_HeroLocationForm__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(80558);
/* harmony import */ var _ComponentThree__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(70412);
/* harmony import */ var _EarnMoney__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(67763);
/* harmony import */ var _CustomReviews__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(95440);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([components_landing_page_AvailableZoneSection__WEBPACK_IMPORTED_MODULE_2__, _CookiesConsent__WEBPACK_IMPORTED_MODULE_7__, _PushNotificationLayout__WEBPACK_IMPORTED_MODULE_8__, _app_download_section_index__WEBPACK_IMPORTED_MODULE_9__, _ComponentOne__WEBPACK_IMPORTED_MODULE_11__, _ComponentTwo__WEBPACK_IMPORTED_MODULE_12__, _hero_section_HeroSection__WEBPACK_IMPORTED_MODULE_14__, _Registration__WEBPACK_IMPORTED_MODULE_15__, _hero_section_HeroLocationForm__WEBPACK_IMPORTED_MODULE_19__]);
([components_landing_page_AvailableZoneSection__WEBPACK_IMPORTED_MODULE_2__, _CookiesConsent__WEBPACK_IMPORTED_MODULE_7__, _PushNotificationLayout__WEBPACK_IMPORTED_MODULE_8__, _app_download_section_index__WEBPACK_IMPORTED_MODULE_9__, _ComponentOne__WEBPACK_IMPORTED_MODULE_11__, _ComponentTwo__WEBPACK_IMPORTED_MODULE_12__, _hero_section_HeroSection__WEBPACK_IMPORTED_MODULE_14__, _Registration__WEBPACK_IMPORTED_MODULE_15__, _hero_section_HeroLocationForm__WEBPACK_IMPORTED_MODULE_19__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);























const MapModal = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>__webpack_require__.e(/* import() */ 3602).then(__webpack_require__.bind(__webpack_require__, 80233)), {
    loadableGenerated: {
        modules: [
            "..\\src\\components\\landing-page\\index.js -> " + "../Map/MapModal"
        ]
    }
});
const LandingPage = ({ configData , landingPageData  })=>{
    const Testimonials = next_dynamic__WEBPACK_IMPORTED_MODULE_3___default()(()=>Promise.all(/* import() */[__webpack_require__.e(9419), __webpack_require__.e(949)]).then(__webpack_require__.bind(__webpack_require__, 30949)), {
        loadableGenerated: {
            modules: [
                "..\\src\\components\\landing-page\\index.js -> " + "./Testimonials"
            ]
        },
        ssr: false
    });
    const [location, setLocation] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(undefined);
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_5__.useState)(false);
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    const { coords  } = (0,react_geolocated__WEBPACK_IMPORTED_MODULE_6__.useGeolocated)({
        positionOptions: {
            enableHighAccuracy: false
        },
        userDecisionTimeout: 5000,
        isGeolocationEnabled: true
    });
    (0,react__WEBPACK_IMPORTED_MODULE_5__.useEffect)(()=>{
        setLocation(JSON.stringify(localStorage.getItem("location")));
    }, []);
    const handleClose = ()=>{
        const location = localStorage.getItem("location");
        const isModuleExist = localStorage.getItem("module");
        if (location) {
            isModuleExist && setOpen(false);
        } else {}
    };
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const handleOrderNow = ()=>{
        if (location) {
            if (location === "null") {
                setOpen(true);
            } else {
                router.push("/home", undefined, {
                    shallow: true
                });
            }
        } else {
            setOpen(true);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_PushNotificationLayout__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z, {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    style: {
                        position: "relative",
                        zIndex: 10,
                        backgroundImage: "url(/landingpage/bg-1.png)",
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                        minHeight: "33rem",
                        height: "33rem"
                    },
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        style: {
                            position: "absolute",
                            top: "30%",
                            left: "13%"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                style: {
                                    color: "white",
                                    fontSize: "1.3rem",
                                    fontWeight: 900
                                },
                                children: [
                                    "FOOD PRODUCTS, MEALS, AND MUCH MORE",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                style: {
                                    color: "#273472",
                                    fontSize: "1rem",
                                    fontWeight: 700
                                },
                                children: [
                                    "Just a click away, delivered easily, right to your door!",
                                    " "
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ComponentOne__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    landingPageData: landingPageData,
                    configData: configData,
                    handleOrderNow: handleOrderNow
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ComponentTwo__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                    configData: configData,
                    landingPageData: landingPageData
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    style: {
                        backgroundColor: "#263471",
                        padding: "0px",
                        width: "60%",
                        borderRadius: "3rem",
                        marginTop: "0px",
                        margin: "auto"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_ComponentThree__WEBPACK_IMPORTED_MODULE_20__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_EarnMoney__WEBPACK_IMPORTED_MODULE_21__/* ["default"] */ .Z, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomReviews__WEBPACK_IMPORTED_MODULE_22__/* ["default"] */ .Z, {})
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LandingPage);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
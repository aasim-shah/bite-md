"use strict";
exports.id = 2161;
exports.ids = [2161];
exports.modules = {

/***/ 91326:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "K": () => (/* binding */ GoogleApi)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__]);
_MainApi__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const GoogleApi = {
    placeApiAutocomplete: (search)=>{
        if (search && search !== "") {
            return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/config/place-api-autocomplete?search_text=${search}`);
        }
    },
    placeApiDetails: (placeId)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/config/place-api-details?placeid=${placeId}`);
    },
    getZoneId: (location)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/config/get-zone-id?lat=${location.lat}&lng=${location.lng}`);
    },
    distanceApi: (origin, destination)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/config/distance-api?origin_lat=${origin.latitude}&origin_lng=${origin.longitude}&destination_lat=${destination.lat ? destination.lat : destination?.latitude}&destination_lng=${destination.lng ? destination.lng : destination?.longitude}&mode=walking`);
    },
    geoCodeApi: (location)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/config/geocode-api?lat=${location.lat}&lng=${location.lng}`);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 24073:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ useGetTrackOrderData)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
/* harmony import */ var _ApiRoutes__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(60274);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var _helper_functions_getToken__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(61859);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([_MainApi__WEBPACK_IMPORTED_MODULE_0__, _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);





const getData = async (order_id, phone, guestId)=>{
    const userToken = (0,_helper_functions_getToken__WEBPACK_IMPORTED_MODULE_3__/* .getToken */ .L)();
    try {
        const params = !userToken ? `?order_id=${order_id}&guest_id=${guestId}&contact_number=${phone}` : `?order_id=${order_id}`;
        const { data  } = await _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`${_ApiRoutes__WEBPACK_IMPORTED_MODULE_4__/* .track_order_api */ .NP}${params}`);
        return data;
    } catch (error) {
        throw error;
    }
};
function useGetTrackOrderData(order_id, phone, guestId, handleSuccess) {
    return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)("track-order-data", ()=>getData(order_id, phone, guestId), {
        onSuccess: handleSuccess,
        enabled: false,
        retry: 1,
        onError: _api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onErrorResponse */ .RJ
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 93666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ CustomStepperStyled)
/* harmony export */ });
/* unused harmony export StepBox */
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_1__);


const StepBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_1__.Box)(()=>({
        padding: "40px 0px 40px 0px",
        width: "100%"
    }));
const CustomStepperStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stepper)(({ theme , width , height , border , color , marginLeft , marginTop , connectorHeight , parcel  })=>({
        "& .MuiStepConnector-line": {
            height: connectorHeight ? connectorHeight : "30px",
            borderColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)(theme.palette.primary.main, 0.2),
            marginLeft: parcel === "true" && "20px",
            marginBottom: parcel === "true" && "-43px",
            [theme.breakpoints.down("sm")]: {
                marginLeft: parcel === "true" && "12px"
            }
        },
        "& .MuiStepConnector-root.Mui-active .MuiStepConnector-line": {
            borderColor: theme.palette.primary.main,
            height: connectorHeight ? connectorHeight : "30px"
        },
        "& .MuiStepConnector-root.Mui-completed .MuiStepConnector-line": {
            borderColor: theme.palette.primary.main,
            height: connectorHeight ? connectorHeight : "30px"
        },
        "& .MuiStepLabel-iconContainer .Mui-active": {
            marginTop: "0px",
            width: width ? width : "10px",
            height: height ? height : "10px",
            borderRadius: "50%",
            color: color ? color : theme.palette.neutral[100]
        },
        "& .MuiStepLabel-iconContainer .Mui-completed": {
            width: "32px",
            height: "20px",
            borderColor: theme.palette.primary.main
        },
        "& .MuiStepContent-root": {},
        "& .MuiStepLabel-label": {
            color: color,
            fontSize: "13px",
            marginBottom: "4px",
            marginLeft: marginLeft ? marginLeft : "0px",
            marginTop: marginTop ? marginTop : "0px"
        },
        "& .MuiStepLabel-label.Mui-active": {
            color: color,
            fontSize: "13px",
            fontWeight: 400
        },
        "& .MuiStepLabel-iconContainer ": {
            width: "32px",
            height: "20px",
            borderColor: theme.palette.primary.main
        },
        "& .MuiStepConnector-root ": {
            color: theme.palette.primary.main,
            marginLeft: "3px",
            "& .MuiStepConnector-line": {
                borderLeftWidth: parcel === "true" ? "1px dash" : "3px",
                color: parcel === "true" ? theme.palette.neutral[400] : theme.palette.primary.main,
                marginTop: parcel === "true" ? "-18px" : "-11px",
                [theme.breakpoints.down("sm")]: {
                    marginTop: parcel === "true" ? "-31px" : "-11px"
                }
            }
        },
        "& .MuiSvgIcon-root": {
            width: width ? width : "10px",
            height: height ? height : "10px",
            color: color ? color : theme.palette.neutral[100],
            border: border ? border : "2px solid",
            borderColor: theme.palette.primary.main,
            borderRadius: "50%"
        },
        "& .MuiStepLabel-root": {
            padding: "0px"
        }
    }));


/***/ })

};
;
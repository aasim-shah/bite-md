"use strict";
exports.id = 1935;
exports.ids = [1935];
exports.modules = {

/***/ 97372:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ useGetConfigData)
/* harmony export */ });
/* unused harmony export getData */
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61175);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var api_manage_MainApi__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(61176);
/* harmony import */ var api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(67759);
/* harmony import */ var api_manage_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(60274);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([api_manage_MainApi__WEBPACK_IMPORTED_MODULE_1__, api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__]);
([api_manage_MainApi__WEBPACK_IMPORTED_MODULE_1__, api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);




const getData = async ()=>{
    const { data  } = await api_manage_MainApi__WEBPACK_IMPORTED_MODULE_1__/* ["default"].get */ .Z.get(api_manage_ApiRoutes__WEBPACK_IMPORTED_MODULE_3__/* .config_api */ .Ax);
    return data;
};
const useGetConfigData = (handleSuccess)=>{
    return (0,react_query__WEBPACK_IMPORTED_MODULE_0__.useQuery)("getConfig", ()=>getData(), {
        enabled: false,
        onError: api_manage_api_error_response_ErrorResponses__WEBPACK_IMPORTED_MODULE_2__/* .onSingleErrorResponse */ .f$,
        retry: 1,
        cacheTime: 400
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 69893:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77591);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(15594);
/* harmony import */ var _mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4173);
/* harmony import */ var _mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(22021);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(38017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _spinner_AnimationDots__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(60899);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([i18next__WEBPACK_IMPORTED_MODULE_6__]);
i18next__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];










const CustomMapSearch = ({ showCurrentLocation , predictions , handleChange , HandleChangeForSearch , handleAgreeLocation , currentLocation , handleCloseLocation , frommap , placesIsLoading , currentLocationValue , fromparcel , isLoading , noleftborder , testLocation , borderRadius , toReceiver , isLanding =false , placeId , handleCloseLocation1 , isRefetching , newMap , width  })=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const isXSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            style: {
                width: "100%"
            },
            children: !showCurrentLocation ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Autocomplete, {
                fullWidth: true,
                options: predictions,
                getOptionLabel: (option)=>option.description,
                onChange: (event, value)=>handleChange(event, value),
                value: currentLocationValue,
                clearOnBlur: false,
                loading: frommap === "true" ? placesIsLoading : null,
                // open={true}
                loadingText: frommap === "true" ? (0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Search suggestions are loading...") : "",
                PaperComponent: (props)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Paper, {
                        sx: {
                            borderRadius: "0 0 4px 4px",
                            width: "100%"
                        },
                        ...props
                    }),
                renderInput: (params)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_2__/* .SearchLocationTextField */ .l7, {
                        noleftborder: noleftborder,
                        frommap: frommap,
                        fromparcel: fromparcel,
                        id: "outlined-basic",
                        ...params,
                        placeholder: (0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Search location here..."),
                        isLanding: true,
                        isXSmall: true,
                        onChange: (event)=>HandleChangeForSearch(event),
                        InputProps: {
                            ...params.InputProps,
                            endAdornment: frommap === "true" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                sx: {
                                    mr: "-31px",
                                    borderRadius: borderRadius ? borderRadius : "0px",
                                    padding: "7px 10px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_7___default()), {})
                            }) : currentLocationValue?.description ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                sx: {
                                    mr: "-61px",
                                    padding: "5px"
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5___default()), {
                                    style: {
                                        cursor: "pointer",
                                        height: "20px"
                                    },
                                    onClick: ()=>handleCloseLocation()
                                })
                            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                                children: toReceiver === "true" ? null : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                                    sx: {
                                        mr: fromparcel === "true" ? "-61px" : "-31px",
                                        padding: "5px",
                                        display: fromparcel !== "true" && "none"
                                    },
                                    onClick: ()=>handleAgreeLocation(),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        color: "primary"
                                    })
                                })
                            })
                        },
                        required: true
                    })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_landing_page_hero_section_HeroSection_style__WEBPACK_IMPORTED_MODULE_2__/* .SearchLocationTextField */ .l7, {
                margin_top: "true",
                size: "small",
                variant: "outlined",
                id: "outlined-basic",
                placeholder: (0,i18next__WEBPACK_IMPORTED_MODULE_6__.t)("Search location here..."),
                value: testLocation ? testLocation : currentLocation,
                onChange: (event)=>HandleChangeForSearch(event),
                required: true,
                isLanding: true,
                isXSmall: true,
                frommap: frommap,
                fromparcel: fromparcel,
                InputProps: {
                    endAdornment: !showCurrentLocation ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                        onClick: ()=>handleAgreeLocation(),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_GpsFixed__WEBPACK_IMPORTED_MODULE_4___default()), {
                            color: "primary"
                        })
                    }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_8__.Stack, {
                        mr: isLanding ? "50px" : "0",
                        children: isLoading || isRefetching ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_spinner_AnimationDots__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton, {
                            sx: {
                                padding: "5px",
                                marginRight: isXSmall ? "0px" : "0px"
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Close__WEBPACK_IMPORTED_MODULE_5___default()), {
                                sx: {
                                    cursor: "pointer",
                                    fontSize: isXSmall ? "16px" : "24px"
                                },
                                onClick: ()=>handleCloseLocation()
                            })
                        })
                    })
                }
            })
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CustomMapSearch);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 60899:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);




const AnimationDots = ()=>{
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useTheme)();
    const isXsmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.useMediaQuery)(theme.breakpoints.down("sm"));
    const AnimationDot = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)("div")({
        position: "relative",
        textAlign: "center",
        width: "35px",
        height: "100%",
        marginLeft: "auto",
        marginRight: "auto"
    });
    const Dot = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)("span")(({ theme  })=>({
            display: "inline-block",
            width: isXsmall ? "4px" : "5px",
            height: isXsmall ? "4px" : "5px",
            borderRadius: "50%",
            marginRight: "3px",
            background: theme.palette.primary.main,
            animation: "wave 1.3s linear infinite",
            "&:nth-child(2)": {
                animationDelay: "-1.1s"
            },
            "&:nth-child(3)": {
                animationDelay: "-0.9s"
            },
            "@keyframes wave": {
                "0%, 60%, 100%": {
                    transform: "initial"
                },
                "30%": {
                    transform: "translateY(-15px)"
                }
            }
        }));
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(AnimationDot, {
        isXsmall: isXsmall,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Dot, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Dot, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Dot, {})
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AnimationDots);


/***/ })

};
;
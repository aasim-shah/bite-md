"use strict";
exports.id = 5938;
exports.ids = [5938];
exports.modules = {

/***/ 60274:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$p": () => (/* binding */ common_condition_product_in_store),
/* harmony export */   "Ax": () => (/* binding */ config_api),
/* harmony export */   "Bn": () => (/* binding */ all_cart_list),
/* harmony export */   "Cz": () => (/* binding */ categories_details_api),
/* harmony export */   "D4": () => (/* binding */ check_zone),
/* harmony export */   "DR": () => (/* binding */ placeApiAutocomplete_api),
/* harmony export */   "Fg": () => (/* binding */ moduleList),
/* harmony export */   "Fp": () => (/* binding */ submit_deliveryman_review_api),
/* harmony export */   "Fq": () => (/* binding */ get_conversations_api),
/* harmony export */   "GA": () => (/* binding */ new_arrival_stores_api),
/* harmony export */   "Gi": () => (/* binding */ parcel_whyChoose_api),
/* harmony export */   "Gl": () => (/* binding */ coupon_list_api),
/* harmony export */   "HM": () => (/* binding */ LP_transactions_list_api),
/* harmony export */   "HR": () => (/* binding */ store_details_api),
/* harmony export */   "Hm": () => (/* binding */ cm_firebase_token_api),
/* harmony export */   "It": () => (/* binding */ get_channel_list),
/* harmony export */   "JA": () => (/* binding */ categories_api),
/* harmony export */   "JF": () => (/* binding */ signIn_api),
/* harmony export */   "Jx": () => (/* binding */ subscribe_api),
/* harmony export */   "Jz": () => (/* binding */ cancel_last_item_review),
/* harmony export */   "KZ": () => (/* binding */ basic_campaigns_api),
/* harmony export */   "LA": () => (/* binding */ suggested_items_stores),
/* harmony export */   "LQ": () => (/* binding */ cashback_amount),
/* harmony export */   "Mo": () => (/* binding */ cart_item_update),
/* harmony export */   "N5": () => (/* binding */ distance_api),
/* harmony export */   "NK": () => (/* binding */ discounted_product_api),
/* harmony export */   "NP": () => (/* binding */ track_order_api),
/* harmony export */   "Nn": () => (/* binding */ get_search_page_data),
/* harmony export */   "Nv": () => (/* binding */ update_payment_method_api),
/* harmony export */   "OL": () => (/* binding */ update_interest_api),
/* harmony export */   "PB": () => (/* binding */ cart_all_item_remove),
/* harmony export */   "Pb": () => (/* binding */ store_registration),
/* harmony export */   "Pt": () => (/* binding */ channel_search_api),
/* harmony export */   "Q4": () => (/* binding */ suggestedProducts_api),
/* harmony export */   "QH": () => (/* binding */ my_orders_api),
/* harmony export */   "RO": () => (/* binding */ profile_info),
/* harmony export */   "RY": () => (/* binding */ get_wish_list_api),
/* harmony export */   "SM": () => (/* binding */ basic_campaigns_details_api),
/* harmony export */   "Ty": () => (/* binding */ banners),
/* harmony export */   "WG": () => (/* binding */ brand_list),
/* harmony export */   "WH": () => (/* binding */ order_details_api),
/* harmony export */   "Y4": () => (/* binding */ store_business_plan),
/* harmony export */   "Yp": () => (/* binding */ latest_store_api),
/* harmony export */   "ZM": () => (/* binding */ Loyalty_points_transfer_api),
/* harmony export */   "ZU": () => (/* binding */ store_review_api),
/* harmony export */   "Zk": () => (/* binding */ guest_checkout),
/* harmony export */   "Zv": () => (/* binding */ cart_item_delete),
/* harmony export */   "_3": () => (/* binding */ top_offer_near_me),
/* harmony export */   "_d": () => (/* binding */ popular_items_in_store),
/* harmony export */   "aD": () => (/* binding */ visit_again),
/* harmony export */   "aj": () => (/* binding */ automated_message),
/* harmony export */   "av": () => (/* binding */ cashback_list),
/* harmony export */   "b9": () => (/* binding */ others_banners),
/* harmony export */   "bS": () => (/* binding */ zone_list),
/* harmony export */   "bU": () => (/* binding */ data_limit),
/* harmony export */   "cT": () => (/* binding */ last_item_review),
/* harmony export */   "ch": () => (/* binding */ popular_items),
/* harmony export */   "cp": () => (/* binding */ most_trips),
/* harmony export */   "d6": () => (/* binding */ profile_update_api),
/* harmony export */   "eE": () => (/* binding */ order_cancel_api),
/* harmony export */   "en": () => (/* binding */ delete_wish_list_api),
/* harmony export */   "fP": () => (/* binding */ refund_reasons_api),
/* harmony export */   "fb": () => (/* binding */ delete_address_api),
/* harmony export */   "fy": () => (/* binding */ remove_account_api),
/* harmony export */   "gb": () => (/* binding */ item_add_to_cart),
/* harmony export */   "h6": () => (/* binding */ signUp_api),
/* harmony export */   "hF": () => (/* binding */ common_condition_api),
/* harmony export */   "iD": () => (/* binding */ add_wish_list_api),
/* harmony export */   "ig": () => (/* binding */ verify_phone_api),
/* harmony export */   "jP": () => (/* binding */ parcel_category_api),
/* harmony export */   "jT": () => (/* binding */ update_address_api),
/* harmony export */   "jv": () => (/* binding */ order_place_api),
/* harmony export */   "k6": () => (/* binding */ offline_payment_options),
/* harmony export */   "kY": () => (/* binding */ wallet_transactions_list_api),
/* harmony export */   "kg": () => (/* binding */ campaigns_item),
/* harmony export */   "kw": () => (/* binding */ social_register_api),
/* harmony export */   "kz": () => (/* binding */ parcel_video_api),
/* harmony export */   "l8": () => (/* binding */ add_fund_to_wallet),
/* harmony export */   "lC": () => (/* binding */ common_conditions_product_api),
/* harmony export */   "m$": () => (/* binding */ landing_page_api),
/* harmony export */   "m3": () => (/* binding */ typewise_store_api),
/* harmony export */   "mC": () => (/* binding */ new_arrivals),
/* harmony export */   "mG": () => (/* binding */ firebase_otp),
/* harmony export */   "mM": () => (/* binding */ submit_items_review_api),
/* harmony export */   "mj": () => (/* binding */ vehicle_list),
/* harmony export */   "nH": () => (/* binding */ filtered_stores_api),
/* harmony export */   "nZ": () => (/* binding */ placedetails_api),
/* harmony export */   "o$": () => (/* binding */ address_list_api),
/* harmony export */   "o2": () => (/* binding */ paid_ads),
/* harmony export */   "q8": () => (/* binding */ more_from_store),
/* harmony export */   "q9": () => (/* binding */ discounted_stores_api),
/* harmony export */   "qS": () => (/* binding */ geocode_api),
/* harmony export */   "qY": () => (/* binding */ store_item_search_api),
/* harmony export */   "sL": () => (/* binding */ social_login_api),
/* harmony export */   "sS": () => (/* binding */ popular_store_api),
/* harmony export */   "sV": () => (/* binding */ delivery_man_registaration),
/* harmony export */   "tA": () => (/* binding */ flash_sales),
/* harmony export */   "tE": () => (/* binding */ most_reviewed_items_api),
/* harmony export */   "td": () => (/* binding */ subCategories_api),
/* harmony export */   "u3": () => (/* binding */ parcel_delivery_instructions),
/* harmony export */   "ul": () => (/* binding */ user_info_api),
/* harmony export */   "v6": () => (/* binding */ wallet_bonuses),
/* harmony export */   "vV": () => (/* binding */ latest_items_api),
/* harmony export */   "vy": () => (/* binding */ zoneId_api),
/* harmony export */   "x": () => (/* binding */ product_reviews_api),
/* harmony export */   "x$": () => (/* binding */ add_address_api),
/* harmony export */   "xD": () => (/* binding */ store_message_api),
/* harmony export */   "xf": () => (/* binding */ subscription_package),
/* harmony export */   "yl": () => (/* binding */ flash_sales_items)
/* harmony export */ });
/* unused harmony exports top_rated_stores, similar_product_api, refund_policy_api, testimonial_api, categories_details_Store_api, categories_Childes_api, product_review_api, brand_products, delivery_men_store */
const data_limit = "10";
const config_api = "/api/v1/config";
const subscribe_api = "/api/v1/newsletter/subscribe";
const placeApiAutocomplete_api = "/api/v1/config/place-api-autocomplete";
const placedetails_api = "/api/v1/config/place-api-details";
//export const distance_api = "/api/v1/config/distance";
const geocode_api = "/api/v1/config/geocode-api";
const zoneId_api = "/api/v1/config/get-zone-id";
const moduleList = "/api/v1/module";
const banners = "/api/v1/banners";
const others_banners = "api/v1/other-banners";
const categories_api = "/api/v1/categories";
const campaigns_item = "/api/v1/campaigns/item";
const popular_items = "/api/v1/items/popular";
const common_condition_api = "api/v1/common-condition";
const common_conditions_product_api = "api/v1/common-condition/items";
const popular_store_api = "/api/v1/stores/popular";
const subCategories_api = "/api/v1/categories/childes";
const most_reviewed_items_api = "/api/v1/items/most-reviewed";
const latest_store_api = "/api/v1/stores/latest";
const latest_items_api = "/api/v1/items/latest";
const more_from_store = "/api/v1/items/related-store-items";
const new_arrivals = "/api/v1/items/new-arrival";
const flash_sales = "/api/v1/flash-sales";
const flash_sales_items = "api/v1/flash-sales/items";
const parcel_category_api = "/api/v1/parcel-category";
const parcel_video_api = "api/v1/other-banners/video-content";
const parcel_whyChoose_api = "api/v1/other-banners/why-choose";
const distance_api = "/api/v1/config/distance-api";
const new_arrival_stores_api = "/api/v1/stores/latest";
const filtered_stores_api = "/api/v1/stores/get-stores";
const top_rated_stores = "/api/v1/stores/top-rated";
const store_details_api = "/api/v1/stores/details";
const signUp_api = "/api/v1/auth/sign-up";
const signIn_api = "/api/v1/auth/login";
const guest_checkout = "api/v1/auth/guest/request";
const profile_info = "/api/v1/customer/info";
const store_item_search_api = "/api/v1/items/search";
const parcel_delivery_instructions = "/api/v1/customer/order/parcel-instructions";
const order_place_api = "/api/v1/customer/order/place";
const my_orders_api = "/api/v1/customer/order";
const user_info_api = "/api/v1/customer/info";
const remove_account_api = "/api/v1/customer/remove-account";
const profile_update_api = "/api/v1/customer/update-profile";
const coupon_list_api = "/api/v1/coupon/list";
const similar_product_api = "/api/v1/items/related-items";
const discounted_product_api = "/api/v1/items/discounted";
const discounted_stores_api = "/api/v1/stores/discounted";
const popular_items_in_store = "api/v1/items/recommended";
const common_condition_product_in_store = "/api/v1/items/common-conditions";
const wallet_transactions_list_api = "/api/v1/customer/wallet/transactions";
const LP_transactions_list_api = "/api/v1/customer/loyalty-point/transactions";
const Loyalty_points_transfer_api = "/api/v1/customer/loyalty-point/point-transfer";
const address_list_api = "/api/v1/customer/address/list";
const add_address_api = "/api/v1/customer/address/add";
const update_address_api = "/api/v1/customer/address/update";
const delete_address_api = "/api/v1/customer/address/delete";
const refund_policy_api = "/refund";
const product_reviews_api = "/api/v1/items/reviews";
const add_wish_list_api = "/api/v1/customer/wish-list/add";
const get_wish_list_api = "/api/v1/customer/wish-list";
const delete_wish_list_api = "/api/v1/customer/wish-list/remove";
const get_channel_list = "/api/v1/customer/message/list";
const get_conversations_api = "/api/v1/customer/message/details";
const store_message_api = "/api/v1/customer/message/send";
const channel_search_api = "/api/v1/customer/message/search-list";
const cm_firebase_token_api = "/api/v1/customer/cm-firebase-token";
const suggestedProducts_api = "/api/v1/customer/suggested-items";
const suggested_items_stores = "/api/v1/items/item-or-store-search";
const order_details_api = "/api/v1/customer/order/details";
const track_order_api = "/api/v1/customer/order/track";
const order_cancel_api = "/api/v1/customer/order/cancel";
const offline_payment_options = "/api/v1/offline_payment_method_list";
const update_payment_method_api = "/api/v1/customer/order/payment-method";
const refund_reasons_api = "/api/v1/customer/order/refund-reasons";
const testimonial_api = "/api/v1/testimonial";
const categories_details_api = "/api/v1/categories/items";
const categories_details_Store_api = "/api/v1/categories/stores";
const categories_Childes_api = "/api/v1/categories/childes";
const basic_campaigns_api = "api/v1/campaigns/basic";
const basic_campaigns_details_api = "/api/v1/campaigns/basic-campaign-details";
const typewise_store_api = "/api/v1/stores";
const social_login_api = "/api/v1/auth/social-login";
const verify_phone_api = "/api/v1/auth/verify-phone";
const social_register_api = "/api/v1/auth/social-register";
const store_review_api = "/api/v1/stores/reviews";
const submit_items_review_api = "/api/v1/items/reviews/submit";
const submit_deliveryman_review_api = "/api/v1/delivery-man/reviews/submit";
const update_interest_api = "/api/v1/customer/update-interest";
const landing_page_api = "/api/v1/react-landing-page";
const most_trips = "/api/v1/most-tips";
const wallet_bonuses = "/api/v1/customer/wallet/bonuses";
const add_fund_to_wallet = "api/v1/customer/wallet/add-fund";
const product_review_api = "/api/v1/items/related-items";
const item_add_to_cart = "api/v1/customer/cart/add";
const cart_all_item_remove = "api/v1/customer/cart/remove";
const all_cart_list = "api/v1/customer/cart/list";
const cart_item_delete = "api/v1/customer/cart/remove-item";
const cart_item_update = "api/v1/customer/cart/update";
const last_item_review = "api/v1/customer/review-reminder";
const cancel_last_item_review = "api/v1/customer/review-reminder-cancel";
const get_search_page_data = "api/v1/get-combined-data";
const cashback_list = "api/v1/cashback/list";
const cashback_amount = "api/v1/cashback/getCashback";
const brand_list = "api/v1/brand";
const brand_products = "api/v1/brand/items/";
const visit_again = "api/v1/customer/visit-again";
const paid_ads = "api/v1/advertisement/list";
const firebase_otp = "api/v1/auth/firebase-verify-token";
const automated_message = "api/v1/customer/automated-message";
const check_zone = "api/v1/zone/check";
const subscription_package = "/api/v1/vendor/package-view";
const store_registration = "api/v1/auth/vendor/register";
const store_business_plan = "/api/v1/vendor/business_plan";
const top_offer_near_me = "api/v1/stores/top-offer-near-me";
const delivery_men_store = "api/v1/delivery-man/store";
const vehicle_list = "/api/v1/get-vehicles";
const zone_list = "/api/v1/zone/list";
const delivery_man_registaration = "api/v1/auth/delivery-man/store"; // export const zone_list = "/api/v1/zone/list";


/***/ }),

/***/ 61176:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "F": () => (/* binding */ baseUrl),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(99648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const baseUrl = "https://bite.md";
const MainApi = axios__WEBPACK_IMPORTED_MODULE_0__["default"].create({
    baseURL: baseUrl
});
MainApi.interceptors.request.use(function(config) {
    let zoneid = undefined;
    let token = undefined;
    let language = undefined;
    let currentLocation = undefined;
    let software_id = 33571750;
    let hostname = process.env.NEXT_CLIENT_HOST_URL;
    let moduleid = undefined;
    if (false) {}
    if (currentLocation) config.headers.latitude = currentLocation.lat;
    if (currentLocation) config.headers.longitude = currentLocation.lng;
    if (zoneid) config.headers.zoneid = zoneid;
    if (moduleid) config.headers.moduleId = moduleid;
    if (token) config.headers.authorization = `Bearer ${token}`;
    if (language) config.headers["X-localization"] = language;
    if (hostname) config.headers["origin"] = hostname;
    config.headers["X-software-id"] = software_id;
    config.headers["Accept"] = "application/json";
    return config;
});
// MainApi.interceptors.response.use(
//     (response) => response,
//     (error) => {
//         if (error.response.status === 401) {
//             toast.error(t('Your token has been expired.please sign in again'), {
//                 id: 'error',
//             })
//             localStorage.removeItem('token')
//             store.dispatch(removeToken())
//         }
//         return Promise.reject(error)
//     }
// )
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainApi);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 67759:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "RJ": () => (/* binding */ onErrorResponse),
/* harmony export */   "f$": () => (/* binding */ onSingleErrorResponse),
/* harmony export */   "qz": () => (/* binding */ handleTokenExpire)
/* harmony export */ });
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(86201);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(22021);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_2__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hot_toast__WEBPACK_IMPORTED_MODULE_0__, i18next__WEBPACK_IMPORTED_MODULE_1__]);
([react_hot_toast__WEBPACK_IMPORTED_MODULE_0__, i18next__WEBPACK_IMPORTED_MODULE_1__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



const handleTokenExpire = (item, status)=>{
    if (status === 401) {
        if (window.localStorage.getItem("token")) {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_0__["default"].error((0,i18next__WEBPACK_IMPORTED_MODULE_1__.t)("Your account is inactive or Your token has been expired"));
            window?.localStorage.removeItem("token");
            next_router__WEBPACK_IMPORTED_MODULE_2___default().push("/home", undefined, {
                shallow: true
            });
        }
    } else {
        react_hot_toast__WEBPACK_IMPORTED_MODULE_0__["default"].error(item?.message, {
            id: "error"
        });
    }
};
const onErrorResponse = (error)=>{
    error?.response?.data?.errors?.forEach((item)=>{
        handleTokenExpire(item);
    });
};
const onSingleErrorResponse = (error)=>{
    react_hot_toast__WEBPACK_IMPORTED_MODULE_0__["default"].error(error?.response?.data?.message, {
        id: "error"
    });
    handleTokenExpire(error, error?.response?.status);
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 58861:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_CustomImageContainer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(20997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(16689);
// EXTERNAL MODULE: ./src/styled-components/CustomStyles.style.js
var CustomStyles_style = __webpack_require__(45269);
;// CONCATENATED MODULE: ./public/static/no-image-found.png
/* harmony default export */ const no_image_found = ({"src":"/_next/static/media/no-image-found.0dc47f70.png","height":2000,"width":2000,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAPUlEQVR42mM4n3Y+7RwEglkMQArGBWMGMAWEMBqs4mz6wZx9uWfTgYIwgX25+3PPQsyAKb6QimwGhi1IEACBC0z5yYZiXQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: external "@mui/system"
var system_ = __webpack_require__(97986);
;// CONCATENATED MODULE: ./src/components/CustomImageContainer.js





const CustomImageContainer = ({ cursor , mdHeight , maxWidth , height , width , objectfit , minwidth , src , alt , borderRadius , marginBottom , smHeight , smMb , smMaxWidth , smWidth , aspectRatio , padding , loading  })=>{
    const [imageFile, setState] = (0,external_react_.useState)(null);
    (0,external_react_.useEffect)(()=>{
        setState(src ? src : no_image_found.src);
    }, [
        src
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(CustomStyles_style/* CustomImageContainerStyled */.SE, {
        height: height,
        width: width,
        objectfit: objectfit,
        minwidth: minwidth,
        border_radius: borderRadius,
        margin_bottom: marginBottom,
        smheight: smHeight,
        sm_mb: smMb,
        max_width: maxWidth,
        sm_max_width: smMaxWidth,
        sm_width: smWidth,
        md_height: mdHeight,
        cursor: cursor,
        aspect_ratio: aspectRatio,
        padding: padding,
        children: !imageFile ? /*#__PURE__*/ jsx_runtime_.jsx(system_.Box, {
            sx: {
                height: "100%",
                width: "100%",
                border: (theme)=>`1px solid ${theme.palette.neutral[200]}`
            }
        }) : /*#__PURE__*/ jsx_runtime_.jsx("img", {
            src: imageFile,
            alt: alt || "image",
            onError: ()=>{
                setState(no_image_found.src);
            },
            loading: loading || "lazy"
        })
    });
};
/* harmony default export */ const components_CustomImageContainer = (/*#__PURE__*/(0,external_react_.memo)(CustomImageContainer));


/***/ }),

/***/ 53236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "D1": () => (/* binding */ setLandingPageData),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zr": () => (/* binding */ setConfigData),
/* harmony export */   "m0": () => (/* binding */ setLanguage),
/* harmony export */   "mY": () => (/* binding */ setCountryCode),
/* harmony export */   "rm": () => (/* binding */ setModules)
/* harmony export */ });
/* unused harmony export configDataSlice */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(75184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const initialState = {
    configData: null,
    language: "",
    countryCode: "",
    modules: [],
    landingPageData: null
};
// Action creators are generated for each case reducer function
const configDataSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "config-data",
    initialState,
    reducers: {
        setConfigData: (state, action)=>{
            state.configData = action.payload;
        },
        setLanguage: (state, action)=>{
            state.language = action.payload;
        },
        setCountryCode: (state, action)=>{
            state.countryCode = action.payload;
        },
        setModules: (state, action)=>{
            state.modules = action.payload.map((item)=>item);
        },
        setLandingPageData: (state, action)=>{
            state.landingPageData = action.payload;
        }
    }
});
const { setLandingPageData , setConfigData , setCountryCode , setLanguage , setModules  } = configDataSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (configDataSlice.reducer);


/***/ })

};
;
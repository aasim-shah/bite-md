"use strict";
exports.id = 7847;
exports.ids = [7847];
exports.modules = {

/***/ 46356:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/empty.fb5e331e.png","height":400,"width":400,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAkklEQVR42mMIZug2Zygz3Wy6maGs2zyIgeFk8uH/C/7nAeGC/4f/n0xm2J208/fu37v+7Pqz+zeQlcSwiG3b1+X/J/2d8nf5/21fF7ExNDKtj53wYs//Lf8mPlsXX83E0MUyjyGvbs//rf+zWmcz9LMxMDD+Z2TgLmku7U6/MTG0jwEEGBkY+hgmM0yI7mnrZQAAjkVC4z+TQUUAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 67019:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ OrderApi)
/* harmony export */ });
/* harmony import */ var _MainApi__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(61176);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_MainApi__WEBPACK_IMPORTED_MODULE_0__]);
_MainApi__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

const OrderApi = {
    placeOrder: (formData)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/customer/order/place", formData);
    },
    prescriptionPlaceOrder: (orderData)=>{
        const { store_id , distance , address , longitude , latitude , prescriptionImages , order_note , guest_id , contact_person_name , contact_person_number , dm_tips  } = orderData;
        let formData = new FormData();
        formData.append("store_id", store_id);
        formData.append("distance", distance);
        formData.append("address", address);
        formData.append("longitude", longitude);
        formData.append("latitude", latitude);
        prescriptionImages.forEach((prescriptionImages)=>{
            formData.append("order_attachment[]", prescriptionImages);
        });
        formData.append("order_note", order_note);
        formData.append("guest_id", guest_id);
        formData.append("contact_person_number", contact_person_number);
        formData.append("contact_person_name", contact_person_name);
        formData.append("dm_tips", dm_tips);
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/customer/order/prescription/place", formData);
    },
    orderHistory: (orderType, limit, offset)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/customer/order/${orderType}?limit=${limit}&offset=${offset}`);
    },
    orderDetails: (order_id)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/customer/order/details?order_id=${order_id}`);
    },
    orderTracking: (order_id)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].get */ .Z.get(`/api/v1/customer/order/track?order_id=${order_id}`);
    },
    CancelOrder: (formData)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/customer/order/cancel", formData);
    },
    FailedPaymentMethodUpdate: (formData)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/customer/order/payment-method", formData);
    },
    FailedPaymentMethodCancel: (formData)=>{
        return _MainApi__WEBPACK_IMPORTED_MODULE_0__/* ["default"].post */ .Z.post("/api/v1/customer/order/cancel", formData);
    }
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 27523:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(45269);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(86872);
/* harmony import */ var _mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_TextsmsRounded__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(73247);
/* harmony import */ var _mui_icons_material_TextsmsRounded__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_TextsmsRounded__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(33378);
/* harmony import */ var _mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(53139);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _header_top_navbar_ClickToCall__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(22458);
/* harmony import */ var _helper_functions_getToken__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(61859);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(86201);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_12__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_emotion_react__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_11__]);
([_emotion_react__WEBPACK_IMPORTED_MODULE_8__, react_hot_toast__WEBPACK_IMPORTED_MODULE_11__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);














const ColorCard = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomStackFullWidth */ .Xw)(({ theme  })=>({
        background: (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.alpha)(theme.palette.primary.main, 0.2),
        padding: "20px 24px",
        marginTop: "10px",
        justifyContent: "space-between"
    }));
const RoundedIconButton = (0,_mui_system__WEBPACK_IMPORTED_MODULE_2__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.IconButton)(({ theme  })=>({
        background: theme.palette.neutral[100],
        padding: "11px",
        borderRadius: "50%"
    }));
const DeliveryManInfoCard = ({ deliveryManInfo  })=>{
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_8__.useTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_12__.useRouter)();
    const { configData  } = (0,react_redux__WEBPACK_IMPORTED_MODULE_9__.useSelector)((state)=>state.configData);
    const messageIconColor = (0,_mui_material__WEBPACK_IMPORTED_MODULE_3__.alpha)(theme.palette.moduleTheme.food, 0.5);
    const name = `${deliveryManInfo?.f_name} ${deliveryManInfo?.l_name}`;
    const handleClick = ()=>{
        if ((0,_helper_functions_getToken__WEBPACK_IMPORTED_MODULE_13__/* .getToken */ .L)()) {
            router.push({
                pathname: "/profile",
                query: {
                    page: "inbox",
                    type: "delivery_man",
                    id: deliveryManInfo?.id,
                    routeName: "delivery_man_id",
                    chatFrom: "true",
                    deliveryman_name: deliveryManData?.f_name,
                    deliveryManData_image: deliveryManData?.image
                }
            });
        } else {
            react_hot_toast__WEBPACK_IMPORTED_MODULE_11__["default"].error("uyrttgr");
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(ColorCard, {
        direction: "row",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                direction: "row",
                spacing: 1.5,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Avatar, {
                        src: deliveryManInfo?.image_full_url
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                children: name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                fontSize: "13px",
                                color: theme.palette.neutral[500],
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        style: {
                                            paddingRight: "2px"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_StarRate__WEBPACK_IMPORTED_MODULE_7___default()), {
                                            style: {
                                                width: "14px",
                                                height: "14px",
                                                color: messageIconColor
                                            }
                                        })
                                    }),
                                    deliveryManInfo?.avg_rating
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                direction: "row",
                spacing: 1.5,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_header_top_navbar_ClickToCall__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                        phone: deliveryManInfo?.phone,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RoundedIconButton, {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Phone__WEBPACK_IMPORTED_MODULE_5___default()), {
                                color: "primary",
                                style: {
                                    width: "20px",
                                    height: "20px"
                                }
                            })
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(RoundedIconButton, {
                        onClick: handleClick,
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_TextsmsRounded__WEBPACK_IMPORTED_MODULE_6___default()), {
                            style: {
                                width: "20px",
                                height: "20px",
                                color: messageIconColor
                            }
                        })
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DeliveryManInfoCard);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 86740:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _side_drawer_CustomSideDrawer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(82192);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(45269);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _Map_location_view_MapComponent__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(11775);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(53139);
/* harmony import */ var _mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(72625);
/* harmony import */ var _mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_ShareLocation__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(74431);
/* harmony import */ var _mui_icons_material_ShareLocation__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ShareLocation__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _CustomDivider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(35740);
/* harmony import */ var i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(22021);
/* harmony import */ var _checkout_parcel_DeliveryManInfo__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(27523);
/* harmony import */ var _parcel_ParcelTrackOderStepper__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(33224);
/* harmony import */ var _api_manage_hooks_react_query_order_useGetTrackOrderData__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(24073);
/* harmony import */ var _custom_empty_result__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(58797);
/* harmony import */ var helper_functions_getToken__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(61859);
/* harmony import */ var helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(89113);
/* harmony import */ var _assets_empty_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(46356);
/* harmony import */ var _added_cart_view_Cart_style__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(92497);
/* harmony import */ var _mui_icons_material_Clear__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(51653);
/* harmony import */ var _mui_icons_material_Clear__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Clear__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(71853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_20__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_Map_location_view_MapComponent__WEBPACK_IMPORTED_MODULE_5__, _emotion_react__WEBPACK_IMPORTED_MODULE_7__, i18next__WEBPACK_IMPORTED_MODULE_11__, _checkout_parcel_DeliveryManInfo__WEBPACK_IMPORTED_MODULE_12__, _api_manage_hooks_react_query_order_useGetTrackOrderData__WEBPACK_IMPORTED_MODULE_14__, _custom_empty_result__WEBPACK_IMPORTED_MODULE_15__]);
([_Map_location_view_MapComponent__WEBPACK_IMPORTED_MODULE_5__, _emotion_react__WEBPACK_IMPORTED_MODULE_7__, i18next__WEBPACK_IMPORTED_MODULE_11__, _checkout_parcel_DeliveryManInfo__WEBPACK_IMPORTED_MODULE_12__, _api_manage_hooks_react_query_order_useGetTrackOrderData__WEBPACK_IMPORTED_MODULE_14__, _custom_empty_result__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);






















const CustomLine = (0,_mui_system__WEBPACK_IMPORTED_MODULE_6__.styled)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Box)(({ theme  })=>({
        borderLeft: "1px dashed",
        borderColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.alpha)(theme.palette.neutral[500], 0.5),
        height: "81px",
        marginLeft: "8px"
    }));
const TrackParcelOrderDrawer = (props)=>{
    const theme = (0,_emotion_react__WEBPACK_IMPORTED_MODULE_7__.useTheme)();
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_20__.useRouter)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_4__.useMediaQuery)(theme.breakpoints.down("sm"));
    const [orderData, setOrderData] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);
    const { sideDrawerOpen , orderId , setSideDrawerOpen , phoneOrEmail  } = props;
    const [actStep, setActStep] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(1);
    const guestId = (0,helper_functions_getToken__WEBPACK_IMPORTED_MODULE_21__/* .getGuestId */ .P)();
    const phone = phoneOrEmail;
    const handleSuccess = (res)=>{
        setOrderData(res);
    };
    const { error , refetch , data: trackOrderData , isLoading , isRefetching  } = (0,_api_manage_hooks_react_query_order_useGetTrackOrderData__WEBPACK_IMPORTED_MODULE_14__/* ["default"] */ .Z)(orderId, phone, guestId, handleSuccess);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (orderId) {
            refetch();
        }
    }, [
        orderId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        const interval = setInterval(()=>{
            if (orderId && orderData && orderData?.order_status !== "delivered") {
                refetch();
            }
        }, 10000); // Refetch every 10 seconds (10,000 milliseconds)
        return ()=>{
            clearInterval(interval); // Clear the interval on component unmount
        };
    }, [
        refetch
    ]);
    const handleStepper = ()=>{
        if (trackOrderData?.order_status === "pending") {
            setActStep(1);
        } else if (trackOrderData?.order_status === "confirmed") {
            setActStep(2);
        } else if (trackOrderData?.order_status === "picked_up") {
            setActStep(3);
        } else if (trackOrderData?.order_status === "delivered") {
            setActStep(4);
        }
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        handleStepper();
    }, [
        actStep,
        trackOrderData,
        orderId
    ]);
    const steps = [
        {
            label: "Order Placed",
            time: trackOrderData?.pending
        },
        {
            label: "Order Confirmed",
            time: trackOrderData?.confirmed
        },
        {
            label: "On the Way",
            time: trackOrderData?.picked_up
        },
        {
            label: "Delivered",
            time: trackOrderData?.delivered
        }
    ];
    const closeHandler = ()=>{
        setOrderData(null);
        setSideDrawerOpen(false);
    };
    const handleClick = ()=>{
        router.push({
            pathname: "/profile",
            query: {
                orderId: trackOrderData?.id,
                page: "my-orders"
            }
        }, undefined, {
            shallow: true
        });
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_side_drawer_CustomSideDrawer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
        anchor: "right",
        open: sideDrawerOpen,
        onClose: closeHandler,
        variant: "temporary",
        maxWidth: "420px",
        width: "100%",
        height: "100vh",
        sx: {
            position: "relative"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                direction: "row",
                spacing: 1,
                alignItems: "center",
                sx: {
                    position: "absolute",
                    top: "1rem",
                    right: ".5rem"
                },
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_added_cart_view_Cart_style__WEBPACK_IMPORTED_MODULE_18__/* .CustomCloseIconButton */ .l8, {
                    onClick: closeHandler,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Clear__WEBPACK_IMPORTED_MODULE_19___default()), {
                        fontSize: "16px"
                    })
                })
            }),
            orderData && !isLoading && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                        padding: "30px 24px 0px 24px",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                justifyContent: "space-between",
                                direction: "row",
                                alignItems: "center",
                                mb: "10px",
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                    fontSize: "16px",
                                    fontWeight: "600",
                                    textAlign: "center",
                                    children: [
                                        "Order ID:",
                                        " ",
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                            component: "span",
                                            fontSize: "16px",
                                            fontWeight: "600",
                                            children: trackOrderData?.id
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                                sx: {
                                    position: "relative"
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Map_location_view_MapComponent__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                                        latitude: trackOrderData?.delivery_address?.latitude,
                                        longitude: trackOrderData?.delivery_address?.longitude,
                                        deliveryManLat: trackOrderData?.order_status === "picked_up" ? trackOrderData?.delivery_man?.lat : trackOrderData?.receiver_details?.latitude,
                                        deliveryManLng: trackOrderData?.order_status === "picked_up" ? trackOrderData?.delivery_man?.lng : trackOrderData?.receiver_details?.longitude
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                        position: "absolute",
                                        bottom: "-80px",
                                        width: "280px",
                                        left: {
                                            xs: "5%",
                                            sm: "8%",
                                            md: "16%"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomPaperBigCard */ .iD, {
                                            padding: "10px",
                                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                                                spacing: 1.5,
                                                direction: "row",
                                                alignItems: "center",
                                                pl: "10px",
                                                children: [
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                                        children: [
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ShareLocation__WEBPACK_IMPORTED_MODULE_9___default()), {
                                                                style: {
                                                                    height: "20px",
                                                                    width: "16px"
                                                                }
                                                            }),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(CustomLine, {}),
                                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_LocationOn__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                                style: {
                                                                    height: "20px",
                                                                    width: "16px"
                                                                }
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                                        spacing: 1,
                                                        children: [
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: "12px",
                                                                        color: theme.palette.primary.main,
                                                                        children: (0,i18next__WEBPACK_IMPORTED_MODULE_11__.t)("Sender")
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: "16px",
                                                                        children: trackOrderData?.delivery_address?.contact_person_name
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: "12px",
                                                                        color: theme.palette.neutral[400],
                                                                        children: trackOrderData?.delivery_address?.address
                                                                    })
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                                                children: [
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: "12px",
                                                                        color: theme.palette.primary.main,
                                                                        children: (0,i18next__WEBPACK_IMPORTED_MODULE_11__.t)("Receiver")
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: "16px",
                                                                        children: trackOrderData?.receiver_details?.contact_person_name
                                                                    }),
                                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                                                        fontSize: "12px",
                                                                        color: theme.palette.neutral[400],
                                                                        children: trackOrderData?.receiver_details?.address
                                                                    }),
                                                                    router.pathname !== "/profile" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Button, {
                                                                        onClick: handleClick,
                                                                        children: (0,i18next__WEBPACK_IMPORTED_MODULE_11__.t)("View Details")
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_system__WEBPACK_IMPORTED_MODULE_6__.Stack, {
                                mt: "100px",
                                width: "100%",
                                justifyContent: "center",
                                pl: "50px",
                                pr: "50px",
                                mb: "20px",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_parcel_ParcelTrackOderStepper__WEBPACK_IMPORTED_MODULE_13__/* ["default"] */ .Z, {
                                    steps: steps,
                                    activeStep: actStep
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomDivider__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z, {
                                border: "1px"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                                justifyContent: "space-between",
                                direction: "row",
                                mt: "10px",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        fontWeight: "700",
                                        color: theme.palette.primary.main,
                                        children: (0,i18next__WEBPACK_IMPORTED_MODULE_11__.t)("Total")
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Typography, {
                                        fontWeight: "700",
                                        color: theme.palette.primary.main,
                                        children: (0,helper_functions_CardHelpers__WEBPACK_IMPORTED_MODULE_16__/* .getAmountWithSign */ .B9)(trackOrderData?.order_amount)
                                    })
                                ]
                            })
                        ]
                    }),
                    trackOrderData?.delivery_man && (0,helper_functions_getToken__WEBPACK_IMPORTED_MODULE_21__/* .getToken */ .L)() && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_checkout_parcel_DeliveryManInfo__WEBPACK_IMPORTED_MODULE_12__/* ["default"] */ .Z, {
                        deliveryManInfo: trackOrderData?.delivery_man
                    })
                ]
            }),
            isLoading && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                padding: "70px 24px 0px 24px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Skeleton, {
                    variant: "rectangular",
                    width: "100%",
                    height: "350px"
                })
            }),
            !orderData && error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomStackFullWidth */ .Xw, {
                padding: "100px 24px 0px 24px",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_custom_empty_result__WEBPACK_IMPORTED_MODULE_15__/* ["default"] */ .Z, {
                    image: _assets_empty_png__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z,
                    label: "Order not found",
                    height: "100px",
                    width: "100px"
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TrackParcelOrderDrawer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 33224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _track_order_trackOrder_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(93666);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(97986);
/* harmony import */ var _mui_system__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_system__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(32245);
/* harmony import */ var moment__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(moment__WEBPACK_IMPORTED_MODULE_5__);






const StepperStyled = (0,_mui_system__WEBPACK_IMPORTED_MODULE_4__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Stepper)(({ theme  })=>({
        "& .MuiStepConnector-root ": {
            "& .MuiStepConnector-line": {
                borderLeftWidth: "2px"
            }
        },
        "& .MuiStepConnector-line": {
            height: "28px",
            marginLeft: "-6px",
            marginBottom: "-11px",
            marginTop: "-10px"
        },
        "& .MuiSvgIcon-root ": {
            width: "14px",
            height: "14px",
            color: theme.palette.neutral[100],
            border: "3px solid",
            borderColor: theme.palette.neutral[400],
            borderRadius: "50%"
        },
        "& .Mui-completed": {
            borderColor: theme.palette.primary.main
        },
        "& .MuiStepLabel-label.Mui-completed": {
            color: theme.palette.primary.main
        },
        "& .MuiStepConnector-root.Mui-active .MuiStepConnector-line": {
            borderColor: theme.palette.neutral[400]
        },
        "& .MuiStepConnector-root.Mui-completed .MuiStepConnector-line": {
            borderColor: theme.palette.primary.main
        }
    }));
const ParcelTrackOderStepper = ({ steps , activeStep  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(StepperStyled, {
        orientation: "vertical",
        activeStep: activeStep,
        children: steps?.map((step, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Step, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.StepLabel, {
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_system__WEBPACK_IMPORTED_MODULE_4__.Stack, {
                        direction: "row",
                        justifyContent: "space-between",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                fontSize: "12px",
                                fontWeight: "400",
                                children: step?.label
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_3__.Typography, {
                                fontSize: "12px",
                                children: step?.time && moment__WEBPACK_IMPORTED_MODULE_5___default()(step?.time).format("D MMM, h:mm A")
                            })
                        ]
                    })
                })
            }, index))
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ParcelTrackOderStepper);


/***/ }),

/***/ 32414:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_2__]);
react_i18next__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const Subtitle1 = (props)=>{
    const { text , textAlign , ...rest } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    const isSmall = (0,_mui_material__WEBPACK_IMPORTED_MODULE_1__.useMediaQuery)(theme.breakpoints.down("sm"));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        textAlign: textAlign ? textAlign : "center",
        variant: isSmall ? "body2" : "subtitle1",
        lineHeight: "24px",
        fontWeight: "400",
        sx: {
            color: "text.secondary"
        },
        ...rest,
        children: t(text)
    });
};
Subtitle1.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Subtitle1);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;
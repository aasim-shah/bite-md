"use strict";
exports.id = 3270;
exports.ids = [3270];
exports.modules = {

/***/ 63270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "e": () => (/* binding */ StyledInputBase),
/* harmony export */   "o": () => (/* binding */ Search)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(45269);
/* harmony import */ var helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(90603);
/* harmony import */ var helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(42604);




const Search = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_1__/* .CustomStackFullWidth */ .Xw)(({ theme , type2  })=>({
        backgroundColor: theme.palette.neutral[100],
        color: theme.palette.neutral[600],
        height: "40px",
        border: type2 && `1px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)((0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_3__/* .getCurrentModuleType */ .X)() === helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_2__/* .ModuleTypes.FOOD */ .J.FOOD ? theme.palette.moduleTheme.food : theme.palette.primary.main, 0.4)}`,
        borderRadius: "5px"
    }));
const StyledInputBase = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.InputBase)(({ theme , language_direction  })=>({
        color: (0,helper_functions_getCurrentModuleType__WEBPACK_IMPORTED_MODULE_3__/* .getCurrentModuleType */ .X)() === helper_functions_moduleTypes__WEBPACK_IMPORTED_MODULE_2__/* .ModuleTypes.FOOD */ .J.FOOD ? theme.palette.moduleTheme.food : "primary.main",
        width: "100%",
        "& .MuiInputBase-input": {
            padding: "10px 17px",
            transition: theme.transitions.create("width"),
            width: "100%"
        }
    }));


/***/ })

};
;
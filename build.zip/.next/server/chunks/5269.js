"use strict";
exports.id = 5269;
exports.ids = [5269];
exports.modules = {

/***/ 45269:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$_": () => (/* binding */ SliderCustom),
/* harmony export */   "B7": () => (/* binding */ CloseIconWrapper),
/* harmony export */   "Bh": () => (/* binding */ AddressTypeStack),
/* harmony export */   "DF": () => (/* binding */ CustomListItem),
/* harmony export */   "E4": () => (/* binding */ FlexContainerCenter),
/* harmony export */   "Eq": () => (/* binding */ CustomIconButton),
/* harmony export */   "J8": () => (/* binding */ CustomPaper),
/* harmony export */   "JK": () => (/* binding */ CouponStyle),
/* harmony export */   "Ks": () => (/* binding */ CustomTextArea),
/* harmony export */   "LL": () => (/* binding */ UserProfileTabs),
/* harmony export */   "MV": () => (/* binding */ StoreImageBox),
/* harmony export */   "SE": () => (/* binding */ CustomImageContainerStyled),
/* harmony export */   "T8": () => (/* binding */ CustomSpan),
/* harmony export */   "Xw": () => (/* binding */ CustomStackFullWidth),
/* harmony export */   "aX": () => (/* binding */ UserProfileTab),
/* harmony export */   "at": () => (/* binding */ UserInfoGrid),
/* harmony export */   "b5": () => (/* binding */ RoundedStack),
/* harmony export */   "hQ": () => (/* binding */ CustomFab),
/* harmony export */   "hu": () => (/* binding */ StoreDetailsNavButton),
/* harmony export */   "i$": () => (/* binding */ CustomStackForFoodModal),
/* harmony export */   "i5": () => (/* binding */ CustomColouredTypography),
/* harmony export */   "iD": () => (/* binding */ CustomPaperBigCard),
/* harmony export */   "jH": () => (/* binding */ CustomOverlayBox),
/* harmony export */   "jj": () => (/* binding */ CustomFormControlLabel),
/* harmony export */   "kL": () => (/* binding */ PageDetailsWrapper),
/* harmony export */   "kY": () => (/* binding */ CustomModalWrapper),
/* harmony export */   "m": () => (/* binding */ CustomBoxForTips),
/* harmony export */   "mI": () => (/* binding */ CustomTypographyGray),
/* harmony export */   "mo": () => (/* binding */ ImageContainer),
/* harmony export */   "n2": () => (/* binding */ CustomTypographyBold),
/* harmony export */   "op": () => (/* binding */ CustomButton),
/* harmony export */   "sO": () => (/* binding */ CustomFullDivider),
/* harmony export */   "uu": () => (/* binding */ CustomBoxFullWidth),
/* harmony export */   "xb": () => (/* binding */ CustomLink),
/* harmony export */   "yM": () => (/* binding */ CustomTextField),
/* harmony export */   "zv": () => (/* binding */ CustomTextFieldContainer)
/* harmony export */ });
/* unused harmony exports FlexContainerCol, FlexContainerSpaceBetween, FlexContainer, CustomColouredTypographySubtitle, CenteringSingleComponentOnLayout, CustomTabs, CustomBadge, CustomTypographyAlign, CustomChip, CustomBoxWithSpacing, CustomSearch, StyledInputBase, Logo, CustomStackForLoaction, CustomBoxAbsoluteCenter, ccsSelect, CustomList */
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85246);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Link__WEBPACK_IMPORTED_MODULE_1__);


// import imgB from '../../public/static/Privacy/RectangleP.png'
//import { Link } from 'react-router-dom'
const FlexContainerCol = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)({
    display: "flex",
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center"
});
const FlexContainerSpaceBetween = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)({
    width: "100%",
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between"
});
const FlexContainerCenter = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)({
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    maxWidth: "1400px",
    width: "100%",
    marginRight: "auto",
    marginLeft: "auto"
});
const FlexContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)({
    display: "flex",
    gap: ".5rem",
    overflowX: "auto",
    whiteSpace: "nowrap",
    flexWrap: "nowrap",
    padding: "8px 0px 8px 5px",
    typography: "body1",
    "& :not(style) + :not(style)": {
        ml: 1
    }
});
const CustomTextField = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextField)(({ theme  })=>({
        borderRadius: "13px",
        "& .MuiInputBase-input": {
            padding: "15px 10px",
            "& .MuiOutlinedInput-input": {
                padding: "4px 10px",
                borderRadius: "5px"
            }
        }
    }));
const CustomTextArea = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.TextareaAutosize)(({ theme  })=>({
        padding: "10px",
        borderRadius: "8px",
        border: `1px solid ${theme.palette.primary.main}`,
        backgroundColor: theme.palette.neutral[100],
        color: theme.palette.neutral[1000]
    }));
const CustomPaper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Paper)(({ theme , width , height  })=>({
        //backgroundColor: '#D1D5DB',
        padding: "2rem",
        maxWidth: width ? width : "600px",
        width: "100%",
        minHeight: "100px",
        height: height ? height : "100%",
        borderRadius: "20px",
        justifyContent: "center",
        textAlign: "center"
    }));
const CustomPaperBigCard = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Paper)(({ theme , nopadding , minheight , height , backgroundcolor , padding , width , noboxshadow  })=>({
        backgroundColor: backgroundcolor ? backgroundcolor : theme.palette.background.paper,
        padding: nopadding === "true" ? "none" : padding ? padding : "1.875rem",
        width: width ? width : "100%",
        height: height ? height : "100%",
        minHeight: minheight && minheight,
        borderRadius: "10px",
        boxShadow: noboxshadow === "true" ? "none" : theme.palette.mode === "light" ? `0px 0px 2px rgba(145, 158, 171, 0.2), 0px 5px 20px ${theme.palette.paperBoxShadow}` : "none"
    }));
const CustomButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button)(({ theme  })=>({
        [theme.breakpoints.up("sm")]: {}
    }));
const CustomFullDivider = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Divider)(({ theme  })=>({
        width: "100%"
    }));
const ImageContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme  })=>({
        borderRadius: "0.125rem",
        position: "relative",
        "& img": {
            width: "100%",
            height: "300px",
            objectFit: "contain"
        }
    }));
const CustomColouredTypography = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme , color  })=>({
        color: color ? color : theme.palette.primary.main
    }));
const CustomColouredTypographySubtitle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme  })=>({
        marginTop: "0.563rem",
        textTransform: "none",
        color: theme.palette.neutral[700]
    }));
const CenteringSingleComponentOnLayout = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)({
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    height: "100%",
    width: "100%"
});
const CustomTabs = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Tabs)(({ theme  })=>({
        border: "1px solid",
        borderColor: theme.palette.primary.main,
        padding: "5px",
        borderRadius: "15px",
        "& .MuiTabs-scrollButtons.Mui-disabled": {
            opacity: 0.3
        }
    }));
const CloseIconWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)("div")(({ theme , right , language_direction  })=>({
        top: 0,
        right: right ? right : 0,
        height: "100%",
        position: "absolute",
        cursor: "pointer",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
    }));
const CustomFormControlLabel = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.FormControlLabel)(({ theme  })=>({
        color: theme.palette.neutral[500]
    }));
const CustomBadge = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Badge)(({ theme  })=>({
        "& .MuiBadge-badge": {
            fontWeight: "bold"
        }
    }));
const CustomTypographyBold = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme , marginTop  })=>({
        fontWeight: "bold"
    }));
const CustomTypographyAlign = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme , align  })=>({
        textAlign: align
    }));
const CustomChip = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Chip)(({ theme  })=>({
        fontWeight: "bold"
    }));
const CustomIconButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , marginTop , align  })=>({
        display: "flex",
        justifyContent: align ? align : "center",
        alignItems: "center",
        color: theme.palette.neutral[700],
        cursor: "pointer",
        gap: "8px"
    }));
const CustomBoxFullWidth = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme  })=>({
        width: "100%"
    }));
const CustomStackFullWidth = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ theme , marginBottom , justifyContent  })=>({
        width: "100%",
        justifyContent: justifyContent
    }));
const CustomBoxWithSpacing = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , marginTopBottom  })=>({
        width: "100%",
        marginTop: marginTopBottom && `${marginTopBottom}rem`,
        marginBottom: marginTopBottom && `${marginTopBottom}rem`
    }));
const CustomSearch = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)("div")(({ theme  })=>({
        position: "relative",
        borderRadius: theme.shape.borderRadius,
        backgroundColor: "#F3F2F2",
        color: "black",
        //alpha(theme.palette.common.white, 0.15),
        "&:hover": {
            //backgroundColor: alpha(theme.palette.common.white, 0.25),
            backgroundColor: "#F3F2F2"
        },
        marginLeft: 0,
        marginRight: "10px",
        width: "100%",
        [theme.breakpoints.up("sm")]: {
            marginLeft: theme.spacing(1),
            width: "auto"
        }
    }));
const StyledInputBase = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.InputBase)(({ theme , width  })=>({
        color: "inherit",
        width: "120px",
        border: "2px solid #EF7822",
        padding: "5px 0",
        marginLeft: "5px",
        borderRadius: "5px",
        "& .MuiInputBase-input": {
            fontSize: "1.3rem",
            textAlign: "center"
        }
    }));
const Logo = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)("div")(({ theme , height , width  })=>({
        width: width,
        height: height,
        justifyContent: "center",
        position: "relative",
        cursor: "pointer",
        "& img": {
            width: "100%",
            height: "100%",
            objectFit: "contained"
        }
    }));
const CustomLink = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Link__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme , color  })=>({
        color: color ? color : "primary.main",
        cursor: "pointer",
        fontWeight: "700",
        "&:hover": {
            //backgroundColor: alpha(theme.palette.common.white, 0.25),
            color: theme.palette.primary.dark,
            textDecoration: "none"
        }
    }));
const CustomTextFieldContainer = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , background , noheight  })=>({
        width: "100%",
        height: !noheight && "5rem",
        color: theme.palette.neutral[1000]
    }));
const CustomStackForLoaction = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ theme  })=>({
        justifyContent: "center",
        cursor: "pointer",
        alignItems: "center"
    }));
const CustomOverlayBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , height , top  })=>({
        position: "absolute",
        bottom: 0,
        left: 0,
        top: top ? top : 0,
        width: "100%",
        backgroundColor: "rgba(0, 0, 0, 0.54)",
        color: "white",
        // padding: '10px',
        height: height ? height : "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: "999"
    }));
const CustomFab = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Fab)(({ theme , module_type  })=>({
        width: "30px",
        height: "30px",
        minHeight: "30px",
        [theme.breakpoints.down("sm")]: {
            width: "30px",
            height: "30px"
        }
    }));
const CustomImageContainerStyled = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , sm_width , max_width , margin_bottom , width , smheight , height , objectfit , minwidth , border_radius , sm_mb , sm_max_width , mdHeight , cursor , aspect_ratio , padding  })=>({
        //maxWidth:'20rem',
        display: "inline-flex",
        background: "transparent",
        width: width ? width : "100%",
        height: height ? height : "100%",
        minWidth: minwidth,
        maxWidth: max_width,
        padding: padding ? padding : "",
        marginBottom: margin_bottom,
        position: "relative",
        borderRadius: border_radius ? border_radius : "none",
        //cursor: "pointer",
        [theme.breakpoints.down("md")]: {
            height: mdHeight ? mdHeight : ""
        },
        [theme.breakpoints.down("sm")]: {
            marginBottom: sm_mb ? sm_mb : "",
            height: smheight ? smheight : "",
            maxWidth: sm_max_width ? sm_max_width : "",
            width: sm_width ? sm_width : ""
        },
        "& img": {
            width: "100%",
            height: "100%",
            objectFit: objectfit ? objectfit : "cover",
            borderRadius: border_radius,
            aspectRatio: aspect_ratio ? aspect_ratio : ""
        }
    }));
const CustomListItem = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.ListItem)(({ theme , display , cursor , border  })=>({
        display: display,
        cursor: cursor && "pointer",
        border: border,
        borderRadius: "10px",
        paddingInline: "5px",
        justifyContent: "flex-start"
    }));
const CustomBoxAbsoluteCenter = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme  })=>({
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)"
    }));
const ccsSelect = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Select)(({ theme  })=>({
        select: {
            "&:before": {
                borderColor: (theme)=>theme.palette.primary.main
            },
            "&:after": {
                borderColor: (theme)=>theme.palette.primary.main
            }
        },
        icon: {
            fill: (theme)=>theme.palette.primary.main
        }
    }));
const CustomList = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.List)(({ theme , border  })=>({
        paddingTop: "0px"
    }));
const SliderCustom = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ float , theme , language_direction , nopadding , paddingBottom , padding  })=>({
        position: "relative",
        width: "100%",
        paddingY: "10px",
        "& .slick-slider": {
            "& .slick-slide": {
                padding: padding ?? "6px"
            },
            "& .slick-list": {
                paddingY: nopadding !== "true" && "8px",
                //paddingBottom: "1rem !important",
                "& .slick-track": {
                    float: float ? float : theme.direction === "ltr" ? "left" : "right",
                    gap: "5px"
                }
            }
        }
    }));
const CustomTypographyGray = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme , nodefaultfont , textdecoration  })=>({
        color: theme.palette.neutral[400],
        fontWeight: "normal",
        fontSize: nodefaultfont !== "true" && "14px",
        textDecoration: textdecoration
    }));
const CustomBoxForTips = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , active  })=>({
        paddingInline: "10px",
        height: "50px",
        width: "auto",
        minWidth: "50px",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        border: "1px solid ",
        borderColor: theme.palette.primary.main,
        cursor: "pointer",
        borderRadius: "5px",
        background: active && theme.palette.primary.main,
        position: "relative",
        [theme.breakpoints.down("sm")]: {
            height: "30px",
            paddingInline: "5px"
        }
    }));
const StoreDetailsNavButton = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button)(({ theme , color , background , language_direction , borderRigthTop , borderRightBottom , borderLeftBottom , borderLeftTop  })=>({
        backgroundColor: background ? theme.palette.primary.main : "inherit",
        color: background ? theme.palette.whiteContainer.main : theme.palette.neutral[1000],
        borderRadius: "15px",
        borderBottomLeftRadius: borderLeftBottom && borderLeftBottom,
        "&:hover": {
            backgroundColor: background && theme.palette.primary.deep
        }
    }));
const CustomModalWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme  })=>({
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        borderRadius: "8px",
        backgroundColor: "background.paper",
        p: 2,
        outline: "none"
    }));
const StoreImageBox = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Box)(({ theme , borderraduis , padding , border  })=>({
        padding: padding ? padding : "12px",
        border: border,
        borderRadius: borderraduis ? borderraduis : "5px",
        display: "flex",
        alignItems: "center",
        position: "relative",
        width: "76px",
        [theme.breakpoints.down("md")]: {
            padding: "18px",
            width: "81px"
        }
    }));
const AddressTypeStack = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ theme , addressType , value  })=>({
        padding: "10px",
        border: value === addressType ? `1px solid ${theme.palette.primary.main}` : `1px solid ${(0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)(theme.palette.neutral[400], 0.5)}`,
        borderRadius: "5px",
        background: value === addressType && (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)(theme.palette.primary.main, 0.2),
        cursor: "pointer"
    }));
const UserInfoGrid = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Grid)(({ theme , page , userToken  })=>({
        position: "relative",
        zIndex: 99,
        minHeight: "100px",
        "&::before": {
            content: '""',
            position: "absolute",
            left: 0,
            top: 0,
            right: 0,
            bottom: userToken ? "42%" : "0%",
            backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)(theme.palette.primary.main, 0.1),
            zIndex: -1,
            [theme.breakpoints.down("md")]: {
                bottom: page === "profile-settings" ? "81%" : page === "inbox" ? "0%" : "37%"
            }
        },
        "&::after": {
            content: '""',
            position: "absolute",
            left: 0,
            bottom: userToken ? "42%" : "0%",
            top: 0,
            right: 0,
            backgroundColor: (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)(theme.palette.primary.main, 0.1),
            zIndex: -1,
            [theme.breakpoints.down("md")]: {
                bottom: page === "profile-settings" ? "81%" : page === "inbox" ? "0%" : "37%"
            }
        }
    }));
const UserProfileTabs = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Tabs)(({ theme , isActive  })=>({
        "& .MuiTabs-scroller": {
            "& .MuiTabs-flexContainer": {
                flexWrap: "nowrap"
            }
        },
        "& .MuiButtonBase-root": {
            minHeight: "42px",
            color: theme.palette.neutral[600],
            textTransform: "capitalize",
            [theme.breakpoints.down("sm")]: {
                minHeight: "32px"
            }
        }
    }));
const UserProfileTab = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Button)(({ theme , page , item , marginright , fontSize , borderRadius  })=>({
        background: item?.name === page && (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.alpha)(theme.palette.primary.main, 0.1),
        paddingInlineEnd: "15px",
        paddingInlineStart: "15px",
        marginInlineEnd: marginright ? marginright : "25px",
        paddingBlockEnd: "0px",
        paddingBlockStart: "0px",
        borderRadius: borderRadius ? borderRadius : "10px",
        [theme.breakpoints.down("sm")]: {
            marginInlineEnd: "10px",
            paddingInlineEnd: "7px",
            paddingInlineStart: "7px"
        }
    }));
const RoundedStack = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ theme , width , height , background , smwidth , smheight  })=>({
        width: width,
        height: height,
        backgroundColor: background,
        borderRadius: "50%",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
        [theme.breakpoints.down("md")]: {
            width: smwidth,
            height: smheight
        }
    }));
const CouponStyle = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ theme  })=>({
        position: "relative",
        "&::after": {
            position: " absolute",
            content: '""',
            display: "block",
            width: "22px",
            height: "22px",
            backgroundColor: "#D9D9D9",
            top: "-20px",
            right: "-9px",
            zIndex: 1,
            borderRadius: "50%"
        },
        "&::before": {
            position: " absolute",
            content: '""',
            display: "block",
            width: "22px",
            height: "22px",
            backgroundColor: "#D9D9D9",
            bottom: "-20px",
            right: "-10px",
            zIndex: 1,
            borderRadius: "50%"
        }
    }));
const PageDetailsWrapper = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(CustomStackFullWidth)(({ theme  })=>({
        marginTop: "1rem"
    }));
const CustomStackForFoodModal = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Stack)(({ theme , padding  })=>({
        padding: padding ? padding : "18px",
        position: "absolute",
        bottom: "0",
        background: `linear-gradient(180deg, rgba(0, 0, 0, 0) 0%, rgb(18 18 18 / 94%) 100%)`
    }));
const CustomSpan = (0,_mui_material__WEBPACK_IMPORTED_MODULE_0__.styled)("span")(({ theme  })=>({
        color: theme.palette.text.secondary
    }));


/***/ })

};
;
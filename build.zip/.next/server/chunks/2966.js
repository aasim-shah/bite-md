"use strict";
exports.id = 2966;
exports.ids = [2966];
exports.modules = {

/***/ 96702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/docx.7072fee4.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA6klEQVR42h3LvUoDQRQF4HPnZ2fXXTdBtFAI1lbWYqFgYyE+idj7CmrnA6iVlpbiS1iLQooUQiBEUGZn3b13MsnXHA6HQ0iOb2R0tNs/lVksQOh8S7Vv7DWAB4PER6kHRTzsBdgoBZvrhKbh+9dPmuq7l+i2HM6tlbPfQDz7U6icdEXOOrTqywjFi5M9uh3PiHcGUbc9kGmVMsJqeFM52MwC+yODLo3DCgj/hI9vxtSLUhyXByTEHZOUOUnqkmkgMKKZzPHsDA6GFZ8aHfE+BoyG+gmC7TXKCCtcXj72b3WOfFmQWAU3meurBWLAWyDURnVcAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 96967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/folder.ce998a02.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA1ElEQVR42mOAAlYg5mBAA6XRHEwMkws4Ay4uEHp0Y6nw4w1tvJ1d6eyOUwo4ArNcGUTAqrZ28VW93Sr2/9UW8f93V4n+v7JY5P/lRSL/JxXyLAQrWFLAUHR+s/L/17eNf72+YfTn7S2jPx/uGv96ckHv/6x64WSGGGuG4scX9P///2T5498r898g/P+D5e+3V/X/hDIwmDD0N0uVvb5u8P/bQ+P/X+4ZgfF3IPv8FpXLDCDQWSEqvXqCZPb6yZLZ6yaD6cx1EyWKW9M4TRgIgR1TRJkA1MJk0a08hbQAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 80632:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/pdf.8af09ceb.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA6klEQVR42h3PvUrDUBxA8ZObywXRRSn4iZNLdkGyOFpcxKfQbPoa+gLmKYSis7RICUhQ8YMsrRHRyZDGLKG3JH9Dz/qbjgPQB08gdMAHaCDSu3sBkHALXnxymhejsRQfqXy/vMrbxaUMIL/vHnrcweDx7FzaptKWF4VM8nzaPzqWYWtagY9SAKYBrLXUIma8tclKaxqAqkKyDGnR/c1Q2qUuS54BLWvbkYRX+85fad3ugek0DfRurOldG9tZjXS1uBAswfAn/VxWcYyjXGbviZnhTlKlAgfgYcfznkZJ+AW+C9SoSK1vzDf/Aaz+bNDzC6OpAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 11288:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/txt-file.41bbe04a.png","height":512,"width":512,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA2UlEQVR42mMAgWvXrgRcvXp5x/XrV5efPnN6k09UgQVIfO6CZSxgBUDJFqCi/zdvXvt/4eL5//WtEz51T5ipxwAD1y5frL14/tz/82fP/Lhw7uz38+fO/r94/mw7XMGl+/cqth88/H/19l2/QXjHocP/rzy8XwZX8HTZotm316/9f3vl8t9gvH7N/ydLF84GS+7+/5/pqwHHzXe1Zf9fzpr6C4RB7K8GnDf3AOXAij5FeF97W1n0/8W0iWAMYoPE4FY82Lop9u7+Pdvv79q+AoRBbJAYAwMDAwA/BpExjf5dfwAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 57198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _file_previewer_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(77595);




const FileFormatInfo = (props)=>{
    const { text  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_file_previewer_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_3__/* .CustomBoxImageText */ .w_, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: text
        })
    });
};
FileFormatInfo.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FileFormatInfo);


/***/ }),

/***/ 47548:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(77595);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(83188);
/* harmony import */ var _mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(27163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(21967);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _assets_pdf_png__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(80632);
/* harmony import */ var _assets_docx_png__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(96702);
/* harmony import */ var _assets_txt_file_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(11288);
/* harmony import */ var _assets_folder_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(96967);
/* harmony import */ var _CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(58861);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_5__]);
_form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const FilePreviewer = (props)=>{
    const { file , anchor , deleteImage , hintText , width , onChange , onDelete , errorStatus , acceptedFileInput , label , titleText , gridControl , prescription  } = props;
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useTheme)();
    const [multipleImages, setMultipleImages] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)([]);
    const matches = (0,_mui_material__WEBPACK_IMPORTED_MODULE_6__.useMediaQuery)("(min-width:400px)");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        if (file?.length > 0) {
            const newImages = [];
            file.forEach((image)=>newImages.push({
                    url: URL.createObjectURL(image),
                    type: image.name.split(".").pop()
                }));
            setMultipleImages(newImages);
        } else {}
    }, [
        file
    ]);
    const renderFilePreview = ()=>{
        if (file?.length > 0) {
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                container: true,
                spacing: 1,
                children: [
                    multipleImages.map((image, index)=>{
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                            item: true,
                            xs: prescription === "true" && matches ? 6 : 12,
                            sm: gridControl === "true" ? 4 : 2.5,
                            md: gridControl === "true" ? 4 : 2.5,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomBoxForFilePreviewer */ .JL, {
                                width: width,
                                children: [
                                    previewBasedOnType(image, index),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .IconButtonImagePreviewer */ .i3, {
                                        onClick: ()=>onDelete(index),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_3___default()), {
                                            sx: {
                                                width: "15px",
                                                height: "15px",
                                                color: theme.palette.error.light
                                            }
                                        })
                                    })
                                ]
                            })
                        }, index);
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Grid, {
                        item: true,
                        xs: prescription === "true" && matches ? 6 : 12,
                        sm: gridControl === "true" ? 4 : 2.3,
                        md: gridControl === "true" ? 4 : 2.3,
                        children: multipleImages?.length <= 5 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_5__/* ["default"] */ .Z, {
                            titleText: titleText,
                            label: label,
                            hintText: hintText,
                            errorStatus: errorStatus,
                            width: true,
                            onChange: onChange,
                            acceptedFileInput: acceptedFileInput
                        })
                    })
                ]
            });
        } else {
            const previewImage = {
                url: URL.createObjectURL(file),
                type: file.name.split(".").pop()
            };
            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomBoxForFilePreviewer */ .JL, {
                children: [
                    previewBasedOnType(previewImage),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .IconButtonImagePreviewer */ .i3, {
                        onClick: ()=>deleteImage(),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Delete__WEBPACK_IMPORTED_MODULE_3___default()), {
                            sx: {
                                width: "15px",
                                height: "15px",
                                color: theme.palette.error.light
                            }
                        })
                    })
                ]
            });
        }
    };
    const previewBasedOnType = (file, fileIndex)=>{
        if (file.type === "jpg" || file.type === "jpeg" || file.type === "gif" || file.type === "png") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .FilePreviewerWrapper */ .Ec, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    src: file.url,
                    alt: "preview",
                    height: "7.75rem"
                })
            });
        } else if (file.type === "pdf") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .FilePreviewerWrapper */ .Ec, {
                // onClick={() => anchor.current.click()}
                objectFit: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    src: _assets_pdf_png__WEBPACK_IMPORTED_MODULE_7__/* ["default"] */ .Z,
                    alt: "pdf",
                    height: "7.75rem"
                })
            });
        } else if (file.type === "docx" || file.type === "docx") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .FilePreviewerWrapper */ .Ec, {
                // onClick={() => anchor.current.click()}
                objectFit: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    src: _assets_docx_png__WEBPACK_IMPORTED_MODULE_8__/* ["default"] */ .Z,
                    alt: "doc",
                    height: "7.75rem"
                })
            });
        } else if (file.type === "txt") {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .FilePreviewerWrapper */ .Ec, {
                // onClick={() => anchor.current.click()}
                objectFit: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    src: _assets_txt_file_png__WEBPACK_IMPORTED_MODULE_9__/* ["default"] */ .Z,
                    alt: "text",
                    height: "7.75rem"
                })
            });
        } else {
            return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FilePreviewer_style__WEBPACK_IMPORTED_MODULE_2__/* .FilePreviewerWrapper */ .Ec, {
                // onClick={() => anchor.current.click()}
                objectFit: true,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_CustomImageContainer__WEBPACK_IMPORTED_MODULE_11__/* ["default"] */ .Z, {
                    src: _assets_folder_png__WEBPACK_IMPORTED_MODULE_10__/* ["default"] */ .Z,
                    alt: "text"
                })
            });
        }
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_6__.Stack, {
        width: "100%",
        alignItems: "center",
        spacing: 3,
        children: [
            renderFilePreview(),
            hintText && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_5__.CustomBoxImageText, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_4___default()), {
                    children: hintText
                })
            })
        ]
    });
};
FilePreviewer.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FilePreviewer);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 94530:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _FileUpload_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(47747);
/* harmony import */ var _styled_components_CustomTypographies_style__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(10648);
/* harmony import */ var _mui_icons_material_AddPhotoAlternate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(60199);
/* harmony import */ var _mui_icons_material_AddPhotoAlternate__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddPhotoAlternate__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _file_format_text_FileFormatInfo__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(57198);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_7__]);
react_i18next__WEBPACK_IMPORTED_MODULE_7__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];


// import { DashedBox } from '../../gurbage/admin/components/forms/FormWithFormik.style'

// import cloudIcon from '../../assets/images/icons/cloud-upload.png'
// import FileFormatInfo from '../file-format-text/FileFormatInfo'





const FileUpload = (props)=>{
    const { anchor , color , width , errorStatus , labelText , titleText , hintText , alignItems  } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const theme = (0,_mui_material__WEBPACK_IMPORTED_MODULE_2__.useTheme)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
        width: "100%",
        spacing: 3,
        children: [
            titleText && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FileUpload_style__WEBPACK_IMPORTED_MODULE_3__/* .FileUploadHeader */ .WV, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomTypographies_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomTypographyGray */ .mI, {
                    variant: "h5",
                    children: titleText
                })
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                alignItems: "baseline",
                justifyContent: "center",
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FileUpload_style__WEBPACK_IMPORTED_MODULE_3__/* .DashedBox */ .pk, {
                        onClick: ()=>anchor.current.click(),
                        color: color,
                        component: "label",
                        width: width,
                        errorStatus: errorStatus,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Stack, {
                            alignItems: "center",
                            justifyContent: "center",
                            spacing: 1.5,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FileUpload_style__WEBPACK_IMPORTED_MODULE_3__/* .ImageContainerFileUpload */ .V9, {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddPhotoAlternate__WEBPACK_IMPORTED_MODULE_5___default()), {
                                        sx: {
                                            width: "40px",
                                            height: "40px",
                                            color: theme.palette.neutral[1100]
                                        }
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.Tooltip, {
                                    title: labelText,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FileUpload_style__WEBPACK_IMPORTED_MODULE_3__/* .FileUploadTextContainer */ .ZY, {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_styled_components_CustomTypographies_style__WEBPACK_IMPORTED_MODULE_4__/* .CustomTypographyEllipsis */ .tp, {
                                            sx: {
                                                fontSize: "13px",
                                                fontWeight: "400"
                                            },
                                            children: labelText ? labelText : t("File upload")
                                        })
                                    })
                                })
                            ]
                        })
                    }),
                    hintText && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_file_format_text_FileFormatInfo__WEBPACK_IMPORTED_MODULE_6__/* ["default"] */ .Z, {
                        text: hintText
                    })
                ]
            })
        ]
    });
};
FileUpload.propTypes = {};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FileUpload);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 47747:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "V9": () => (/* binding */ ImageContainerFileUpload),
/* harmony export */   "WV": () => (/* binding */ FileUploadHeader),
/* harmony export */   "ZY": () => (/* binding */ FileUploadTextContainer),
/* harmony export */   "pk": () => (/* binding */ DashedBox)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);



const ImageContainerFileUpload = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .ImageContainer */ .mo)(({ theme  })=>({
        maxHeight: "1.75rem",
        maxWidth: "1.75rem"
    }));
const FileUploadTextContainer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme  })=>({
        textAlign: "center",
        width: "8rem"
    }));
const FileUploadHeader = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomBoxFullWidth */ .uu)(({ theme  })=>({
        display: "flex"
    }));
const DashedBox = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_1___default()))(({ theme , width , color , errorStatus  })=>({
        height: "7.75rem",
        width: width ? width : "7.75rem",
        border: "1.3px dashed",
        borderColor: color ? "red" : theme.palette.neutral[400] && errorStatus ? "red" : theme.palette.neutral[400],
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: theme.palette.neutral[400],
        borderRadius: "12px",
        cursor: "pointer",
        [theme.breakpoints.down("sm")]: {
            width: "100%"
        }
    }));


/***/ }),

/***/ 21967:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(45269);
/* harmony import */ var _file_upload_container_FileUpload__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(94530);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_file_upload_container_FileUpload__WEBPACK_IMPORTED_MODULE_3__]);
_file_upload_container_FileUpload__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];




const FileInputField = (props)=>{
    const { width , onChange , errorStatus , acceptedFileInput , labelText , titleText , hintText , imagesHandler  } = props;
    const imageContainerBusinessRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_styled_components_CustomStyles_style__WEBPACK_IMPORTED_MODULE_2__/* .CustomBoxFullWidth */ .uu, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_file_upload_container_FileUpload__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                titleText: titleText,
                labelText: labelText,
                hintText: hintText,
                width: width,
                anchor: imageContainerBusinessRef,
                errorStatus: errorStatus
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                ref: imageContainerBusinessRef,
                multiple: true,
                id: "file",
                name: "file",
                type: "file",
                accept: acceptedFileInput,
                hidden: true,
                onChange: (e)=>onChange(e)
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (FileInputField);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 17787:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(16689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _file_previewer_FilePreviewer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(47548);
/* harmony import */ var _form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(21967);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6022);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _MultiFileUploader_style__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(24378);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(57987);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_file_previewer_FilePreviewer__WEBPACK_IMPORTED_MODULE_2__, _form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_7__]);
([_file_previewer_FilePreviewer__WEBPACK_IMPORTED_MODULE_2__, _form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_3__, react_i18next__WEBPACK_IMPORTED_MODULE_7__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);








const MultiFileUploader = (props)=>{
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_7__.useTranslation)();
    const { width , fileImagesHandler , maxFileSize , supportedFileFormats , acceptedFileInput , labelText , titleText , hintText , totalFiles , gridControl , prescription  } = props;
    const [files, setFiles] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(totalFiles ? totalFiles : []);
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [errorAlert, setErrorAlert] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    // const { businessInfoImageReset } = useSelector(
    //     (state) => state.multiStepForm
    // )
    const fileInputRef = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)();
    const dispatch = (0,react_redux__WEBPACK_IMPORTED_MODULE_5__.useDispatch)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fileImagesHandler(files);
    // dispatch(setBusinessInfoImageReset(false))
    }, [
        files
    ]);
    // useEffect(() => {
    //     setFiles([])
    // }, [businessInfoImageReset])
    const FileSelectedHandler = (e)=>{
        let file = e.target.files[e.target.files.length - 1];
        let fileExtension = file.name.split(".").pop();
        if (supportedFileFormats.indexOf(fileExtension) !== -1) {
            if (file.size <= maxFileSize) {
                setError(false);
                setFiles([
                    ...files,
                    ...e.target.files
                ]);
            } else {
                setError(true);
                setErrorAlert(t("Chose an image max size 2mb"));
            }
        } else {
            setError(true);
            setErrorAlert(t("Unsupported file format chosen"));
        }
    };
    const DeleteImageFromFiles = (id)=>{
        let remainingFiles = files.filter((item, index)=>index !== id);
        setFiles(remainingFiles);
    };
    const replaceFilesByIndex = (indexNumber)=>{};
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_4__.Stack, {
        width: "100%",
        spacing: 1,
        children: [
            files.length > 0 ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_file_previewer_FilePreviewer__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                    anchor: fileInputRef,
                    errorStatus: error,
                    titleText: titleText,
                    acceptedFileInput: acceptedFileInput,
                    file: files,
                    width: width,
                    onChange: FileSelectedHandler,
                    onDelete: DeleteImageFromFiles,
                    supportedFileFormats: supportedFileFormats,
                    replaceFiles: replaceFilesByIndex,
                    gridControl: gridControl,
                    prescription: prescription
                })
            }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_form_fields_FileInputField__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {
                titleText: titleText,
                labelText: labelText,
                hintText: hintText,
                errorStatus: error,
                acceptedFileInput: acceptedFileInput,
                width: width,
                onChange: FileSelectedHandler,
                text: "Upload identity file",
                maxFileSize: 200000
            }),
            error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_MultiFileUploader_style__WEBPACK_IMPORTED_MODULE_6__/* .CustomTypographyForMultiImagePreviewer */ .g, {
                children: errorAlert
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MultiFileUploader);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 24378:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ CustomTypographyForMultiImagePreviewer)
/* harmony export */ });
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);


const CustomTypographyForMultiImagePreviewer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.styled)(_mui_material__WEBPACK_IMPORTED_MODULE_0__.Typography)(({ theme  })=>({
        color: theme.palette.error.main
    }));


/***/ }),

/***/ 74485:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(20997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(65692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(57987);
/* harmony import */ var _utils_CommonValues__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(65401);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_i18next__WEBPACK_IMPORTED_MODULE_3__]);
react_i18next__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const H1 = (props)=>{
    const { text , textAlign , textTransform , fontWeight , ...rest } = props;
    const { t  } = (0,react_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Typography, {
        textAlign: textAlign ? textAlign : "center",
        fontWeight: fontWeight ? fontWeight : "700",
        lineHeight: (0,_utils_CommonValues__WEBPACK_IMPORTED_MODULE_4__/* .IsSmallScreen */ .R)() ? "10px" : "30px",
        sx: {
            fontSize: {
                xs: "15px",
                md: "22px"
            }
        },
        textTransform: textTransform,
        ...rest,
        children: t(text)
    });
};
H1.propTypes = {
    text: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string.isRequired)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (H1);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;